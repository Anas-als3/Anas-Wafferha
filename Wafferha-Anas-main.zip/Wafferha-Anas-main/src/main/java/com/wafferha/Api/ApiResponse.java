package com.wafferha.Api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ApiResponse {

    private String message;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Object data;

    public ApiResponse(String message) {
        this.message = message;
    }

    public ApiResponse(String message, Object data) {
        this.message = message;
        this.data = data;
    }

    
    private static final ObjectMapper FLAT_MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .setSerializationInclusion(JsonInclude.Include.NON_NULL);

    





    public static Map<String, Object> flat(String message, Object data) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("message", message);
        if (data != null) {
            try {
                Map<String, Object> fields =
                        FLAT_MAPPER.convertValue(data, new TypeReference<LinkedHashMap<String, Object>>() {});
                out.putAll(fields);
            } catch (IllegalArgumentException e) {
                out.put("data", data);
            }
        }
        return out;
    }
}
