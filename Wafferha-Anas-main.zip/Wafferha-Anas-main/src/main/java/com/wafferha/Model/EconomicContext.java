package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;










@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "economic_context")
public class EconomicContext {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    
    @Column(name = "inflation_rate_pct")
    private Double inflationRatePct;

    
    @Column(name = "policy_rate_pct")
    private Double policyRatePct;

    
    @Column(name = "season_level", length = 20)
    private String seasonLevel;

    
    @Column(name = "saving_climate", length = 20)
    private String savingClimate;

    
    @Column
    private String source;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    void onSave() {
        updatedAt = LocalDateTime.now();
    }
}
