package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;




@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "scores")
public class Score {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    
    @Column(length = 20)
    private String period;

    @Column(name = "rate_subscore", precision = 19, scale = 4)
    private BigDecimal rateSubscore;

    @Column(name = "consistency_subscore", precision = 19, scale = 4)
    private BigDecimal consistencySubscore;

    @Column(name = "improvement_subscore", precision = 19, scale = 4)
    private BigDecimal improvementSubscore;

    @Column(name = "composite_score", precision = 19, scale = 4)
    private BigDecimal compositeScore;

    @Column(name = "percentile_in_league", precision = 5, scale = 2)
    private BigDecimal percentileInLeague;

    @Column(name = "computed_at", nullable = false, updatable = false)
    private LocalDateTime computedAt;

    @PrePersist
    void onCreate() {
        if (computedAt == null) {
            computedAt = LocalDateTime.now();
        }
    }
}
