package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;






@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "seasonal_points_ledger")
public class SeasonalPointsLedger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    
    @Column(name = "season_id", nullable = false)
    private Integer seasonId;

    
    @Column(name = "seasonal_wallet_id", nullable = false)
    private Integer seasonalWalletId;

    
    @Column(nullable = false)
    private int amount;

    @Column(nullable = false, length = 120)
    private String reason;

    @Column(name = "ref_id")
    private Integer refId;

    @Column(name = "entry_timestamp", nullable = false, updatable = false)
    private LocalDateTime timestamp;

    @PrePersist
    void onCreate() {
        if (timestamp == null) {
            timestamp = LocalDateTime.now();
        }
    }
}
