package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;





@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "financial_progress")
public class FinancialProgress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false, unique = true)
    private Integer userId;

    @Column(name = "total_saved", precision = 19, scale = 2)
    private BigDecimal totalSaved;

    @Column(name = "projected_goal_date")
    private LocalDate projectedGoalDate;

    @Column(name = "emergency_fund_pct", precision = 5, scale = 2)
    private BigDecimal emergencyFundPct;
}
