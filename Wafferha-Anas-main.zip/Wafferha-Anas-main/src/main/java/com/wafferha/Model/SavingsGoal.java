package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;





@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "savings_goals")
public class SavingsGoal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    @Column(nullable = false, length = 120)
    private String name;

    @Column(name = "target_amount", nullable = false)
    private Double targetAmount;

    
    
    @Column(name = "buffered_target")
    private Double bufferedTarget;

    
    @Column(name = "buffer_rationale", columnDefinition = "TEXT")
    private String bufferRationale;

    
    @Column(name = "per_period_amount", nullable = false)
    private Double perPeriodAmount;

    
    @Column(nullable = false, length = 20)
    private String cadence;

    @Column(name = "target_date", nullable = false)
    private LocalDate targetDate;

    @Column(name = "saved_amount", nullable = false)
    private Double savedAmount = 0.0;

    
    @Column(nullable = false, length = 20)
    private String status = "ACTIVE";

    
    
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}
