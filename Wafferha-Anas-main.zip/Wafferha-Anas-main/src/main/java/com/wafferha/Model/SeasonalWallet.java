package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;






@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "seasonal_wallets", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "season_id"}))
public class SeasonalWallet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    
    @Column(name = "season_id", nullable = false)
    private Integer seasonId;

    @Column(name = "seasonal_points_balance", nullable = false)
    private int seasonalPointsBalance = 0;

    @Column(name = "earned_during_season", nullable = false)
    private int earnedDuringSeason = 0;

    @Column(name = "spent_during_season", nullable = false)
    private int spentDuringSeason = 0;

    @Column(name = "expired_points", nullable = false)
    private int expiredPoints = 0;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    
    @Column(nullable = false, length = 20)
    private String status = "ACTIVE";

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        if (createdAt == null) {
            createdAt = now;
        }
        updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
