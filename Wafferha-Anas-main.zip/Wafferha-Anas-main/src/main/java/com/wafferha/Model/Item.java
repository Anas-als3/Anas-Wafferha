package com.wafferha.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(100) not null")
    private String name;

    @Column(columnDefinition = "varchar(30) not null")
    private String type;

    private Integer cost;

    @Column(columnDefinition = "varchar(20) not null")
    private String currencyType;

    @Column(columnDefinition = "varchar(20) not null")
    private String rarity;

    private LocalDateTime availableFrom;

    private LocalDateTime availableUntil;

    private Boolean isSeasonExclusive;

    
    private Boolean awardOnly;

    @Column(columnDefinition = "varchar(255)")
    private String unlockCondition;

    
    
    @Column(columnDefinition = "varchar(60)")
    private String couponCode;

    @Column(columnDefinition = "varchar(255)")
    private String couponDescription;

    @ManyToOne
    @JoinColumn(name = "season_id", referencedColumnName = "id")
    private Season season;

    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL)
    @JsonIgnore
    private Set<UserReward> userRewards;
}
