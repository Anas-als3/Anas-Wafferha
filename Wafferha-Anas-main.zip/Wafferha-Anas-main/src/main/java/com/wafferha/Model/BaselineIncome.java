package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;





@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "baseline_income")
public class BaselineIncome {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    
    @Column(name = "user_id", nullable = false, unique = true)
    private Integer userId;

    @Column(name = "window_days", nullable = false)
    private int windowDays = 90;

    @Column(name = "baseline_income_value", precision = 19, scale = 2)
    private BigDecimal baselineIncomeValue;

    @com.fasterxml.jackson.annotation.JsonIgnore
    @Column(name = "floor_value", precision = 19, scale = 2)
    private BigDecimal floorValue;

    @Column(name = "last_computed")
    private LocalDateTime lastComputed;

    @PrePersist
    void onCreate() {
        if (lastComputed == null) {
            lastComputed = LocalDateTime.now();
        }
    }
}
