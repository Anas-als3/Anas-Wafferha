package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;





@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 120)
    private String name;

    
    @Column(name = "phone_number")
    private String phoneNumber;

    @Column
    private String email;

    
    @Column(name = "payday_day")
    private Integer paydayDay;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    
    @Column(name = "monthly_income")
    private Integer monthlyIncome;

    @Column(name = "competitive_opt_in", nullable = false)
    private boolean competitiveOptIn = false;

    
    @Column(name = "phone_verified", nullable = false)
    private boolean phoneVerified = false;

    
    @Column(name = "is_bank_verified", nullable = false)
    private boolean bankVerified = false;

    
    @Column(name = "integrity_status", length = 20)
    private String integrityStatus;

    
    
    @ManyToOne
    @JoinColumn(name = "league_id")
    private League league;

    @PrePersist
    void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
}
