package com.wafferha.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class PersonalizedGoal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(20) not null")
    private String period;

    
    @Column(length = 20)
    private String status = "SUGGESTED";

    @Column(columnDefinition = "double not null")
    private Double suggestedTarget;

    @Column(columnDefinition = "varchar(255) not null")
    private String rationale;

    @Column(columnDefinition = "varchar(30) not null")
    private String modelVersion;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @JsonIgnore
    private User user;
}
