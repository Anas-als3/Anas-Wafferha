package com.wafferha.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class League {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(50) not null")
    private String segmentType;

    
    
    @Column(columnDefinition = "varchar(50) not null unique")
    private String name;

    
    
    @Column(name = "display_name", length = 60)
    private String displayName;

    @OneToMany(mappedBy = "league", cascade = CascadeType.ALL)
    @JsonIgnore
    private Set<User> users;
}