package com.wafferha.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Challenge {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(100) not null")
    private String title;

    @Column(columnDefinition = "varchar(20) not null")
    private String cadence;

    @Column(columnDefinition = "varchar(50) not null")
    private String type;

    @Column(columnDefinition = "double not null")
    private Double targetValue;

    @Column(columnDefinition = "int not null")
    private Integer rewardPoints;

    @Column(columnDefinition = "varchar(20) not null")
    private String rewardCurrencyType;

    private LocalDateTime startAt;

    private LocalDateTime endAt;

    @ManyToOne
    @JoinColumn(name = "season_id", referencedColumnName = "id")
    private Season season;

    @ManyToOne
    @JoinColumn(name = "reward_item_id", referencedColumnName = "id")
    private Item rewardItem;

    @OneToMany(mappedBy = "challenge", cascade = CascadeType.ALL)
    @JsonIgnore
    private Set<UserChallenge> userChallenges;
}
