package com.wafferha.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;





@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "daily_questions")
public class DailyQuestion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String question;

    
    @Column(columnDefinition = "TEXT", nullable = false)
    private String options;

    @Column(name = "correct_answer", nullable = false, length = 255)
    private String correctAnswer;

    @Column(columnDefinition = "TEXT")
    private String explanation;

    @Column(name = "reward_points", nullable = false)
    private int rewardPoints = 10;

    @Column(name = "question_date", nullable = false)
    private LocalDate questionDate;

    @Column(nullable = false)
    private boolean answered = false;

    @Column(name = "answered_correctly", nullable = false)
    private boolean answeredCorrectly = false;

    @PrePersist
    void onCreate() {
        if (questionDate == null) {
            questionDate = LocalDate.now();
        }
    }
}
