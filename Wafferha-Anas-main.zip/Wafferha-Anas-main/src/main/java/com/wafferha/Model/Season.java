package com.wafferha.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Season {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "varchar(30) not null")
    private String seasonType;

    @Column(columnDefinition = "varchar(50) not null")
    private String name;

    @Column(columnDefinition = "varchar(50)")
    private String theme;

    @Column(name = "season_year", nullable = false)
    private Integer year;

    private LocalDateTime startAt;

    private LocalDateTime endAt;

    private LocalDateTime pointsExpireAt;

    @Column(columnDefinition = "varchar(20) not null")
    private String status;

    @OneToMany(mappedBy = "season", cascade = CascadeType.ALL)
    @JsonIgnore
    private Set<Item> items;

    @OneToMany(mappedBy = "season", cascade = CascadeType.ALL)
    @JsonIgnore
    private Set<Challenge> challenges;
}
