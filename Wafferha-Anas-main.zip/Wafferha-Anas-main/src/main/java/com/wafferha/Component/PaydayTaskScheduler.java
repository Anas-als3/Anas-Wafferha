package com.wafferha.Component;

import com.wafferha.Service.NotificationService;
import java.time.LocalDate;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;








@Component
@RequiredArgsConstructor
public class PaydayTaskScheduler {

    private static final Logger log = LoggerFactory.getLogger(PaydayTaskScheduler.class);

    private final NotificationService notificationService;

    
    @Scheduled(cron = "0 30 8 * * *")
    public void generateTodaysPaydayTasks() {
        try {
            int today = LocalDate.now().getDayOfMonth();
            notificationService.generateForPaydayDay(today);
        } catch (Exception e) {
            log.warn("Payday-task scheduler run failed: {}", e.getMessage());
        }
    }
}
