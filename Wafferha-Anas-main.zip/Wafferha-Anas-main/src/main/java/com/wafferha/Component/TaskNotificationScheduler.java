package com.wafferha.Component;

import com.wafferha.Service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;









@Component
@RequiredArgsConstructor
public class TaskNotificationScheduler {

    private static final Logger log = LoggerFactory.getLogger(TaskNotificationScheduler.class);

    private final NotificationService notificationService;

    
    @Scheduled(cron = "0 0 8 * * *")
    public void daily() {
        run("DAILY");
    }

    
    @Scheduled(cron = "0 0 9 * * MON")
    public void weekly() {
        run("WEEKLY");
    }

    
    @Scheduled(cron = "0 0 9 1 * *")
    public void monthly() {
        run("MONTHLY");
    }

    
    @Scheduled(cron = "0 0 9 1 1 *")
    public void yearly() {
        run("YEARLY");
    }

    private void run(String cadence) {
        try {
            notificationService.notifyAllForCadence(cadence);
        } catch (Exception e) {
            log.warn("{} task-notification run failed: {}", cadence, e.getMessage());
        }
    }
}
