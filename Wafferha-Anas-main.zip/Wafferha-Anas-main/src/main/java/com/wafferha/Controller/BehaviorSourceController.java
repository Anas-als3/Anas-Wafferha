package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.BehaviorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/behavior-sources")
@RequiredArgsConstructor
public class BehaviorSourceController {

    private final BehaviorService behaviorService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(behaviorService.getAllSources());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(behaviorService.getSourceById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUserId(@PathVariable Integer userId) {
        return ResponseEntity.ok(behaviorService.getSourcesByUser(userId));
    }

    
    @PutMapping("/{sourceId}/detect-salary")
    public ResponseEntity<?> detectSalary(@PathVariable Integer sourceId) {
        return ResponseEntity.ok(ApiResponse.flat("Salary detected on source", behaviorService.detectSalary(sourceId)));
    }
}
