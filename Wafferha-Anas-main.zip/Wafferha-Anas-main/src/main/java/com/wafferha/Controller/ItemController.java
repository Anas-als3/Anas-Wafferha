package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.ItemInDTO;
import com.wafferha.Service.AdminService;
import com.wafferha.Service.ItemService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/item")
@RequiredArgsConstructor
public class ItemController {

    private final ItemService itemService;
    private final AdminService adminService;

    @GetMapping("/get")
    public ResponseEntity<?> getAllItems() {
        return ResponseEntity.status(200)
                .body(itemService.getAllItems());
    }

    @GetMapping("/season/{seasonId}")
    public ResponseEntity<?> getItemsBySeason(@PathVariable Integer seasonId) {
        return ResponseEntity.status(200)
                .body(itemService.getItemsBySeason(seasonId));
    }

    @GetMapping("/filter")
    public ResponseEntity<?> filterItems(@RequestParam(required = false) String currencyType,
                                                   @RequestParam(required = false) Integer seasonId,
                                                   @RequestParam(required = false) Double maxCost) {
        return ResponseEntity.status(200)
                .body(itemService.filter(currencyType, seasonId, maxCost));
    }

    @PostMapping("/add/{seasonId}/{adminId}")
    public ResponseEntity<?> addItem(@PathVariable Integer seasonId,
                                               @PathVariable Integer adminId,
                                               @RequestBody @Valid ItemInDTO item) {

        adminService.requireAdmin(adminId);
        itemService.addItem(seasonId, item);

        return ResponseEntity.status(200).body(ApiResponse.flat("Item added", null));
    }
}
