package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.EconomicContextInDTO;
import com.wafferha.Service.EconomicContextService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/economic-context")
@RequiredArgsConstructor
public class EconomicContextController {

    private final EconomicContextService economicContextService;

    
    @GetMapping
    public ResponseEntity<?> getCurrent() {
        return ResponseEntity.ok(economicContextService.getCurrentDto());
    }

    
    @PutMapping
    public ResponseEntity<?> update(@RequestBody @Valid EconomicContextInDTO body) {
        return ResponseEntity.ok(
                ApiResponse.flat("Economic context updated successfully", economicContextService.update(body)));
    }
}
