package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.LeaderBoardInDTO;
import com.wafferha.Service.LeaderBoardService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/leaderBoard")
@RequiredArgsConstructor
public class LeaderBoardController {

    private final LeaderBoardService leaderBoardService;

    @PostMapping("/{leagueId}")
    public ResponseEntity<?> addLeaderBoard(@PathVariable Integer leagueId, @RequestBody @Valid LeaderBoardInDTO leaderboard) {
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("LeaderBoard added successfully", leaderBoardService.addLeaderboard(leagueId, leaderboard)));
    }

    @GetMapping
    public ResponseEntity<?> getLeaderBoards() {
        return ResponseEntity.status(200)
                .body(leaderBoardService.getLeaderBoards());
    }

    @GetMapping("/league/{leagueId}")
    public ResponseEntity<?> getLeaderBoardsByLeague(@PathVariable Integer leagueId) {
        return ResponseEntity.status(200)
                .body(leaderBoardService.getLeaderBoardsByLeague(leagueId));
    }

    @GetMapping("/{boardId}/top")
    public ResponseEntity<?> getTopEntries(@PathVariable Integer boardId,
                                                     @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.status(200)
                .body(leaderBoardService.getTopEntries(boardId, limit));
    }
}
