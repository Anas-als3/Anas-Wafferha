package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.LeagueService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;






@RestController
@RequestMapping("/api/v1/leagues")
@RequiredArgsConstructor
public class LeagueAssignmentController {

    private final LeagueService leagueService;

    @PostMapping("/assign/{userId}")
    public ResponseEntity<?> assignLeague(@PathVariable Integer userId) {
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("League assigned", leagueService.assignLeague(userId)));
    }
}
