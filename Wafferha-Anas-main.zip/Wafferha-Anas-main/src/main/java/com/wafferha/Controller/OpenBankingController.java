package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.OpenBankingService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping("/api/v1/open-banking")
@RequiredArgsConstructor
public class OpenBankingController {

    private final OpenBankingService openBankingService;

    
    @PostMapping("/link/{userId}")
    public ResponseEntity<?> link(@PathVariable Integer userId) {
        Map<String, Object> result = openBankingService.linkAccount(userId);
        return ResponseEntity.ok(ApiResponse.flat("Open banking link", result));
    }

    
    @PostMapping("/import/{userId}")
    public ResponseEntity<?> importTransactions(@PathVariable Integer userId) {
        Map<String, Object> result = openBankingService.importTransactions(userId);
        return ResponseEntity.ok(ApiResponse.flat("Open banking import", result));
    }
}
