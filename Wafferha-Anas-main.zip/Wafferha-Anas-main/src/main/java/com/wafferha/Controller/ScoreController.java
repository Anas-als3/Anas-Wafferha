package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.ScoreService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/scores")
@RequiredArgsConstructor
public class ScoreController {

    private final ScoreService scoreService;

    
    @GetMapping("/cap-status/{userId}")
    public ResponseEntity<?> capStatus(@PathVariable Integer userId) {
        return ResponseEntity.ok(scoreService.capStatus(userId));
    }

    
    @PostMapping("/compute/{userId}")
    public ResponseEntity<?> compute(@PathVariable Integer userId,
                                               @RequestParam(defaultValue = "MONTHLY") String period) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.flat("Score computed successfully", scoreService.computeForUser(userId, period)));
    }

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(scoreService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(scoreService.getById(id));
    }

    
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUserId(@PathVariable Integer userId) {
        return ResponseEntity.ok(scoreService.getByUserId(userId));
    }

    
    @GetMapping("/user/{userId}/latest")
    public ResponseEntity<?> getLatestForUser(@PathVariable Integer userId,
                                                        @RequestParam(required = false) String period) {
        return ResponseEntity.ok(scoreService.getLatestForUser(userId, period));
    }

    
    @GetMapping("/filter")
    public ResponseEntity<?> filter(@RequestParam(required = false) String period,
                                              @RequestParam(required = false) Double minScore,
                                              @RequestParam(required = false) Integer leagueId) {
        return ResponseEntity.ok(scoreService.filter(period, minScore, leagueId));
    }
}
