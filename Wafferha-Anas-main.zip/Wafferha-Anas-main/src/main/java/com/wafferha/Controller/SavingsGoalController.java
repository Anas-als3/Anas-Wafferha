package com.wafferha.Controller;

import com.wafferha.Api.ApiException;
import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.SavingsGoalInDTO;
import com.wafferha.DTO.Out.SavingsGoalOutDTO;
import com.wafferha.Model.PendingGoalAdjustment;
import com.wafferha.Model.SavingsGoal;
import com.wafferha.Service.GoalService;
import jakarta.validation.Valid;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/savings-goals")
@RequiredArgsConstructor
public class SavingsGoalController {

    private final GoalService goalService;

    




    @PostMapping("/{userId}")
    public ResponseEntity<?> create(@PathVariable Integer userId, @RequestBody @Valid SavingsGoalInDTO body) {
        SavingsGoalOutDTO goal = goalService.createGoal(userId, body);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.flat("Savings goal created with a save plan", goal));
    }

    
    @GetMapping("/{userId}")
    public ResponseEntity<?> getForUser(@PathVariable Integer userId) {
        return ResponseEntity.ok(goalService.getForUser(userId));
    }

    
    @GetMapping("/user/{userId}/filter")
    public ResponseEntity<?> filterForUser(@PathVariable Integer userId,
                                                     @RequestParam(required = false) String status) {
        return ResponseEntity.ok(goalService.filterForUser(userId, status));
    }

    
    @PostMapping("/{goalId}/recalculate")
    public ResponseEntity<?> recalculate(@PathVariable Integer goalId) {
        return ResponseEntity.ok(ApiResponse.flat("Savings goal recalculated", goalService.recalculate(goalId)));
    }

    
    @PostMapping("/{goalId}/progress")
    public ResponseEntity<?> addProgress(@PathVariable Integer goalId, @RequestBody Map<String, Object> body) {
        double amount = asDouble(body.get("amount"), "amount");
        SavingsGoalOutDTO goal = goalService.addProgress(goalId, amount);
        String msg = "COMPLETED".equals(goal.getStatus()) ? "Goal reached!" : "Progress updated";
        return ResponseEntity.ok(ApiResponse.flat(msg, goal));
    }

    




    @PostMapping("/{goalId}/check-behind")
    public ResponseEntity<?> checkBehind(@PathVariable Integer goalId) {
        PendingGoalAdjustment pending = goalService.checkBehind(goalId);
        if (pending == null) {
            return ResponseEntity.ok(ApiResponse.flat("Goal is on track - no adjustment needed", null));
        }
        return ResponseEntity.ok(ApiResponse.flat("Goal is behind - WhatsApp prompt sent", pending));
    }

    





    @PostMapping("/{goalId}/simulate-behind")
    public ResponseEntity<?> simulateBehind(@PathVariable Integer goalId) {
        PendingGoalAdjustment pending = goalService.simulateBehind(goalId);
        if (pending == null) {
            return ResponseEntity.ok(ApiResponse.flat("Goal could not be made behind (already complete?)", null));
        }
        return ResponseEntity.ok(ApiResponse.flat(
                "Goal is now behind - WhatsApp prompt sent (reply 1 to extend the deadline, or 2 to add the shortfall)", pending));
    }

    



    @PostMapping("/{goalId}/adjust/{choice}")
    public ResponseEntity<?> adjust(@PathVariable Integer goalId, @PathVariable String choice) {
        String c = choice == null ? "" : choice.trim().toLowerCase();
        SavingsGoal goal;
        String msg;
        switch (c) {
            case "extend":
            case "1":
                goal = goalService.applyExtend(goalId);
                msg = "Goal deadline extended";
                break;
            case "redistribute":
            case "add":
            case "2":
                goal = goalService.applyRedistribute(goalId);
                msg = "Shortfall redistributed to upcoming periods";
                break;
            default:
                throw new ApiException("choice must be 'extend' (1) or 'redistribute' (2)");
        }
        return ResponseEntity.ok(ApiResponse.flat(msg, goal));
    }

    private double asDouble(Object value, String field) {
        if (value instanceof Number number) {
            return number.doubleValue();
        }
        try {
            return Double.parseDouble(String.valueOf(value));
        } catch (NumberFormatException e) {
            throw new ApiException(field + " must be a number");
        }
    }
}
