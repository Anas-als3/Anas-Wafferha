package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.UserRewardInDTO;
import com.wafferha.Service.UserRewardService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/user-reward")
@RequiredArgsConstructor
public class UserRewardController {

    private final UserRewardService userRewardService;

    @GetMapping("/get")
    public ResponseEntity<?> getAllUserRewards() {
        return ResponseEntity.status(200)
                .body(userRewardService.getAllUserRewards());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserRewardsByUser(@PathVariable Integer userId) {
        return ResponseEntity.status(200)
                .body(userRewardService.getUserRewardsByUser(userId));
    }

    @GetMapping("/user/{userId}/filter")
    public ResponseEntity<?> filterUserRewardsByUser(@PathVariable Integer userId,
                                                               @RequestParam(required = false) Boolean equipped) {
        return ResponseEntity.status(200)
                .body(userRewardService.filterByUser(userId, equipped));
    }

    @PutMapping("/{rewardId}/equip")
    public ResponseEntity<?> equip(@PathVariable Integer rewardId,
                                             @RequestParam(defaultValue = "true") boolean equipped) {
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("Coupon marked as used", userRewardService.equip(rewardId, equipped)));
    }

    
    @PutMapping("/user/{userId}/item/{itemId}/equip")
    public ResponseEntity<?> equipByUserItem(@PathVariable Integer userId,
                                                       @PathVariable Integer itemId,
                                                       @RequestParam(defaultValue = "true") boolean equipped) {
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("Coupon marked as used",
                        userRewardService.equipByUserAndItem(userId, itemId, equipped)));
    }

    @GetMapping("/season/{seasonId}")
    public ResponseEntity<?> getUserRewardsBySeason(@PathVariable Integer seasonId) {
        return ResponseEntity.status(200)
                .body(userRewardService.getUserRewardsBySeason(seasonId));
    }

    @PostMapping("/add/{userId}/{itemId}/{seasonId}")
    public ResponseEntity<?> addUserReward(@PathVariable Integer userId, @PathVariable Integer itemId, @PathVariable Integer seasonId,
                                                     @RequestBody @Valid UserRewardInDTO userReward) {

        return ResponseEntity.status(200)
                .body(ApiResponse.flat("UserReward added", userRewardService.addUserReward(userId, itemId, seasonId, userReward)));
    }
}
