package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.BehaviorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/behavior")
@RequiredArgsConstructor
public class BehaviorIngestionController {

    private final BehaviorService behaviorService;

    




    @PostMapping("/recompute/{userId}")
    public ResponseEntity<?> recompute(@PathVariable Integer userId) {
        return ResponseEntity.ok(
                ApiResponse.flat("Behavior recomputed", behaviorService.recompute(userId)));
    }
}
