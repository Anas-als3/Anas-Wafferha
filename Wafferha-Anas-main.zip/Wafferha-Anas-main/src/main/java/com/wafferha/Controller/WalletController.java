package com.wafferha.Controller;

import com.wafferha.Service.WalletService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/wallets")
@RequiredArgsConstructor
public class WalletController {

    private final WalletService walletService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(walletService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(walletService.getById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUser(@PathVariable Integer userId) {
        return ResponseEntity.ok(walletService.getByUser(userId));
    }

    
    @GetMapping("/user/{userId}/summary")
    public ResponseEntity<?> pointsSummary(@PathVariable Integer userId) {
        return ResponseEntity.ok(walletService.pointsSummary(userId));
    }
}
