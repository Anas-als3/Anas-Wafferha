package com.wafferha.Controller;

import com.wafferha.Service.SeasonalWalletService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/seasonal-wallets")
@RequiredArgsConstructor
public class SeasonalWalletController {

    private final SeasonalWalletService seasonalWalletService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(seasonalWalletService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(seasonalWalletService.getById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUser(@PathVariable Integer userId) {
        return ResponseEntity.ok(seasonalWalletService.getByUser(userId));
    }

    @GetMapping("/season/{seasonId}")
    public ResponseEntity<?> getBySeason(@PathVariable Integer seasonId) {
        return ResponseEntity.ok(seasonalWalletService.getBySeason(seasonId));
    }
}
