package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.ResetJobService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping("/api/v1/admin/reset")
@RequiredArgsConstructor
public class AdminResetController {

    private final ResetJobService resetJobService;

    
    @PostMapping("/yearly")
    public ResponseEntity<?> resetYearly() {
        int expired = resetJobService.runYearlyReset();
        return ResponseEntity.ok(
                ApiResponse.flat("Yearly reset complete", Map.of("walletsExpired", expired)));
    }

    
    @PostMapping("/seasonal")
    public ResponseEntity<?> resetSeasonal() {
        int expired = resetJobService.runSeasonalReset();
        return ResponseEntity.ok(
                ApiResponse.flat("Seasonal reset complete", Map.of("seasonalWalletsExpired", expired)));
    }
}
