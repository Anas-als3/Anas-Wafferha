package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Model.Challenge;
import com.wafferha.Model.DailyQuestion;
import com.wafferha.Model.Insight;
import com.wafferha.Model.UserChallenge;
import com.wafferha.Service.AiTaskService;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/ai")
@RequiredArgsConstructor
public class AiController {

    private final AiTaskService aiTaskService;

    
    @PostMapping("/tasks/{userId}")
    public ResponseEntity<?> generateTask(@PathVariable Integer userId) {
        UserChallenge task = aiTaskService.generateTaskForUser(userId);
        
        
        Challenge ch = task.getChallenge();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", "Task generated");
        body.put("taskId", task.getId());
        body.put("status", task.getStatus());
        if (ch != null) {
            body.put("title", ch.getTitle());
            body.put("type", ch.getType());
            body.put("cadence", ch.getCadence());
            body.put("targetValue", ch.getTargetValue());
            body.put("rewardPoints", ch.getRewardPoints());
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(body);
    }

    
    @PostMapping("/users/{userId}/tasks/{userChallengeId}/complete")
    public ResponseEntity<?> completeUserTask(@PathVariable Integer userId,
                                                        @PathVariable Integer userChallengeId) {
        UserChallenge task = aiTaskService.completeTaskForUser(userId, userChallengeId);
        
        Challenge ch = task.getChallenge();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", "Task completed and points awarded");
        body.put("taskId", task.getId());
        body.put("status", task.getStatus());
        if (ch != null) {
            body.put("title", ch.getTitle());
            body.put("pointsEarned", ch.getRewardPoints());
        }
        return ResponseEntity.ok(body);
    }

    
    @PostMapping("/payday-task/{userId}")
    public ResponseEntity<?> generatePaydayTask(@PathVariable Integer userId) {
        UserChallenge task = aiTaskService.generatePaydayTask(userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.flat("Payday task generated", task));
    }

    
    @PostMapping("/daily-question/{userId}")
    public ResponseEntity<?> generateDailyQuestion(@PathVariable Integer userId) {
        DailyQuestion question = aiTaskService.generateDailyQuestion(userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.flat("Daily question generated", question));
    }

    
    @PostMapping("/insights/{userId}/generate")
    public ResponseEntity<?> generateInsight(@PathVariable Integer userId) {
        Insight insight = aiTaskService.generateInsight(userId);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.flat("Insight generated", insight));
    }

    
    @PostMapping("/daily-question/{dailyQuestionId}/answer")
    public ResponseEntity<?> answerDailyQuestion(
            @PathVariable Integer dailyQuestionId,
            @RequestBody(required = false) Map<String, String> body) {
        String answer = body == null ? null : body.get("answer");
        DailyQuestion question = aiTaskService.answerDailyQuestion(dailyQuestionId, answer);
        String msg = question.isAnsweredCorrectly() ? "Correct! Points awarded" : "Incorrect answer, no points";
        return ResponseEntity.ok(ApiResponse.flat(msg, question));
    }
}
