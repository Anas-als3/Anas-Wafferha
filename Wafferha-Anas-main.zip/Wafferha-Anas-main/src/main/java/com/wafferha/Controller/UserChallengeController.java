package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.EngagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/user-challenge")
@RequiredArgsConstructor
public class UserChallengeController {

    private final EngagementService engagementService;

    @GetMapping("/get")
    public ResponseEntity<?> getAllUserChallenges() {
        return ResponseEntity.status(200)
                .body(engagementService.getAllUserChallenges());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserChallengesByUser(@PathVariable Integer userId) {
        return ResponseEntity.status(200)
                .body(engagementService.getUserChallengesByUser(userId));
    }

    @GetMapping("/user/{userId}/filter")
    public ResponseEntity<?> filterUserChallengesByUser(@PathVariable Integer userId,
                                                                  @RequestParam(required = false) String status) {
        return ResponseEntity.status(200)
                .body(engagementService.filterByUser(userId, status));
    }

    @PutMapping("/{id}/progress")
    public ResponseEntity<?> addProgress(@PathVariable Integer id, @RequestParam double amount) {
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("UserChallenge progress updated",
                        engagementService.addProgress(id, amount)));
    }

    @PostMapping("/add/{userId}/{challengeId}")
    public ResponseEntity<?> addUserChallenge(
            @PathVariable Integer userId,
            @PathVariable Integer challengeId) {

        engagementService.addUserChallenge(userId, challengeId);

        return ResponseEntity.status(200)
                .body(ApiResponse.flat("User joined challenge", null));
    }
}
