package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.GoalService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/financial-progress")
@RequiredArgsConstructor
public class FinancialProgressController {

    private final GoalService goalService;

    
    
    @PostMapping("/recompute/{userId}")
    public ResponseEntity<?> recompute(@PathVariable Integer userId) {
        return ResponseEntity.ok(ApiResponse.flat("Financial progress recomputed", goalService.recompute(userId)));
    }

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(goalService.getAllFinancialProgress());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(goalService.getFinancialProgressById(id));
    }

    
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUserId(@PathVariable Integer userId) {
        return ResponseEntity.ok(goalService.getFinancialProgressByUser(userId));
    }
}
