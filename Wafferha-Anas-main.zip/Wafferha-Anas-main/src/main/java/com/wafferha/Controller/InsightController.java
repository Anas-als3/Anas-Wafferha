package com.wafferha.Controller;

import com.wafferha.Service.AiTaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/insights")
@RequiredArgsConstructor
public class InsightController {

    private final AiTaskService aiTaskService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(aiTaskService.getAllInsights());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(aiTaskService.getInsightById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUserId(@PathVariable Integer userId) {
        return ResponseEntity.ok(aiTaskService.getInsightsByUser(userId));
    }

    @GetMapping("/user/{userId}/filter")
    public ResponseEntity<?> filterByUser(@PathVariable Integer userId,
                                                    @RequestParam(required = false) String type) {
        return ResponseEntity.ok(aiTaskService.filterInsightsByUser(userId, type));
    }
}
