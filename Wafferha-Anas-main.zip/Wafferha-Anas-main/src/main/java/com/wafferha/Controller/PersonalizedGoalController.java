package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.PersonalizedGoalInDTO;
import com.wafferha.Service.GoalService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping({"/api/v1/personalized-goal", "/api/v1/personalized-goals"})
@RequiredArgsConstructor
public class PersonalizedGoalController {

    private final GoalService goalService;

    




    @PostMapping("/generate/{userId}")
    public ResponseEntity<?> generatePersonalizedGoal(
            @PathVariable Integer userId,
            @RequestParam(name = "period", required = false, defaultValue = "MONTHLY") String period) {

        return ResponseEntity.status(201)
                .body(ApiResponse.flat("PersonalizedGoal generated", goalService.generate(userId, period)));
    }

    @GetMapping("/get")
    public ResponseEntity<?> getAllPersonalizedGoals() {

        return ResponseEntity.status(200)
                .body(goalService.getAllPersonalizedGoals());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getPersonalizedGoalsByUser(@PathVariable Integer userId) {

        return ResponseEntity.status(200)
                .body(goalService.getPersonalizedGoalsByUser(userId));
    }

    
    @PostMapping("/{id}/accept")
    public ResponseEntity<?> acceptPersonalizedGoal(@PathVariable Integer id) {

        return ResponseEntity.status(200)
                .body(ApiResponse.flat("PersonalizedGoal accepted", goalService.accept(id)));
    }

    @PostMapping("/add/{userId}")
    public ResponseEntity<?> addPersonalizedGoal(
            @PathVariable Integer userId,
            @RequestBody @Valid PersonalizedGoalInDTO personalizedGoal) {

        return ResponseEntity.status(200)
                .body(ApiResponse.flat("PersonalizedGoal added", goalService.addPersonalizedGoal(userId, personalizedGoal)));
    }
}
