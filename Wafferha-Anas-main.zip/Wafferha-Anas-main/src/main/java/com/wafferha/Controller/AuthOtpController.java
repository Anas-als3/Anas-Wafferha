package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.OtpVerifyInDTO;
import com.wafferha.Service.OtpService;
import jakarta.validation.Valid;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth/otp")
@RequiredArgsConstructor
public class AuthOtpController {

    private final OtpService otpService;

    @PostMapping("/send/{userId}")
    public ResponseEntity<?> send(@PathVariable Integer userId) {
        boolean sent = otpService.sendOtp(userId);
        String message = sent
                ? "OTP sent successfully"
                : "OTP generated but WhatsApp delivery is unavailable";
        return ResponseEntity.ok(ApiResponse.flat(message, sent));
    }

    @PostMapping("/verify/{userId}")
    public ResponseEntity<?> verify(@PathVariable Integer userId,
                                              @RequestBody @Valid OtpVerifyInDTO request) {
        boolean valid = otpService.verifyAndActivate(userId, request.getCode());
        String message = valid ? "OTP verified - phone confirmed" : "Invalid or expired OTP";
        return ResponseEntity.ok(ApiResponse.flat(message, valid));
    }

    



    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = otpService.register(
                str(body, "name"), str(body, "phoneNumber"), str(body, "email"), intOrNull(body, "monthlyIncome"));
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.flat("User registered - please verify your phone with the OTP.", result));
    }

    private String str(Map<String, Object> body, String key) {
        Object v = body == null ? null : body.get(key);
        return v == null ? null : String.valueOf(v);
    }

    private Integer intOrNull(Map<String, Object> body, String key) {
        Object v = body == null ? null : body.get(key);
        if (v instanceof Number number) {
            return number.intValue();
        }
        try {
            return v == null ? null : Integer.parseInt(String.valueOf(v).trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
