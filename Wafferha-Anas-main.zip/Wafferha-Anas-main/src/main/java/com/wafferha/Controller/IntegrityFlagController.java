package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.IntegrityFlagInDTO;
import com.wafferha.Service.IntegrityFlagService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/integrity-flag")
@RequiredArgsConstructor
public class IntegrityFlagController {

    private final IntegrityFlagService integrityFlagService;

    @GetMapping("/get")
    public ResponseEntity<?> getAllIntegrityFlags() {

        return ResponseEntity.status(200)
                .body(integrityFlagService.getAllIntegrityFlags());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getIntegrityFlagByUser(@PathVariable Integer userId) {

        return ResponseEntity.status(200)
                .body(integrityFlagService.getIntegrityFlagByUser(userId));
    }

    @GetMapping("/filter")
    public ResponseEntity<?> filterIntegrityFlags(@RequestParam(required = false) Boolean eligible) {

        return ResponseEntity.status(200)
                .body(integrityFlagService.filter(eligible));
    }

    
    @PostMapping("/{userId}/evaluate")
    public ResponseEntity<?> evaluateIntegrityFlag(@PathVariable Integer userId) {

        return ResponseEntity.status(200)
                .body(ApiResponse.flat("IntegrityFlag evaluated", integrityFlagService.evaluate(userId)));
    }

    @PostMapping("/add/{userId}")
    public ResponseEntity<?> addIntegrityFlag(
            @PathVariable Integer userId,
            @RequestBody @Valid IntegrityFlagInDTO integrityFlag) {

        return ResponseEntity.status(200)
                .body(ApiResponse.flat("IntegrityFlag added", integrityFlagService.addIntegrityFlag(userId, integrityFlag)));
    }
}
