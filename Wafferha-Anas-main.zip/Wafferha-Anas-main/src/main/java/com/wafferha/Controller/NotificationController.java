package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    




    @PostMapping("/encourage/{userId}")
    public ResponseEntity<?> encourage(@PathVariable Integer userId) {
        notificationService.encourage(userId);
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("Encouragement notification sent", null));
    }

    




    @PostMapping("/account-verified/{userId}")
    public ResponseEntity<?> accountVerified(@PathVariable Integer userId) {
        notificationService.sendAccountVerified(userId);
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("Account-verified notification sent", null));
    }
}
