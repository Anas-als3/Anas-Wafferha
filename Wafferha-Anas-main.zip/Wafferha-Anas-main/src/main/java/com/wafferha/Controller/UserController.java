package com.wafferha.Controller;

import com.wafferha.Api.ApiException;
import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.UserInDTO;
import com.wafferha.DTO.Out.UserOutDTO;
import com.wafferha.Service.UserService;
import jakarta.validation.Valid;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    public ResponseEntity<?> create(@RequestBody @Valid UserInDTO user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.flat("User added successfully", userService.create(user)));
    }

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(userService.getAll());
    }

    
    @GetMapping("/{id}")
    public ResponseEntity<UserOutDTO> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(userService.getById(id));
    }

    @GetMapping("/league/{leagueId}")
    public ResponseEntity<?> getByLeague(@PathVariable Integer leagueId) {
        return ResponseEntity.ok(userService.getByLeague(leagueId));
    }

    



    @PostMapping("/{userId}/onboard")
    public ResponseEntity<?> onboard(@PathVariable Integer userId,
                                     @RequestBody(required = false) Map<String, Object> body) {
        
        
        Object raw = body == null ? null : body.get("monthlyIncome");
        Integer monthlyIncome = null;
        if (raw != null) {
            if (raw instanceof Number number) {
                monthlyIncome = number.intValue();
            } else {
                try {
                    monthlyIncome = Integer.parseInt(String.valueOf(raw).trim());
                } catch (NumberFormatException e) {
                    throw new ApiException("monthlyIncome must be an integer");
                }
            }
        }
        return ResponseEntity.ok(ApiResponse.flat("User onboarded", userService.onboard(userId, monthlyIncome)));
    }

    
    @PutMapping("/{userId}/opt-in")
    public ResponseEntity<?> optIn(@PathVariable Integer userId,
                                             @RequestParam(defaultValue = "true") boolean optIn) {
        return ResponseEntity.ok(ApiResponse.flat("Competitive opt-in updated", userService.setCompetitiveOptIn(userId, optIn)));
    }

}
