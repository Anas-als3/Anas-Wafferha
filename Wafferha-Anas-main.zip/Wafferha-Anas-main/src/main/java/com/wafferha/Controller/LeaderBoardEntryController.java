package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.LeaderBoardEntryInDTO;
import com.wafferha.Service.LeaderBoardService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/leaderBoardEntry")
@RequiredArgsConstructor
public class LeaderBoardEntryController {

    private final LeaderBoardService leaderBoardService;

    @PostMapping("/{userId}/{leaderboardId}")
    public ResponseEntity<?> addEntry(@PathVariable Integer userId, @PathVariable Integer leaderboardId,
                                                @RequestBody @Valid LeaderBoardEntryInDTO entry) {
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("Entry added successfully", leaderBoardService.addEntry(userId, leaderboardId, entry)));
    }

    @GetMapping
    public ResponseEntity<?> getEntries() {
        return ResponseEntity.status(200)
                .body(leaderBoardService.getEntries());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getEntriesByUser(@PathVariable Integer userId) {
        return ResponseEntity.status(200)
                .body(leaderBoardService.getEntriesByUser(userId));
    }

    @GetMapping("/user/{userId}/rank")
    public ResponseEntity<?> getUserRank(@PathVariable Integer userId,
                                                   @RequestParam(required = false) String period) {
        return ResponseEntity.status(200)
                .body(leaderBoardService.getUserRank(userId, period));
    }

    @GetMapping("/leaderboard/{id}")
    public ResponseEntity<?> getEntriesByLeaderboard(@PathVariable Integer id) {
        return ResponseEntity.status(200)
                .body(leaderBoardService.getEntriesByLeaderboard(id));
    }
}
