package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.NotificationService;
import java.time.LocalDate;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping("/api/v1/payday-tasks")
@RequiredArgsConstructor
public class PaydayTaskController {

    private final NotificationService notificationService;

    



    @PostMapping("/run")
    public ResponseEntity<?> run(@RequestParam(required = false) Integer day) {
        int target = day != null ? day : LocalDate.now().getDayOfMonth();
        int created = notificationService.generateForPaydayDay(target);
        return ResponseEntity.ok(ApiResponse.flat(
                "Generated " + created + " payday task(s) for payday day " + target,
                Map.of("paydayDay", target, "tasksGenerated", created)));
    }
}
