package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.ChallengeInDTO;
import com.wafferha.Service.AdminService;
import com.wafferha.Service.EngagementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/challenge")
@RequiredArgsConstructor
public class ChallengeController {

    private final EngagementService engagementService;
    private final AdminService adminService;

    @GetMapping("/get")
    public ResponseEntity<?> getAllChallenges() {
        return ResponseEntity.status(200)
                .body(engagementService.getAllChallenges());
    }

    @GetMapping("/season/{seasonId}")
    public ResponseEntity<?> getChallengesBySeason(@PathVariable Integer seasonId) {
        return ResponseEntity.status(200)
                .body(engagementService.getChallengesBySeason(seasonId));
    }

    @GetMapping("/active")
    public ResponseEntity<?> getActiveChallenges(@RequestParam(required = false) Integer seasonId) {
        return ResponseEntity.status(200)
                .body(engagementService.getActive(seasonId));
    }

    @PostMapping("/add/{seasonId}/{itemId}/{adminId}")
    public ResponseEntity<?> addChallenge(@PathVariable Integer seasonId,
                                                    @PathVariable Integer itemId,
                                                    @PathVariable Integer adminId,
                                                    @RequestBody @Valid ChallengeInDTO challenge) {

        adminService.requireAdmin(adminId);
        engagementService.addChallenge(seasonId, itemId, challenge);
        return ResponseEntity.status(200).body(ApiResponse.flat("Challenge added", null));
    }
}
