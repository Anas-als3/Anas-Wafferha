package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.AdminService;
import com.wafferha.Service.LeaderBoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;







@RestController
@RequestMapping("/api/v1/leaderboards")
@RequiredArgsConstructor
public class LeaderBoardBuildController {

    private final LeaderBoardService leaderBoardService;
    private final AdminService adminService;

    
    @PostMapping("/build/{leagueId}/{adminId}")
    public ResponseEntity<?> buildForLeague(@PathVariable Integer leagueId,
                                                      @PathVariable Integer adminId,
                                                      @RequestParam(defaultValue = "MONTHLY") String period) {
        adminService.requireAdmin(adminId);
        return ResponseEntity.ok(
                ApiResponse.flat("LeaderBoard built successfully", leaderBoardService.buildForLeague(leagueId, period)));
    }
}
