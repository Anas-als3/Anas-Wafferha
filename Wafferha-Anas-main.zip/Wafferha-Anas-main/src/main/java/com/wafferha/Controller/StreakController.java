package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.EngagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/streaks")
@RequiredArgsConstructor
public class StreakController {

    private final EngagementService engagementService;

    
    
    @PostMapping("/record/{userId}/{type}")
    public ResponseEntity<?> recordActivity(@PathVariable Integer userId, @PathVariable String type) {
        return ResponseEntity.ok(ApiResponse.flat("Streak activity recorded", engagementService.recordActivity(userId, type)));
    }

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(engagementService.getAllStreaks());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(engagementService.getStreakById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUserId(@PathVariable Integer userId) {
        return ResponseEntity.ok(engagementService.getStreaksByUser(userId));
    }

    
    @PutMapping("/{id}/use-freeze")
    public ResponseEntity<?> useFreeze(@PathVariable Integer id) {
        return ResponseEntity.ok(ApiResponse.flat("Freeze used", engagementService.useFreeze(id)));
    }
}
