package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Model.BehaviorEvent;
import com.wafferha.Service.BehaviorService;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/behavior-events")
@RequiredArgsConstructor
public class BehaviorEventController {

    private final BehaviorService behaviorService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(behaviorService.getAllEvents());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(behaviorService.getEventById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUserId(@PathVariable Integer userId) {
        return ResponseEntity.ok(behaviorService.getEventsByUser(userId));
    }

    



    @PostMapping("/ingest/{userId}")
    public ResponseEntity<?> ingest(@PathVariable Integer userId, @RequestBody List<BehaviorEvent> events) {
        int count = behaviorService.ingest(userId, events);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("ingested", count);
        return ResponseEntity.ok(ApiResponse.flat("Behavior events ingested", result));
    }

    
    @GetMapping("/user/{userId}/filter")
    public ResponseEntity<?> filterByUser(
            @PathVariable Integer userId,
            @RequestParam(required = false) String direction,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        return ResponseEntity.ok(behaviorService.filterForUser(userId, direction, category, from, to));
    }

    
    @GetMapping("/user/{userId}/summary")
    public ResponseEntity<?> spendingSummary(@PathVariable Integer userId) {
        return ResponseEntity.ok(behaviorService.spendingSummary(userId));
    }
}
