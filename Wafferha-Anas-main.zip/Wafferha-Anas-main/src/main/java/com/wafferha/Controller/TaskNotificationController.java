package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.NotificationService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;






@RestController
@RequestMapping("/api/v1/notifications/tasks")
@RequiredArgsConstructor
public class TaskNotificationController {

    private final NotificationService notificationService;

    
    @PostMapping("/{cadence}")
    public ResponseEntity<?> notifyAll(@PathVariable String cadence) {
        Map<String, Object> summary = notificationService.notifyAllForCadence(cadence);
        return ResponseEntity.ok(ApiResponse.flat("Task reminders processed", summary));
    }

    
    @PostMapping("/{cadence}/user/{userId}")
    public ResponseEntity<?> notifyUser(@PathVariable String cadence, @PathVariable Integer userId) {
        Map<String, Object> summary = notificationService.notifyUserForCadence(userId, cadence);
        return ResponseEntity.ok(ApiResponse.flat("Task reminder processed", summary));
    }
}
