package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.Service.ShopService;
import com.wafferha.Service.UserRewardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/shop")
@RequiredArgsConstructor
public class ShopController {

    private final ShopService shopService;
    private final UserRewardService userRewardService;

    
    
    @PostMapping("/{userId}/buy/{itemId}")
    public ResponseEntity<?> buy(@PathVariable Integer userId, @PathVariable Integer itemId) {
        return ResponseEntity.ok(
                ApiResponse.flat("Item purchased",
                        userRewardService.fromEntity(shopService.buyItem(userId, itemId))));
    }

    
    @GetMapping("/{userId}/catalog")
    public ResponseEntity<?> catalog(@PathVariable Integer userId) {
        return ResponseEntity.ok(shopService.catalogForUser(userId));
    }
}
