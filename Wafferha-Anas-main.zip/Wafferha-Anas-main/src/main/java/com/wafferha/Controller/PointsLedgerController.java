package com.wafferha.Controller;

import com.wafferha.Service.WalletService;
import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/points-ledger")
@RequiredArgsConstructor
public class PointsLedgerController {

    private final WalletService walletService;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(walletService.getAllLedger());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(walletService.getLedgerById(id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getByUser(@PathVariable Integer userId) {
        return ResponseEntity.ok(walletService.getLedgerByUser(userId));
    }

    @GetMapping("/user/{userId}/filter")
    public ResponseEntity<?> filterByUser(
            @PathVariable Integer userId,
            @RequestParam(required = false) String reason,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {
        return ResponseEntity.ok(walletService.filterByUser(userId, reason, from, to));
    }
}
