package com.wafferha.Controller;

import com.wafferha.Model.DailyQuestion;
import com.wafferha.Model.PendingGoalAdjustment;
import com.wafferha.Model.PersonalizedGoal;
import com.wafferha.Model.User;
import com.wafferha.Repository.DailyQuestionRepository;
import com.wafferha.Repository.PendingGoalAdjustmentRepository;
import com.wafferha.Repository.PersonalizedGoalRepository;
import com.wafferha.Repository.UserRepository;
import com.wafferha.Service.AiTaskService;
import com.wafferha.Service.GoalService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;









@RestController
@RequestMapping("/api/v1/whatsapp")
@RequiredArgsConstructor
public class WhatsAppWebhookController {

    private static final Logger log = LoggerFactory.getLogger(WhatsAppWebhookController.class);

    private final PendingGoalAdjustmentRepository pendingGoalAdjustmentRepository;
    private final GoalService goalService;
    private final UserRepository userRepository;
    private final DailyQuestionRepository dailyQuestionRepository;
    private final AiTaskService aiTaskService;
    private final PersonalizedGoalRepository personalizedGoalRepository;

    













    @PostMapping(value = "/twilio", produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<String> twilio(
            @RequestParam(name = "From", required = false) String From,
            @RequestParam(name = "Body", required = false) String Body) {
        try {
            String phone = stripWhatsAppPrefix(From);
            String reply = handleTwilioInbound(phone, Body);
            return twiml(reply);
        } catch (Exception e) {
            
            log.warn("Twilio inbound handling failed: {}", e.getMessage());
            return twiml("Sorry, something went wrong handling your message.");
        }
    }

    
    private String handleTwilioInbound(String phone, String body) {
        if (phone == null || phone.isBlank()) {
            return "We could not read your number. Please try again.";
        }

        
        PendingGoalAdjustment pending =
                pendingGoalAdjustmentRepository.findTopByPhoneNumberAndResolvedFalseOrderByCreatedAtDesc(phone);
        if (pending != null) {
            Choice choice = classify(body);
            if (choice == Choice.EXTEND) {
                
                goalService.applyExtend(pending.getSavingsGoalId(), false);
                pending.setResolved(true);
                pendingGoalAdjustmentRepository.save(pending);
                return "Done - your goal deadline was extended.";
            }
            if (choice == Choice.REDISTRIBUTE) {
                
                goalService.applyRedistribute(pending.getSavingsGoalId(), false);
                pending.setResolved(true);
                pendingGoalAdjustmentRepository.save(pending);
                return "Done - the shortfall was added to your upcoming periods.";
            }
            return "You're behind on a goal. Reply 1 to EXTEND the deadline, or 2 to ADD the shortfall.";
        }

        
        User user = userRepository.findByPhoneNumber(phone);

        
        if (user != null) {
            DailyQuestion dq =
                    dailyQuestionRepository.findTopByUserIdAndAnsweredFalseOrderByQuestionDateDescIdDesc(user.getId());
            if (dq != null) {
                DailyQuestion graded = aiTaskService.answerDailyQuestion(dq.getId(), body);
                if (graded.isAnsweredCorrectly()) {
                    return "Correct! You earned " + graded.getRewardPoints() + " points. Keep saving!";
                }
                String why = graded.getExplanation() == null ? "" : " " + graded.getExplanation();
                return "Not quite - no points this time. The correct answer was: "
                        + graded.getCorrectAnswer() + "." + why;
            }
        }

        
        if (user != null && body != null && body.trim().toLowerCase().contains("accept")) {
            PersonalizedGoal suggested = latestSuggestedGoal(user.getId());
            if (suggested != null) {
                goalService.accept(suggested.getId());
                return "Your suggested goal was accepted.";
            }
            return "You have no suggested goal to accept right now.";
        }

        
        return "Reply with your daily-question answer, '1'/'2' for a goal prompt, "
                + "or 'accept' to accept a suggested goal.";
    }

    
    private PersonalizedGoal latestSuggestedGoal(Integer userId) {
        List<PersonalizedGoal> goals = personalizedGoalRepository.findByUser_Id(userId);
        PersonalizedGoal best = null;
        for (PersonalizedGoal g : goals) {
            if (!"SUGGESTED".equalsIgnoreCase(g.getStatus())) {
                continue;
            }
            if (best == null || (g.getId() != null && best.getId() != null && g.getId() > best.getId())) {
                best = g;
            }
        }
        return best;
    }

    
    private ResponseEntity<String> twiml(String reply) {
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Message>"
                + xmlEscape(reply) + "</Message></Response>";
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_XML)
                .body(xml);
    }

    
    private String xmlEscape(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    



    private String stripWhatsAppPrefix(String raw) {
        if (raw == null) {
            return null;
        }
        String phone = raw.trim();
        if (phone.toLowerCase().startsWith("whatsapp:")) {
            phone = phone.substring("whatsapp:".length());
        }
        return phone.trim();
    }

    

    private enum Choice {EXTEND, REDISTRIBUTE, UNKNOWN}

    



    private Choice classify(String text) {
        if (text == null) {
            return Choice.UNKNOWN;
        }
        String t = text.trim().toLowerCase();
        if (t.contains("1") || t.contains("extend")) {
            return Choice.EXTEND;
        }
        if (t.contains("2") || t.contains("add") || t.contains("redistribute")) {
            return Choice.REDISTRIBUTE;
        }
        return Choice.UNKNOWN;
    }
}
