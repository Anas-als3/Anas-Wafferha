package com.wafferha.Controller;


import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.LeagueInDTO;
import com.wafferha.Service.AdminService;
import com.wafferha.Service.LeagueService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/league")
@RequiredArgsConstructor
public class LeagueController {

    private final LeagueService leagueService;
    private final AdminService adminService;

    @GetMapping("/get")
    public ResponseEntity<?> getAllLeagues() {
        return ResponseEntity.status(200)
                .body(leagueService.getAllLeagues());
    }

    @PostMapping("/add/{adminId}")
    public ResponseEntity<?> addLeague(@PathVariable Integer adminId,
                                       @RequestBody @Valid LeagueInDTO league) {
        adminService.requireAdmin(adminId);
        leagueService.addLeague(league);
        return ResponseEntity.status(200).body(ApiResponse.flat("League added", null));
    }
}
