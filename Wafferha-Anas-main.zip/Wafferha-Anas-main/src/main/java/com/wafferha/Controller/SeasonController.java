package com.wafferha.Controller;

import com.wafferha.Api.ApiResponse;
import com.wafferha.DTO.In.SeasonInDTO;
import com.wafferha.Service.AdminService;
import com.wafferha.Service.SeasonService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/season")
@RequiredArgsConstructor
public class SeasonController {

    private final SeasonService seasonService;
    private final AdminService adminService;

    @GetMapping("/get")
    public ResponseEntity<?> getAllSeasons() {
        return ResponseEntity.ok(seasonService.getAllSeasons());
    }

    @GetMapping("/active")
    public ResponseEntity<?> getActiveSeason() {
        return ResponseEntity.ok(seasonService.getActive());
    }

    @PutMapping("/{id}/activate")
    public ResponseEntity<?> activateSeason(@PathVariable Integer id) {
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("Season activated", seasonService.activate(id)));
    }

    @PutMapping("/{id}/end/{adminId}")
    public ResponseEntity<?> endSeason(@PathVariable Integer id, @PathVariable Integer adminId) {
        adminService.requireAdmin(adminId);
        return ResponseEntity.status(200)
                .body(ApiResponse.flat("Season ended", seasonService.end(id, adminId)));
    }

    @PostMapping("/add/{adminId}")
    public ResponseEntity<?> addSeason(@PathVariable Integer adminId,
                                       @RequestBody @Valid SeasonInDTO season) {
        adminService.requireAdmin(adminId);
        seasonService.addSeason(season);
        return ResponseEntity.status(200).body(ApiResponse.flat("Season added", null));
    }
}
