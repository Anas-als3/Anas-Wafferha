package com.wafferha.Config;

import com.wafferha.Model.League;
import com.wafferha.Repository.LeaderBoardRepository;
import com.wafferha.Repository.LeagueRepository;
import com.wafferha.Service.LeaderBoardService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;






@Component
@Order(2)
@RequiredArgsConstructor
public class DemoBoardSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DemoBoardSeeder.class);

    private final LeagueRepository leagueRepository;
    private final LeaderBoardRepository leaderBoardRepository;
    private final LeaderBoardService leaderBoardService;

    @Override
    public void run(String... args) {
        int built = 0;
        for (League league : leagueRepository.findAll()) {
            if (!leaderBoardRepository.findByLeague_Id(league.getId()).isEmpty()) {
                continue; 
            }
            try {
                leaderBoardService.buildForLeague(league.getId(), "MONTHLY");
                built++;
            } catch (Exception e) {
                log.warn("DemoBoardSeeder: build failed for league {}: {}", league.getId(), e.getMessage());
            }
        }
        if (built > 0) {
            log.info("DemoBoardSeeder: built {} league leaderboard(s)", built);
        }
    }
}
