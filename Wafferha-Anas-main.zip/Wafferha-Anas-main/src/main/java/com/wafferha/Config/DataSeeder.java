package com.wafferha.Config;

import com.wafferha.Model.Admin;
import com.wafferha.Model.BaselineIncome;
import com.wafferha.Model.BehaviorEvent;
import com.wafferha.Model.BehaviorSource;
import com.wafferha.Model.Challenge;
import com.wafferha.Model.EconomicContext;
import com.wafferha.Model.IntegrityFlag;
import com.wafferha.Model.Item;
import com.wafferha.Model.League;
import com.wafferha.Model.Score;
import com.wafferha.Model.Season;
import com.wafferha.Model.SeasonalWallet;
import com.wafferha.Model.User;
import com.wafferha.Model.UserChallenge;
import com.wafferha.Repository.AdminRepository;
import com.wafferha.Repository.BaselineIncomeRepository;
import com.wafferha.Repository.BehaviorEventRepository;
import com.wafferha.Repository.BehaviorSourceRepository;
import com.wafferha.Repository.ChallengeRepository;
import com.wafferha.Repository.EconomicContextRepository;
import com.wafferha.Repository.IntegrityFlagRepository;
import com.wafferha.Repository.ItemRepository;
import com.wafferha.Repository.LeagueRepository;
import com.wafferha.Repository.ScoreRepository;
import com.wafferha.Repository.SeasonRepository;
import com.wafferha.Repository.SeasonalWalletRepository;
import com.wafferha.Repository.UserChallengeRepository;
import com.wafferha.Repository.UserRepository;
import com.wafferha.Service.LeagueService;
import com.wafferha.Service.WalletService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;













@Component
@Order(1)
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    
    private static final String SEGMENT_INCOME_BAND = "incomeBand";

    
    private static final String[] INCOME_BANDS = {
        "1-3k", "4-8k", "9-15k", "16-25k", "26-36k", "37-48k", "49k+"
    };

    private final LeagueRepository leagueRepository;
    private final UserRepository userRepository;
    private final BehaviorSourceRepository behaviorSourceRepository;
    private final BehaviorEventRepository behaviorEventRepository;
    private final SeasonRepository seasonRepository;
    private final ItemRepository itemRepository;
    private final ChallengeRepository challengeRepository;
    private final EconomicContextRepository economicContextRepository;
    private final ScoreRepository scoreRepository;
    private final IntegrityFlagRepository integrityFlagRepository;
    private final BaselineIncomeRepository baselineIncomeRepository;
    private final UserChallengeRepository userChallengeRepository;
    private final WalletService walletService;
    private final AdminRepository adminRepository;
    private final SeasonalWalletRepository seasonalWalletRepository;

    
    @Value("${demo.whatsapp-phone:+966554412209}")
    private String demoWhatsAppPhone;

    @Override
    @Transactional
    public void run(String... args) {
        seedLeagues();
        seedUsersAndBehavior();
        seedCompetitionUsers();
        seedAiDemoUser();
        seedAdminUser();
        seedCappedUser();
        seedSeasonItemsAndChallenges();
        seedSeasonalPoints();
        seedEconomicContext();
    }

    

    private void seedLeagues() {
        int created = 0;
        for (String band : INCOME_BANDS) {
            String name = leagueName(band);
            League existing = leagueRepository.findByName(name);
            if (existing != null) {
                
                if (existing.getDisplayName() == null || existing.getDisplayName().isBlank()) {
                    existing.setDisplayName(LeagueService.displayNameForBand(band));
                    leagueRepository.save(existing);
                }
                continue;
            }
            League league = new League();
            league.setSegmentType(SEGMENT_INCOME_BAND);
            league.setName(name);
            league.setDisplayName(LeagueService.displayNameForBand(band));
            leagueRepository.save(league);
            created++;
        }
        if (created > 0) {
            log.info("DataSeeder: created {} income-band league(s)", created);
        }
    }

    private String leagueName(String band) {
        return band;
    }

    
    private String leagueNameForIncome(int monthlyIncome) {
        if (monthlyIncome <= 3000) {
            return leagueName("1-3k");
        } else if (monthlyIncome <= 8000) {
            return leagueName("4-8k");
        } else if (monthlyIncome <= 15000) {
            return leagueName("9-15k");
        } else if (monthlyIncome <= 25000) {
            return leagueName("16-25k");
        } else if (monthlyIncome <= 36000) {
            return leagueName("26-36k");
        } else if (monthlyIncome <= 48000) {
            return leagueName("37-48k");
        } else {
            return leagueName("49k+");
        }
    }

    

    private void seedUsersAndBehavior() {
        
        List<User> existing = userRepository.findAll();
        boolean haveSeedUsers = existing.stream()
                .anyMatch(u -> "Sara Demo".equals(u.getName()));
        if (haveSeedUsers) {
            return; 
        }

        
        
        seedUser("Sara Demo", 2500, "NEW", false,
                "+966500000001", "sara.demo@wafferha.test", 27);
        seedUser("Omar Demo", 6000, "VERIFIED", true,
                "+966500000002", "omar.demo@wafferha.test", 1);
        seedUser("Lina Demo", 12000, "VERIFYING", true,
                "+966500000003", "lina.demo@wafferha.test", 15);
        seedUser("Khalid Demo", 22000, "VERIFIED", true,
                "+966500000004", "khalid.demo@wafferha.test", 5);
        seedUser("Noura Demo", 55000, "VERIFIED", true,
                "+966500000005", "noura.demo@wafferha.test", 28);

        log.info("DataSeeder: created sample users + behavior events");
    }

    private void seedUser(
            String name, int monthlyIncome, String integrityStatus, boolean optIn,
            String phoneNumber, String email, int paydayDay) {
        League league = leagueRepository.findByName(leagueNameForIncome(monthlyIncome));

        User user = new User();
        user.setName(name);
        user.setMonthlyIncome(monthlyIncome);
        user.setIntegrityStatus(integrityStatus);
        user.setCompetitiveOptIn(optIn);
        user.setPhoneNumber(phoneNumber);
        user.setEmail(email);
        user.setPaydayDay(paydayDay);
        user.setLeague(league);
        user = userRepository.save(user);

        seedBehaviorForUser(user.getId());
    }

    
    private void seedBehaviorForUser(Integer userId) {
        if (!behaviorEventRepository.findByUserId(userId).isEmpty()) {
            return; 
        }

        Integer sourceId;
        List<BehaviorSource> sources = behaviorSourceRepository.findByUserId(userId);
        if (sources.isEmpty()) {
            BehaviorSource source = new BehaviorSource();
            source.setUserId(userId);
            source.setType("SAVINGS_ACCOUNT");
            source.setPrimary(true);
            source.setSalaryDetected(true);
            sourceId = behaviorSourceRepository.save(source).getId();
        } else {
            sourceId = sources.get(0).getId();
        }

        LocalDateTime now = LocalDateTime.now();
        
        behaviorEventRepository.save(
                event(userId, sourceId, "9000.00", "Salary", "IN", now.minusDays(28)));
        behaviorEventRepository.save(
                event(userId, sourceId, "420.00", "Food Delivery", "OUT", now.minusDays(20)));
        behaviorEventRepository.save(
                event(userId, sourceId, "150.00", "Subscriptions", "OUT", now.minusDays(12)));
        behaviorEventRepository.save(
                event(userId, sourceId, "600.00", "Savings Transfer", "IN", now.minusDays(5)));
    }

    private BehaviorEvent event(
            Integer userId,
            Integer sourceId,
            String value,
            String category,
            String direction,
            LocalDateTime timestamp) {
        BehaviorEvent e = new BehaviorEvent();
        e.setUserId(userId);
        e.setSourceId(sourceId);
        e.setValue(new BigDecimal(value));
        e.setCategory(category);
        e.setDirection(direction);
        e.setTimestamp(timestamp);
        return e;
    }

    

    
    private static final String COMP_SENTINEL_PHONE = "+966590000001";

    



    private void seedCompetitionUsers() {
        if (userRepository.findByPhoneNumber(COMP_SENTINEL_PHONE) != null) {
            return; 
        }
        
        int[][] bandIncomes = {
            {2000, 2700, 3000}, {4500, 6000, 7800}, {9000, 12000, 14500},
            {17000, 20000, 24000}, {27000, 31000, 35000}, {38000, 43000, 47000},
            {50000, 60000, 75000}
        };
        String[] names = {
            "Ahmed Z", "Fatima R", "Yousef K", "Maryam A", "Hassan B", "Aisha N",
            "Sami D", "Huda E", "Tariq F", "Reem G", "Bader H", "Lama I",
            "Nasser J", "Dana L", "Faris M", "Sara Q", "Ziad S", "Mona T",
            "Rakan U", "Noor V", "Waleed Y"
        };
        
        double[] composites = {86.0, 72.0, 58.0};
        
        
        
        double[] demoBandComposites = {92.0, 9.0, 5.0};

        int idx = 0;
        for (int band = 0; band < INCOME_BANDS.length; band++) {
            for (int slot = 0; slot < 3; slot++) {
                int income = bandIncomes[band][slot];
                
                
                boolean champion = band == 2 && slot == 0;
                String phone = champion && demoWhatsAppPhone != null && !demoWhatsAppPhone.trim().isEmpty()
                        ? demoWhatsAppPhone.trim()
                        : String.format("+96659%07d", idx + 1);

                User user = new User();
                user.setName(champion ? "Demo Champion" : names[idx]);
                user.setMonthlyIncome(income);
                
                
                
                user.setIntegrityStatus(champion ? "NEW" : "VERIFIED");
                user.setBankVerified(!champion);
                
                user.setCompetitiveOptIn(!champion);
                user.setPhoneNumber(phone);
                user.setEmail("comp" + (idx + 1) + "@wafferha.test");
                user.setPaydayDay(25);
                user.setLeague(leagueRepository.findByName(leagueNameForIncome(income)));
                user = userRepository.save(user);

                seedBaseline(user.getId(), income);
                if (!champion) {
                    seedEligibleFlag(user.getId()); 
                }
                
                
                
                double[] bandComposites = band == 2 ? demoBandComposites : composites;
                seedScore(user.getId(), champion ? 92.0 : bandComposites[slot]);
                
                walletService.awardNormalPoints(user.getId(), 3000, "demo seed points", null);
                idx++;
            }
        }
        seedDemoLeagueRivals();
        log.info("DataSeeder: created {} competition users (3 per income band)", idx);
    }

    
    private static final String DEMO_RIVAL_SENTINEL_PHONE = "+966590015001";

    





    private void seedDemoLeagueRivals() {
        if (userRepository.findByPhoneNumber(DEMO_RIVAL_SENTINEL_PHONE) != null) {
            return; 
        }
        
        String[][] rivals = {
            {"Khaled R", "10000", "+966590015001", "rival1@wafferha.test", "7"},
            {"Salma R", "12500", "+966590015002", "rival2@wafferha.test", "4"},
            {"Turki R", "14000", "+966590015003", "rival3@wafferha.test", "2"}
        };
        for (String[] r : rivals) {
            int income = Integer.parseInt(r[1]);
            User user = new User();
            user.setName(r[0]);
            user.setMonthlyIncome(income);
            user.setIntegrityStatus("VERIFIED");
            user.setBankVerified(true);
            user.setCompetitiveOptIn(true);
            user.setPhoneNumber(r[2]);
            user.setEmail(r[3]);
            user.setPaydayDay(25);
            user.setLeague(leagueRepository.findByName(leagueNameForIncome(income)));
            user = userRepository.save(user);

            seedBaseline(user.getId(), income);
            seedEligibleFlag(user.getId());
            seedScore(user.getId(), Double.parseDouble(r[4]));
            walletService.awardNormalPoints(user.getId(), 3000, "demo seed points", null);
        }
        log.info("DataSeeder: created {} extra 9-15k demo-league rivals", rivals.length);
    }

    
    private void seedBaseline(Integer userId, int monthlyIncome) {
        if (baselineIncomeRepository.findByUserId(userId) != null) {
            return;
        }
        BaselineIncome baseline = new BaselineIncome();
        baseline.setUserId(userId);
        baseline.setBaselineIncomeValue(BigDecimal.valueOf(monthlyIncome));
        baseline.setFloorValue(BigDecimal.valueOf(monthlyIncome).multiply(BigDecimal.valueOf(0.5)));
        baselineIncomeRepository.save(baseline);
    }

    
    private void seedEligibleFlag(Integer userId) {
        IntegrityFlag flag = new IntegrityFlag();
        flag.setSalaryVerified(true);
        flag.setCompetitiveEligible(true);
        flag.setEligibleSince(LocalDate.now());
        flag.setUser(userRepository.findUserById(userId));
        integrityFlagRepository.save(flag);
    }

    
    private void seedScore(Integer userId, double composite) {
        Score score = new Score();
        score.setUserId(userId);
        score.setPeriod("MONTHLY");
        score.setCompositeScore(BigDecimal.valueOf(composite));
        score.setRateSubscore(BigDecimal.valueOf(composite / 250.0));
        score.setConsistencySubscore(BigDecimal.valueOf(0.6));
        score.setImprovementSubscore(BigDecimal.valueOf(0.5));
        score.setPercentileInLeague(BigDecimal.valueOf(composite));
        scoreRepository.save(score);
    }

    

    



    private void seedAiDemoUser() {
        if (userRepository.findByPhoneNumber("+966590009999") != null) {
            return;
        }
        User user = new User();
        user.setName("Faisal Demo");
        user.setMonthlyIncome(15000);
        user.setIntegrityStatus("VERIFIED");
        user.setBankVerified(true);
        user.setCompetitiveOptIn(true);
        user.setPhoneNumber("+966590009999");
        user.setEmail("faisal.demo@wafferha.test");
        user.setPaydayDay(27);
        user.setLeague(leagueRepository.findByName(leagueNameForIncome(15000)));
        user = userRepository.save(user);

        BehaviorSource source = new BehaviorSource();
        source.setUserId(user.getId());
        source.setType("CURRENT_ACCOUNT");
        source.setPrimary(true);
        source.setSalaryDetected(true);
        Integer sourceId = behaviorSourceRepository.save(source).getId();

        LocalDateTime now = LocalDateTime.now();
        
        String[][] tx = {
            {"15000", "Salary", "IN", "58"}, {"2600", "Rent", "OUT", "56"},
            {"540", "Groceries", "OUT", "54"}, {"190", "Fuel", "OUT", "52"},
            {"120", "Coffee", "OUT", "51"}, {"75", "Subscriptions", "OUT", "50"},
            {"330", "Dining", "OUT", "48"}, {"260", "Online Shopping", "OUT", "46"},
            {"800", "Savings Transfer", "IN", "45"}, {"210", "Utilities", "OUT", "44"},
            {"140", "Transport", "OUT", "42"}, {"95", "Pharmacy", "OUT", "40"},
            {"15000", "Salary", "IN", "28"}, {"2600", "Rent", "OUT", "26"},
            {"610", "Groceries", "OUT", "24"}, {"175", "Fuel", "OUT", "22"},
            {"130", "Coffee", "OUT", "21"}, {"75", "Subscriptions", "OUT", "20"},
            {"420", "Dining", "OUT", "18"}, {"310", "Online Shopping", "OUT", "16"},
            {"1000", "Savings Transfer", "IN", "15"}, {"205", "Utilities", "OUT", "14"},
            {"160", "Transport", "OUT", "12"}, {"260", "Electronics", "OUT", "9"},
            {"88", "Pharmacy", "OUT", "6"}
        };
        for (String[] t : tx) {
            behaviorEventRepository.save(
                    event(user.getId(), sourceId, t[0], t[1], t[2], now.minusDays(Long.parseLong(t[3]))));
        }
        seedBaseline(user.getId(), 15000);
        walletService.awardNormalPoints(user.getId(), 3000, "demo seed points", null);
        log.info("DataSeeder: created AI-demo user 'Faisal Demo' with {} transactions", tx.length);
    }

    

    


    private void seedAdminUser() {
        if (adminRepository.findByName("Wafferha Admin") != null) {
            return;
        }
        Admin admin = new Admin();
        admin.setName("Wafferha Admin");
        admin.setEmail("admin@wafferha.test");
        adminRepository.save(admin);
        log.info("DataSeeder: created admin 'Wafferha Admin' (separate Admin table)");
    }

    

    private static final String CAPPED_USER_PHONE = "+966590008888";

    




    private void seedCappedUser() {
        if (userRepository.findByPhoneNumber(CAPPED_USER_PHONE) != null) {
            return;
        }
        int income = 10000;
        User user = new User();
        user.setName("Capped Saver");
        user.setMonthlyIncome(income);
        user.setIntegrityStatus("VERIFIED");
        user.setBankVerified(true);
        user.setCompetitiveOptIn(true);
        user.setPhoneNumber(CAPPED_USER_PHONE);
        user.setEmail("capped.saver@wafferha.test");
        user.setPaydayDay(25);
        user.setLeague(leagueRepository.findByName(leagueNameForIncome(income)));
        user = userRepository.save(user);

        seedBaseline(user.getId(), income);
        seedEligibleFlag(user.getId());
        walletService.awardNormalPoints(user.getId(), 3000, "demo seed points", null);

        
        LocalDateTime now = LocalDateTime.now();
        Challenge ch = new Challenge();
        ch.setTitle("Big save (demo: past the 40% cap)");
        ch.setType("save");
        ch.setCadence("MONTHLY");
        ch.setTargetValue(6000.0);
        ch.setRewardPoints(20);
        ch.setRewardCurrencyType("NORMAL");
        ch.setStartAt(now.minusDays(3));
        ch.setEndAt(now.plusDays(27));
        ch = challengeRepository.save(ch);

        UserChallenge uc = new UserChallenge();
        uc.setUser(user);
        uc.setChallenge(ch);
        uc.setStatus("COMPLETED");
        uc.setProgress(6000.0);
        uc.setCompletedAt(now);
        userChallengeRepository.save(uc);

        log.info("DataSeeder: created 'Capped Saver' (past the 40% monthly cap)");
    }

    

    private void seedSeasonItemsAndChallenges() {
        Season season = findSeasonByName("Summer Saver 2026");
        if (season == null) {
            LocalDateTime now = LocalDateTime.now();
            season = new Season();
            season.setSeasonType("EVENT");
            season.setName("Summer Saver 2026");
            season.setTheme("Summer");
            season.setYear(2026);
            season.setStartAt(now.minusDays(7));
            season.setEndAt(now.plusDays(30));
            season.setPointsExpireAt(now.plusDays(37));
            season.setStatus("ACTIVE");
            season = seasonRepository.save(season);
            log.info("DataSeeder: created sample season");
        }

        
        if (findItemByName("Talabat 10 SAR Off") == null) {
            Item deliveryCoupon = new Item();
            deliveryCoupon.setName("Talabat 10 SAR Off");
            deliveryCoupon.setType("COUPON");
            deliveryCoupon.setCost(500);
            deliveryCoupon.setCurrencyType("normalPoints");
            deliveryCoupon.setRarity("COMMON");
            deliveryCoupon.setIsSeasonExclusive(false);
            deliveryCoupon.setAwardOnly(false);
            deliveryCoupon.setCouponCode("WAFFERHA-TLB-10");
            deliveryCoupon.setCouponDescription("10 SAR off your next Talabat delivery");
            itemRepository.save(deliveryCoupon);
        }
        if (findItemByName("Cinema Ticket") == null) {
            Item cinemaCoupon = new Item();
            cinemaCoupon.setName("Cinema Ticket");
            cinemaCoupon.setType("COUPON");
            cinemaCoupon.setCost(300);
            cinemaCoupon.setCurrencyType("seasonalPoints");
            cinemaCoupon.setRarity("RARE");
            cinemaCoupon.setIsSeasonExclusive(true);
            cinemaCoupon.setAwardOnly(false);
            cinemaCoupon.setAvailableFrom(season.getStartAt());
            cinemaCoupon.setAvailableUntil(season.getEndAt());
            cinemaCoupon.setSeason(season);
            cinemaCoupon.setCouponCode("WAFFERHA-CINEMA");
            cinemaCoupon.setCouponDescription("One free cinema ticket");
            itemRepository.save(cinemaCoupon);
        }
        if (findItemByName("Riyadh Season 15% Off") == null) {
            Item riyadhCoupon = new Item();
            riyadhCoupon.setName("Riyadh Season 15% Off");
            riyadhCoupon.setType("COUPON");
            riyadhCoupon.setCost(800);
            riyadhCoupon.setCurrencyType("normalPoints");
            riyadhCoupon.setRarity("EPIC");
            riyadhCoupon.setIsSeasonExclusive(false);
            riyadhCoupon.setAwardOnly(false);
            riyadhCoupon.setCouponCode("WAFFERHA-RS-15");
            riyadhCoupon.setCouponDescription("15% off Riyadh Season tickets");
            itemRepository.save(riyadhCoupon);
        }

        
        if (findItemByName("Season Champion Coupon") == null) {
            Item coupon = new Item();
            coupon.setName("Season Champion Coupon");
            coupon.setType("COUPON");
            coupon.setCost(null); 
            coupon.setCurrencyType("normalPoints");
            coupon.setRarity("LEGENDARY");
            coupon.setIsSeasonExclusive(false);
            coupon.setAwardOnly(true);   
            coupon.setCouponCode("WAFFERHA-CHAMP-10");
            coupon.setCouponDescription("10% off next month's Shahid subscription");
            itemRepository.save(coupon);
        }

        
        if (findChallengeByTitle("Save 500 SAR this week") == null) {
            Challenge normalChallenge = new Challenge();
            normalChallenge.setTitle("Save 500 SAR this week");
            normalChallenge.setCadence("WEEKLY");
            normalChallenge.setType("SAVE");
            normalChallenge.setTargetValue(500.0);
            normalChallenge.setRewardPoints(100);
            normalChallenge.setRewardCurrencyType("NORMAL");
            normalChallenge.setStartAt(LocalDateTime.now());
            normalChallenge.setEndAt(LocalDateTime.now().plusDays(7));
            challengeRepository.save(normalChallenge);
        }
        if (findChallengeByTitle("Summer no-delivery month") == null) {
            Challenge seasonalChallenge = new Challenge();
            seasonalChallenge.setTitle("Summer no-delivery month");
            seasonalChallenge.setCadence("MONTHLY");
            seasonalChallenge.setType("REDUCE_SPEND");
            seasonalChallenge.setTargetValue(400.0);
            seasonalChallenge.setRewardPoints(250);
            seasonalChallenge.setRewardCurrencyType("SEASONAL");
            seasonalChallenge.setStartAt(season.getStartAt());
            seasonalChallenge.setEndAt(season.getEndAt());
            seasonalChallenge.setSeason(season);
            challengeRepository.save(seasonalChallenge);
        }
    }

    

    private void seedEconomicContext() {
        if (economicContextRepository.count() > 0) {
            return; 
        }
        EconomicContext ctx = new EconomicContext();
        ctx.setInflationRatePct(2.0);
        ctx.setPolicyRatePct(5.0);
        ctx.setSeasonLevel("NORMAL");
        ctx.setSavingClimate("SAVE_FAVORABLE");
        ctx.setSource("SAMA published indicators");
        economicContextRepository.save(ctx);
        log.info("DataSeeder: created economic context snapshot");
    }

    

    private Season findSeasonByName(String name) {
        return seasonRepository.findAll().stream()
                .filter(s -> name.equals(s.getName()))
                .findFirst()
                .orElse(null);
    }

    private Item findItemByName(String name) {
        return itemRepository.findAll().stream()
                .filter(i -> name.equals(i.getName()))
                .findFirst()
                .orElse(null);
    }

    private Challenge findChallengeByTitle(String title) {
        return challengeRepository.findAll().stream()
                .filter(c -> title.equals(c.getTitle()))
                .findFirst()
                .orElse(null);
    }

    
    
    
    private void seedSeasonalPoints() {
        Season season = findSeasonByName("Summer Saver 2026");
        if (season == null) {
            return;
        }
        String championPhone = (demoWhatsAppPhone != null && !demoWhatsAppPhone.trim().isEmpty())
                ? demoWhatsAppPhone.trim() : "+966554412209";
        String[] phones = { championPhone, "+966590009999" };
        int seeded = 0;
        for (String phone : phones) {
            User u = userRepository.findByPhoneNumber(phone);
            if (u == null) {
                continue;
            }
            boolean exists = seasonalWalletRepository.findByUserId(u.getId()).stream()
                    .anyMatch(w -> season.getId().equals(w.getSeasonId()));
            if (exists) {
                continue;
            }
            SeasonalWallet w = new SeasonalWallet();
            w.setUserId(u.getId());
            w.setSeasonId(season.getId());
            w.setSeasonalPointsBalance(1200);
            w.setEarnedDuringSeason(1200);
            w.setExpiresAt(season.getPointsExpireAt());
            w.setStatus("ACTIVE");
            seasonalWalletRepository.save(w);
            seeded++;
        }
        if (seeded > 0) {
            log.info("DataSeeder: seeded seasonal points for {} demo user(s)", seeded);
        }
    }
}
