package com.wafferha.Repository;

import com.wafferha.Model.SavingsGoal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SavingsGoalRepository extends JpaRepository<SavingsGoal, Integer> {

    List<SavingsGoal> findByUserId(Integer userId);

    SavingsGoal findSavingsGoalById(Integer id);

    
    List<SavingsGoal> findByStatus(String status);
}
