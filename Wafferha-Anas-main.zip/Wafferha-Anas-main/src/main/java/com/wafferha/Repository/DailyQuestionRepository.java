package com.wafferha.Repository;

import com.wafferha.Model.DailyQuestion;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DailyQuestionRepository extends JpaRepository<DailyQuestion, Integer> {

    DailyQuestion findDailyQuestionById(Integer id);

    List<DailyQuestion> findByUserId(Integer userId);

    
    DailyQuestion findTopByUserIdAndAnsweredFalseOrderByQuestionDateDescIdDesc(Integer userId);
}
