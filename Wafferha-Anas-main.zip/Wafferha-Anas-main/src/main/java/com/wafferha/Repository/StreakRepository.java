package com.wafferha.Repository;

import com.wafferha.Model.Streak;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StreakRepository extends JpaRepository<Streak, Integer> {

    List<Streak> findByUserId(Integer userId);

    
    Optional<Streak> findByUserIdAndType(Integer userId, String type);
}
