package com.wafferha.Repository;

import com.wafferha.Model.Score;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ScoreRepository extends JpaRepository<Score, Integer> {

    
    List<Score> findByUserId(Integer userId);

    
    
    List<Score> findByUserIdAndPeriodOrderByComputedAtDesc(Integer userId, String period);
}
