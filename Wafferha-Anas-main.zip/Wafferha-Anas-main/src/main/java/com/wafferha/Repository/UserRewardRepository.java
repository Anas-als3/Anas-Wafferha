package com.wafferha.Repository;

import com.wafferha.Model.UserReward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRewardRepository extends JpaRepository<UserReward, Integer> {
    UserReward findUserRewardById(Integer id);

    List<UserReward> findByUser_Id(Integer userId);

    List<UserReward> findBySeason_Id(Integer seasonId);
}
