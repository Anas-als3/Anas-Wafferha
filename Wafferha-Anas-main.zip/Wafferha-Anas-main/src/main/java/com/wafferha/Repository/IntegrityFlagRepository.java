package com.wafferha.Repository;

import com.wafferha.Model.IntegrityFlag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IntegrityFlagRepository extends JpaRepository<IntegrityFlag, Integer> {
    IntegrityFlag findIntegrityFlagById(Integer id);

    IntegrityFlag findByUser_Id(Integer userId);
}
