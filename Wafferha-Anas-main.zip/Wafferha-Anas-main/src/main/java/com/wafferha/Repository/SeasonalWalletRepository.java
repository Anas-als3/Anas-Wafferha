package com.wafferha.Repository;

import com.wafferha.Model.SeasonalWallet;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SeasonalWalletRepository extends JpaRepository<SeasonalWallet, Integer> {

    
    List<SeasonalWallet> findByUserId(Integer userId);

    List<SeasonalWallet> findBySeasonId(Integer seasonId);
}
