package com.wafferha.Repository;

import com.wafferha.Model.Challenge;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChallengeRepository extends JpaRepository<Challenge, Integer> {
    Challenge findChallengeById(Integer id);

    List<Challenge> findBySeason_Id(Integer seasonId);
}