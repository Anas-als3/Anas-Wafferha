package com.wafferha.Repository;

import com.wafferha.Model.BaselineIncome;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BaselineIncomeRepository extends JpaRepository<BaselineIncome, Integer> {

    
    BaselineIncome findByUserId(Integer userId);
}
