package com.wafferha.Repository;

import com.wafferha.Model.BehaviorEvent;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BehaviorEventRepository extends JpaRepository<BehaviorEvent, Integer> {

    List<BehaviorEvent> findByUserId(Integer userId);

    
    List<BehaviorEvent> findByUserIdAndDirection(Integer userId, String direction);
}
