package com.wafferha.Repository;

import com.wafferha.Model.LeaderBoardEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeaderBoardEntryRepository extends JpaRepository<LeaderBoardEntry, Integer> {

    LeaderBoardEntry findLeaderBoardEntryById(Integer id);

    List<LeaderBoardEntry> findByUser_Id(Integer userId);

    List<LeaderBoardEntry> findByLeaderboard_Id(Integer leaderboardId);
}
