package com.wafferha.Repository;

import com.wafferha.Model.VerificationCode;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VerificationCodeRepository extends JpaRepository<VerificationCode, Integer> {

    
    Optional<VerificationCode> findTopByUserIdAndUsedFalseOrderByExpiresAtDesc(Integer userId);
}
