package com.wafferha.Repository;


import com.wafferha.Model.League;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LeagueRepository extends JpaRepository<League, Integer> {
    League findLeagueById(Integer id);

    
    League findByName(String name);
}
