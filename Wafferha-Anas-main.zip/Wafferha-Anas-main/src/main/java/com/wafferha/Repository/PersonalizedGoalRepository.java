package com.wafferha.Repository;

import com.wafferha.Model.PersonalizedGoal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PersonalizedGoalRepository extends JpaRepository<PersonalizedGoal, Integer> {
    PersonalizedGoal findPersonalizedGoalById(Integer id);

    List<PersonalizedGoal> findByUser_Id(Integer userId);
}
