package com.wafferha.Repository;

import com.wafferha.Model.PendingGoalAdjustment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PendingGoalAdjustmentRepository extends JpaRepository<PendingGoalAdjustment, Integer> {

    
    PendingGoalAdjustment findTopByPhoneNumberAndResolvedFalseOrderByCreatedAtDesc(String phoneNumber);

    
    PendingGoalAdjustment findTopBySavingsGoalIdAndResolvedFalseOrderByCreatedAtDesc(Integer savingsGoalId);
}
