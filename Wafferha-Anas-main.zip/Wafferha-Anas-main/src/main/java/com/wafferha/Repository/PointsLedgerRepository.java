package com.wafferha.Repository;

import com.wafferha.Model.PointsLedger;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PointsLedgerRepository extends JpaRepository<PointsLedger, Integer> {

    
    List<PointsLedger> findByUserId(Integer userId);
}
