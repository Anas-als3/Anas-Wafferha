package com.wafferha.Repository;

import com.wafferha.Model.SeasonalPointsLedger;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SeasonalPointsLedgerRepository extends JpaRepository<SeasonalPointsLedger, Integer> {

    
    List<SeasonalPointsLedger> findByUserId(Integer userId);

    List<SeasonalPointsLedger> findBySeasonId(Integer seasonId);
}
