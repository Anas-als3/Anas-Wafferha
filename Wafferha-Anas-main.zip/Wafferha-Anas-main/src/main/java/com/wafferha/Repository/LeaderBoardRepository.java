package com.wafferha.Repository;

import com.wafferha.Model.LeaderBoard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeaderBoardRepository extends JpaRepository<LeaderBoard, Integer> {

    LeaderBoard findLeaderBoardById(Integer id);

    List<LeaderBoard> findByLeague_Id(Integer leagueId);
}
