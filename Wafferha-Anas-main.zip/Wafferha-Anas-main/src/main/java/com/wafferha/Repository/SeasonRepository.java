package com.wafferha.Repository;

import com.wafferha.Model.Season;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SeasonRepository extends JpaRepository<Season, Integer> {
    Season findSeasonById(Integer id);
}
