package com.wafferha.Repository;

import com.wafferha.Model.FinancialProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FinancialProgressRepository extends JpaRepository<FinancialProgress, Integer> {

    
    FinancialProgress findByUserId(Integer userId);
}
