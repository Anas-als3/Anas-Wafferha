package com.wafferha.Repository;

import com.wafferha.Model.UserChallenge;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserChallengeRepository extends JpaRepository<UserChallenge, Integer> {

    UserChallenge findUserChallengeById(Integer id);

    List<UserChallenge> findByUser_Id(Integer userId);

    
    @Query("select coalesce(sum(c.targetValue), 0) from UserChallenge uc join uc.challenge c "
            + "where uc.user.id = :userId and uc.status = 'COMPLETED' and lower(c.type) = 'save' "
            + "and uc.completedAt >= :since")
    double sumSavedSince(@Param("userId") Integer userId, @Param("since") LocalDateTime since);

    
    
    @Query("select uc.completedAt from UserChallenge uc join uc.challenge c "
            + "where uc.user.id = :userId and uc.status = 'COMPLETED' and lower(c.type) = 'save' "
            + "and uc.completedAt >= :since")
    List<LocalDateTime> findSaveCompletionsSince(@Param("userId") Integer userId, @Param("since") LocalDateTime since);
}
