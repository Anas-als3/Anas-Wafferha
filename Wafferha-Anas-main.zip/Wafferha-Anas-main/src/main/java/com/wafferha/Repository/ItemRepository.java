package com.wafferha.Repository;

import com.wafferha.Model.Item;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemRepository extends JpaRepository<Item, Integer> {
    Item findItemById(Integer id);

    List<Item> findBySeason_Id(Integer seasonId);
}