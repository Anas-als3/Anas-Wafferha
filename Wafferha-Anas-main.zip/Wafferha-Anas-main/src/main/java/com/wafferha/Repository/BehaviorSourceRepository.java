package com.wafferha.Repository;

import com.wafferha.Model.BehaviorSource;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BehaviorSourceRepository extends JpaRepository<BehaviorSource, Integer> {

    List<BehaviorSource> findByUserId(Integer userId);
}
