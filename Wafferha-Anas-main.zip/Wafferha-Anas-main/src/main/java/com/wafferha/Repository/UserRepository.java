package com.wafferha.Repository;

import com.wafferha.Model.User;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    
    User findUserById(Integer id);

    
    List<User> findByLeague_Id(Integer leagueId);

    
    User findByPhoneNumber(String phoneNumber);

    
    List<User> findByPaydayDay(Integer paydayDay);
}
