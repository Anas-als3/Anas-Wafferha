package com.wafferha.Repository;

import com.wafferha.Model.EconomicContext;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EconomicContextRepository extends JpaRepository<EconomicContext, Integer> {

    
    Optional<EconomicContext> findTopByOrderByUpdatedAtDescIdDesc();
}
