package com.wafferha.Repository;

import com.wafferha.Model.Insight;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InsightRepository extends JpaRepository<Insight, Integer> {

    List<Insight> findByUserId(Integer userId);
}
