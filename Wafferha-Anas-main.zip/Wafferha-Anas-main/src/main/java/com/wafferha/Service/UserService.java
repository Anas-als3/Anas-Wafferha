package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.UserInDTO;
import com.wafferha.DTO.Out.LeagueOutDTO;
import com.wafferha.DTO.Out.UserOutDTO;
import com.wafferha.Model.BaselineIncome;
import com.wafferha.Model.League;
import com.wafferha.Model.User;
import com.wafferha.Repository.LeagueRepository;
import com.wafferha.Repository.UserRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final LeagueRepository leagueRepository;
    private final LeagueService leagueService;
    private final BehaviorService behaviorService;

    





    @Transactional
    public Map<String, Object> onboard(Integer userId, Integer monthlyIncome) {
        User user = findById(userId);
        if (monthlyIncome != null) {
            user.setMonthlyIncome(monthlyIncome);
            userRepository.save(user);
        }

        
        
        BaselineIncome baseline = behaviorService.recompute(userId);
        if (baseline.getBaselineIncomeValue() != null && baseline.getBaselineIncomeValue().intValue() > 1000) {
            user.setMonthlyIncome(baseline.getBaselineIncomeValue().intValue());
            userRepository.save(user);
        }
        if (user.getMonthlyIncome() == null) {
            throw new ApiException("No income on file for this user (connect a bank, or pass monthlyIncome)");
        }

        LeagueOutDTO league = leagueService.assignLeague(userId);

        
        
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("userId", user.getId());
        result.put("name", user.getName());
        result.put("monthlyIncome", user.getMonthlyIncome());
        result.put("league", league.getName());   
        result.put("leagueId", league.getId());    
        result.put("baselineIncomeValue", baseline.getBaselineIncomeValue());
        return result;
    }

    @Transactional
    public UserOutDTO create(UserInDTO dto) {
        User user = toEntity(dto, new User());
        return fromEntity(userRepository.save(user));
    }

    
    @Transactional
    public UserOutDTO setCompetitiveOptIn(Integer userId, boolean optIn) {
        User user = findById(userId);
        user.setCompetitiveOptIn(optIn);
        return fromEntity(userRepository.save(user));
    }

    public List<UserOutDTO> getAll() {
        return userRepository.findAll().stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public UserOutDTO getById(Integer id) {
        return fromEntity(findById(id));
    }

    public List<UserOutDTO> getByLeague(Integer leagueId) {
        return userRepository.findByLeague_Id(leagueId).stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public User findById(Integer id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ApiException("User was not found"));
    }

    

    private User toEntity(UserInDTO dto, User user) {
        user.setName(dto.getName());
        user.setPhoneNumber(dto.getPhoneNumber());
        user.setEmail(dto.getEmail());
        user.setPaydayDay(dto.getPaydayDay());
        user.setMonthlyIncome(dto.getMonthlyIncome());
        user.setCompetitiveOptIn(dto.isCompetitiveOptIn());
        user.setIntegrityStatus(dto.getIntegrityStatus());
        if (dto.getLeagueId() != null) {
            League league = leagueRepository.findById(dto.getLeagueId())
                    .orElseThrow(() -> new ApiException("League was not found"));
            user.setLeague(league);
        } else {
            user.setLeague(null);
        }
        return user;
    }

    private UserOutDTO fromEntity(User user) {
        UserOutDTO dto = new UserOutDTO();
        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setPhoneNumber(user.getPhoneNumber());
        dto.setEmail(user.getEmail());
        dto.setPaydayDay(user.getPaydayDay());
        dto.setCreatedAt(user.getCreatedAt());
        dto.setMonthlyIncome(user.getMonthlyIncome());
        dto.setCompetitiveOptIn(user.isCompetitiveOptIn());
        dto.setPhoneVerified(user.isPhoneVerified());
        dto.setIntegrityStatus(user.getIntegrityStatus());
        if (user.getLeague() != null) {
            dto.setLeagueId(user.getLeague().getId());
            
            dto.setLeagueName(LeagueService.displayLabel(user.getLeague()));
        }
        return dto;
    }
}
