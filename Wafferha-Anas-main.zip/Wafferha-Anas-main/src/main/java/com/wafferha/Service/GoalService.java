package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.PersonalizedGoalInDTO;
import com.wafferha.DTO.In.SavingsGoalInDTO;
import com.wafferha.DTO.Out.FinancialProgressOutDTO;
import com.wafferha.DTO.Out.PersonalizedGoalOutDTO;
import com.wafferha.DTO.Out.SavingsGoalOutDTO;
import com.wafferha.Model.BehaviorEvent;
import com.wafferha.Model.Challenge;
import com.wafferha.Model.EconomicContext;
import com.wafferha.Model.FinancialProgress;
import com.wafferha.Model.PendingGoalAdjustment;
import com.wafferha.Model.PersonalizedGoal;
import com.wafferha.Model.SavingsGoal;
import com.wafferha.Model.User;
import com.wafferha.Model.UserChallenge;
import com.wafferha.Repository.BehaviorEventRepository;
import com.wafferha.Repository.ChallengeRepository;
import com.wafferha.Repository.FinancialProgressRepository;
import com.wafferha.Repository.PendingGoalAdjustmentRepository;
import com.wafferha.Repository.PersonalizedGoalRepository;
import com.wafferha.Repository.SavingsGoalRepository;
import com.wafferha.Repository.UserChallengeRepository;
import com.wafferha.Repository.UserRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;









@Service
@RequiredArgsConstructor
public class GoalService {

    private static final Logger log = LoggerFactory.getLogger(GoalService.class);

    private static final double WEEKS_PER_MONTH = 4.345;
    private static final double DAYS_PER_MONTH = 30.0;

    
    
    
    private static final double TARGET_RATE = 0.40;
    private static final String MODEL_VERSION = "rule-40pct-v1";
    private static final Set<String> VALID_PERIODS =
            Set.of("DAILY", "WEEKLY", "MONTHLY", "YEARLY");

    private static final String STATUS_ACTIVE = "ACTIVE";

    private static final String BEHIND_INSTRUCTIONS = """
            You are Wafferha's supportive saving coach. The user has fallen a little behind on a savings
            goal. Write ONE short, warm, encouraging sentence (max 160 characters) that gently says they
            have slipped behind and can get back on track. No shame, no riba/interest. Do NOT include any
            reply instructions or option numbers - those are appended separately. Return JSON ("message").
            """;

    private static final String GOAL_INSTRUCTIONS = """
            You are Wafferha's saving coach for a young Saudi saver. Given their monthly income and the
            suggested 40%-of-income savings target for this period, write ONE short, motivating rationale
            (max 220 characters) for why saving that amount is worth it. Encouraging, never shaming. No
            riba/interest. Return only JSON matching the schema (a single "message" string).
            """;

    private final SavingsGoalRepository savingsGoalRepository;
    private final UserRepository userRepository;
    private final ChallengeRepository challengeRepository;
    private final UserChallengeRepository userChallengeRepository;
    private final EconomicContextService economicContextService;
    private final PendingGoalAdjustmentRepository pendingGoalAdjustmentRepository;
    private final NotificationService notificationService;
    private final AiTaskService aiTaskService;
    private final FinancialProgressRepository financialProgressRepository;
    private final BehaviorEventRepository behaviorEventRepository;
    private final PersonalizedGoalRepository personalizedGoalRepository;

    
    
    

    @Transactional
    public SavingsGoalOutDTO createGoal(Integer userId, SavingsGoalInDTO dto) {
        String cadence = dto.getCadence() == null ? "WEEKLY" : dto.getCadence();
        int months = dto.getMonths() == null ? 0 : dto.getMonths();
        double targetAmount = dto.getTargetAmount() == null ? 0.0 : dto.getTargetAmount();
        return savingsGoalFromEntity(createGoal(userId, dto.getName(), targetAmount, months, cadence));
    }

    @Transactional
    public SavingsGoal createGoal(Integer userId, String name, double targetAmount, int months, String cadence) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));
        if (targetAmount <= 0) {
            throw new ApiException("targetAmount must be positive");
        }
        if (months <= 0) {
            throw new ApiException("months must be positive");
        }

        String cad = cadence == null ? "WEEKLY" : cadence.toUpperCase();
        double periods;
        switch (cad) {
            case "DAILY":
                periods = months * DAYS_PER_MONTH;
                break;
            case "MONTHLY":
                periods = months;
                break;
            default:
                cad = "WEEKLY";
                periods = months * WEEKS_PER_MONTH;
                break;
        }
        
        
        
        EconomicContext econ = economicContextService.getCurrent();
        double inflationRatePct = econ.getInflationRatePct() == null ? 0.0 : econ.getInflationRatePct();
        double years = months / 12.0;
        double bufferedTarget = Math.round(targetAmount * (1 + (inflationRatePct / 100.0) * years));
        String bufferRationale = String.format(
                "Added a %.2f%% inflation buffer over %d month(s) (annual rate %.1f%%, source: %s): "
                        + "%.2f SAR target grossed up to %.0f SAR so it still buys this goal by the target date.",
                inflationRatePct * years, months, inflationRatePct,
                econ.getSource() == null ? "default" : econ.getSource(),
                targetAmount, bufferedTarget);

        double perPeriod = Math.ceil((bufferedTarget / periods) * 100.0) / 100.0;

        SavingsGoal goal = new SavingsGoal();
        goal.setUserId(userId);
        goal.setName(name);
        goal.setTargetAmount(targetAmount);
        goal.setBufferedTarget(bufferedTarget);
        goal.setBufferRationale(bufferRationale);
        goal.setPerPeriodAmount(perPeriod);
        goal.setCadence(cad);
        goal.setTargetDate(LocalDate.now().plusMonths(months));
        goal.setSavedAmount(0.0);
        goal.setStatus("ACTIVE");
        goal = savingsGoalRepository.save(goal);

        seedFirstTask(user, name, perPeriod, cad);
        return goal;
    }

    @Transactional
    public SavingsGoalOutDTO addProgress(Integer goalId, double amount) {
        SavingsGoal goal = savingsGoalRepository.findById(goalId)
                .orElseThrow(() -> new ApiException("Savings goal was not found"));
        if (amount <= 0) {
            throw new ApiException("amount must be positive");
        }
        goal.setSavedAmount(goal.getSavedAmount() + amount);
        double effectiveTarget = goal.getBufferedTarget() != null ? goal.getBufferedTarget() : goal.getTargetAmount();
        if (goal.getSavedAmount() >= effectiveTarget) {
            goal.setStatus("COMPLETED");
        }
        return savingsGoalFromEntity(savingsGoalRepository.save(goal));
    }

    public List<SavingsGoalOutDTO> getForUser(Integer userId) {
        return savingsGoalRepository.findByUserId(userId).stream()
                .map(this::savingsGoalFromEntity)
                .collect(Collectors.toList());
    }

    
    public List<SavingsGoalOutDTO> filterForUser(Integer userId, String status) {
        return savingsGoalRepository.findByUserId(userId).stream()
                .filter(g -> status == null || status.equalsIgnoreCase(g.getStatus()))
                .map(this::savingsGoalFromEntity)
                .collect(Collectors.toList());
    }

    




    @Transactional
    public SavingsGoalOutDTO recalculate(Integer goalId) {
        SavingsGoal goal = savingsGoalRepository.findById(goalId)
                .orElseThrow(() -> new ApiException("Savings goal was not found"));

        long monthsBetween = java.time.temporal.ChronoUnit.MONTHS.between(LocalDate.now(), goal.getTargetDate());
        int months = (int) Math.max(1, monthsBetween);

        String cad = goal.getCadence() == null ? "WEEKLY" : goal.getCadence().toUpperCase();
        double periods;
        switch (cad) {
            case "DAILY":
                periods = months * DAYS_PER_MONTH;
                break;
            case "MONTHLY":
                periods = months;
                break;
            default:
                cad = "WEEKLY";
                periods = months * WEEKS_PER_MONTH;
                break;
        }

        EconomicContext econ = economicContextService.getCurrent();
        double inflationRatePct = econ.getInflationRatePct() == null ? 0.0 : econ.getInflationRatePct();
        double years = months / 12.0;
        double targetAmount = goal.getTargetAmount() == null ? 0.0 : goal.getTargetAmount();
        double bufferedTarget = Math.round(targetAmount * (1 + (inflationRatePct / 100.0) * years));
        String bufferRationale = String.format(
                "Recalculated: added a %.2f%% inflation buffer over %d month(s) (annual rate %.1f%%, source: %s): "
                        + "%.2f SAR target grossed up to %.0f SAR so it still buys this goal by the target date.",
                inflationRatePct * years, months, inflationRatePct,
                econ.getSource() == null ? "default" : econ.getSource(),
                targetAmount, bufferedTarget);

        double perPeriod = Math.ceil((bufferedTarget / periods) * 100.0) / 100.0;

        goal.setCadence(cad);
        goal.setBufferedTarget(bufferedTarget);
        goal.setBufferRationale(bufferRationale);
        goal.setPerPeriodAmount(perPeriod);
        return savingsGoalFromEntity(savingsGoalRepository.save(goal));
    }

    public SavingsGoalOutDTO getSavingsGoalById(Integer id) {
        return savingsGoalFromEntity(findSavingsGoalById(id));
    }

    public SavingsGoal findSavingsGoalById(Integer id) {
        return savingsGoalRepository.findById(id)
                .orElseThrow(() -> new ApiException("Savings goal was not found"));
    }

    private void seedFirstTask(User user, String goalName, double perPeriod, String cadence) {
        String title = "Save " + (long) Math.ceil(perPeriod) + " SAR toward " + goalName;
        if (title.length() > 100) {
            title = title.substring(0, 100);
        }

        Challenge challenge = new Challenge();
        challenge.setTitle(title);
        challenge.setType("save");
        challenge.setCadence(cadence);
        challenge.setTargetValue(perPeriod);
        challenge.setRewardPoints(rewardForAmount(perPeriod));
        challenge.setRewardCurrencyType("NORMAL");
        challenge.setStartAt(LocalDateTime.now());
        challenge.setEndAt(endForCadence(cadence));
        challenge = challengeRepository.save(challenge);

        UserChallenge uc = new UserChallenge();
        uc.setUser(user);
        uc.setChallenge(challenge);
        uc.setProgress(0.0);
        uc.setStatus("NOT_STARTED");
        userChallengeRepository.save(uc);
    }

    private int rewardForAmount(double amount) {
        return Math.min(100, Math.max(5, (int) (amount / 10)));
    }

    private LocalDateTime endForCadence(String cadence) {
        LocalDateTime now = LocalDateTime.now();
        switch (cadence == null ? "WEEKLY" : cadence.toUpperCase()) {
            case "DAILY":
                return now.plusDays(1);
            case "MONTHLY":
                return now.plusMonths(1);
            default:
                return now.plusWeeks(1);
        }
    }

    private SavingsGoalOutDTO savingsGoalFromEntity(SavingsGoal entity) {
        return new SavingsGoalOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getName(),
                entity.getTargetAmount(),
                entity.getBufferedTarget(),
                entity.getBufferRationale(),
                entity.getPerPeriodAmount(),
                entity.getCadence(),
                entity.getTargetDate(),
                entity.getSavedAmount(),
                entity.getStatus(),
                entity.getCreatedAt());
    }

    
    
    

    






    @Transactional
    public PendingGoalAdjustment checkBehind(Integer goalId) {
        SavingsGoal goal = findGoal(goalId);
        if (!STATUS_ACTIVE.equals(goal.getStatus())) {
            return null; 
        }

        User user = userRepository.findById(goal.getUserId())
                .orElseThrow(() -> new ApiException("User was not found"));
        String phone = user.getPhoneNumber();

        double expected = expectedSavedByNow(goal);
        double saved = nz(goal.getSavedAmount());
        if (saved >= expected) {
            
            notificationService.sendMessage(phone, "Goal '" + goal.getName() + "': you've saved "
                    + (long) saved + " of " + (long) nz(goal.getTargetAmount())
                    + " SAR and you're on track - keep it up!");
            return null;
        }

        
        
        PendingGoalAdjustment open =
                pendingGoalAdjustmentRepository.findTopBySavingsGoalIdAndResolvedFalseOrderByCreatedAtDesc(goal.getId());
        if (open != null) {
            return open;
        }

        PendingGoalAdjustment pending = new PendingGoalAdjustment();
        pending.setUserId(goal.getUserId());
        pending.setSavingsGoalId(goal.getId());
        pending.setPhoneNumber(phone);
        pending.setResolved(false);
        pending = pendingGoalAdjustmentRepository.save(pending);

        
        
        String fallbackLead = "You are behind on your goal \"" + goal.getName() + "\".";
        String aiLead = aiTaskService.aiText(BEHIND_INSTRUCTIONS,
                "Saver " + user.getName() + " has fallen behind on their savings goal \"" + goal.getName()
                        + "\" (about " + (long) remaining(goal) + " SAR still to save). Write one short, warm,"
                        + " encouraging sentence - no reply instructions, no numbers.");
        String lead = aiLead != null ? aiLead : fallbackLead;
        notificationService.sendMessage(phone, lead
                + " Reply 1 to EXTEND the deadline, or 2 to ADD the shortfall to your upcoming periods.");
        return pending;
    }

    



    @Transactional
    public SavingsGoal applyExtend(Integer goalId) {
        return applyExtend(goalId, true);
    }

    




    @Transactional
    public SavingsGoal applyExtend(Integer goalId, boolean notify) {
        SavingsGoal goal = findGoal(goalId);

        double remaining = remaining(goal);
        if (remaining > 0) {
            double perPeriod = nz(goal.getPerPeriodAmount());
            if (perPeriod <= 0) {
                throw new ApiException("perPeriodAmount must be positive to extend the goal");
            }
            long periodsNeeded = (long) Math.ceil(remaining / perPeriod);
            LocalDate from = LocalDate.now();
            LocalDate extended = addPeriods(from, goal.getCadence(), periodsNeeded);
            
            if (extended.isAfter(goal.getTargetDate())) {
                goal.setTargetDate(extended);
            }
            goal = savingsGoalRepository.save(goal);
        }

        if (notify) {
            notificationService.sendMessage(phoneFor(goal.getUserId()),
                    "Done - your goal deadline was extended.");
        }
        return goal;
    }

    



    @Transactional
    public SavingsGoal applyRedistribute(Integer goalId) {
        return applyRedistribute(goalId, true);
    }

    



    @Transactional
    public SavingsGoal applyRedistribute(Integer goalId, boolean notify) {
        SavingsGoal goal = findGoal(goalId);

        double remaining = remaining(goal);
        if (remaining > 0) {
            long periodsRemaining = Math.max(1, periodsBetween(LocalDate.now(), goal.getTargetDate(), goal.getCadence()));
            double newPerPeriod = roundUpMoney(remaining / periodsRemaining);
            
            if (newPerPeriod > nz(goal.getPerPeriodAmount())) {
                goal.setPerPeriodAmount(newPerPeriod);
                goal = savingsGoalRepository.save(goal);
            }
        }

        if (notify) {
            notificationService.sendMessage(phoneFor(goal.getUserId()),
                    "Done - your upcoming amounts were increased to stay on track.");
        }
        return goal;
    }

    









    @Transactional
    public PendingGoalAdjustment simulateBehind(Integer goalId) {
        SavingsGoal goal = findGoal(goalId);

        double perPeriod = nz(goal.getPerPeriodAmount());
        double target = nz(goal.getTargetAmount());
        long elapsed = (perPeriod > 0 && target > 0)
                ? Math.max(1, (long) Math.ceil(target / perPeriod)) : 1;

        goal.setCreatedAt(addPeriods(LocalDate.now(), goal.getCadence(), -elapsed).atStartOfDay());
        goal.setTargetDate(addPeriods(LocalDate.now(), goal.getCadence(), 1));
        goal.setStatus(STATUS_ACTIVE);
        savingsGoalRepository.save(goal);

        return checkBehind(goalId);
    }

    



    @Scheduled(cron = "0 0 9 1 * *")
    public void scheduledMonthlyBehindCheck() {
        List<SavingsGoal> active = savingsGoalRepository.findByStatus(STATUS_ACTIVE);
        int prompted = 0;
        for (SavingsGoal goal : active) {
            try {
                if (checkBehind(goal.getId()) != null) {
                    prompted++;
                }
            } catch (Exception e) {
                log.warn("Behind-on-goal check failed for goal {}: {}", goal.getId(), e.getMessage());
            }
        }
        log.info("Monthly behind-on-goal sweep: checked {} active goal(s), prompted {}.", active.size(), prompted);
    }

    private SavingsGoal findGoal(Integer goalId) {
        SavingsGoal goal = savingsGoalRepository.findById(goalId)
                .orElseThrow(() -> new ApiException("Savings goal was not found"));
        return goal;
    }

    
    private double expectedSavedByNow(SavingsGoal goal) {
        long periodsElapsed = periodsElapsedSince(goal.getCreatedAt(), goal.getCadence());
        double expected = nz(goal.getPerPeriodAmount()) * periodsElapsed;
        double target = nz(goal.getTargetAmount());
        return Math.min(expected, target);
    }

    private double remaining(SavingsGoal goal) {
        return Math.max(0.0, nz(goal.getTargetAmount()) - nz(goal.getSavedAmount()));
    }

    
    private long periodsElapsedSince(LocalDateTime createdAt, String cadence) {
        LocalDateTime start = createdAt == null ? LocalDateTime.now() : createdAt;
        return periodsBetween(start.toLocalDate(), LocalDate.now(), cadence);
    }

    
    private long periodsBetween(LocalDate from, LocalDate to, String cadence) {
        if (to.isBefore(from)) {
            return 0;
        }
        switch (cad(cadence)) {
            case "DAILY":
                return ChronoUnit.DAYS.between(from, to);
            case "MONTHLY":
                return ChronoUnit.MONTHS.between(from, to);
            default: 
                return ChronoUnit.WEEKS.between(from, to);
        }
    }

    
    private LocalDate addPeriods(LocalDate from, String cadence, long periods) {
        switch (cad(cadence)) {
            case "DAILY":
                return from.plusDays(periods);
            case "MONTHLY":
                return from.plusMonths(periods);
            default: 
                return from.plusWeeks(periods);
        }
    }

    private String phoneFor(Integer userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));
        return user.getPhoneNumber();
    }

    private static String cad(String cadence) {
        return cadence == null ? "WEEKLY" : cadence.toUpperCase();
    }

    private static double nz(Double value) {
        return value == null ? 0.0 : value;
    }

    
    private static double roundUpMoney(double amount) {
        return Math.ceil(amount * 100.0) / 100.0;
    }

    
    
    

    





    @Transactional
    public FinancialProgressOutDTO recompute(Integer userId) {
        if (userId == null) {
            throw new ApiException("userId is required");
        }

        FinancialProgress progress = financialProgressRepository.findByUserId(userId);
        if (progress == null) {
            progress = new FinancialProgress();
            progress.setUserId(userId);
        }

        
        
        
        BigDecimal totalSaved = BigDecimal.ZERO;
        for (SavingsGoal goal : savingsGoalRepository.findByUserId(userId)) {
            if (goal.getSavedAmount() != null) {
                totalSaved = totalSaved.add(BigDecimal.valueOf(goal.getSavedAmount()));
            }
        }
        for (UserChallenge uc : userChallengeRepository.findByUser_Id(userId)) {
            if (!"COMPLETED".equalsIgnoreCase(uc.getStatus()) || uc.getChallenge() == null) {
                continue;
            }
            Challenge ch = uc.getChallenge();
            
            if (ch.getType() != null && ch.getType().toLowerCase().contains("save")
                    && ch.getTargetValue() != null && ch.getTargetValue() > 1) {
                totalSaved = totalSaved.add(BigDecimal.valueOf(ch.getTargetValue()));
            }
        }
        progress.setTotalSaved(totalSaved);

        return financialProgressFromEntity(financialProgressRepository.save(progress));
    }

    public List<FinancialProgressOutDTO> getAllFinancialProgress() {
        return financialProgressRepository.findAll().stream()
                .map(this::financialProgressFromEntity)
                .collect(Collectors.toList());
    }

    public FinancialProgressOutDTO getFinancialProgressById(Integer id) {
        return financialProgressFromEntity(findFinancialProgressById(id));
    }

    
    public FinancialProgressOutDTO getFinancialProgressByUser(Integer userId) {
        FinancialProgress existing = financialProgressRepository.findByUserId(userId);
        if (existing == null) {
            throw new ApiException("Financial progress was not found for this user");
        }
        return financialProgressFromEntity(existing);
    }

    public FinancialProgress findFinancialProgressById(Integer id) {
        return financialProgressRepository.findById(id)
                .orElseThrow(() -> new ApiException("Financial progress was not found"));
    }

    private FinancialProgressOutDTO financialProgressFromEntity(FinancialProgress entity) {
        return new FinancialProgressOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getTotalSaved(),
                entity.getProjectedGoalDate(),
                entity.getEmergencyFundPct());
    }

    
    
    

    




    @Transactional
    public PersonalizedGoalOutDTO generate(Integer userId, String period) {

        User user = userRepository.findUserById(userId);

        if (user == null) {
            throw new ApiException("User not found");
        }

        String normalizedPeriod = period == null ? "MONTHLY" : period.trim().toUpperCase();
        if (!VALID_PERIODS.contains(normalizedPeriod)) {
            throw new ApiException("Period must be DAILY, WEEKLY, MONTHLY or YEARLY");
        }

        if (user.getMonthlyIncome() == null || user.getMonthlyIncome() <= 0) {
            throw new ApiException("User has no monthly income set; cannot compute a goal");
        }

        double monthlyIncome = user.getMonthlyIncome();
        double suggestedTarget = Math.round(monthlyIncome * TARGET_RATE * 100.0) / 100.0;

        String fallbackRationale = "Aim to save 40% of your monthly income ("
                + suggestedTarget + " SAR) this " + normalizedPeriod.toLowerCase()
                + " - the fairness target that maximises your leaderboard standing.";

        
        
        String aiRationale = aiTaskService.aiText(GOAL_INSTRUCTIONS,
                "User earns about " + (int) monthlyIncome + " SAR per month. Suggested target: save "
                        + suggestedTarget + " SAR this " + normalizedPeriod.toLowerCase()
                        + " (40% of income). Write one short, motivating rationale.");
        boolean usedAi = aiRationale != null;

        PersonalizedGoal goal = new PersonalizedGoal();
        goal.setPeriod(normalizedPeriod);
        goal.setSuggestedTarget(suggestedTarget);
        goal.setRationale(usedAi ? aiRationale : fallbackRationale);
        goal.setModelVersion(usedAi ? aiTaskService.aiModel() : MODEL_VERSION);
        goal.setUser(user);

        return personalizedGoalFromEntity(personalizedGoalRepository.save(goal));
    }

    public List<PersonalizedGoalOutDTO> getAllPersonalizedGoals() {
        return personalizedGoalRepository.findAll()
                .stream().map(this::personalizedGoalFromEntity).collect(Collectors.toList());
    }

    public List<PersonalizedGoalOutDTO> getPersonalizedGoalsByUser(Integer userId) {
        return personalizedGoalRepository.findByUser_Id(userId)
                .stream().map(this::personalizedGoalFromEntity).collect(Collectors.toList());
    }

    public PersonalizedGoalOutDTO addPersonalizedGoal(Integer userId, PersonalizedGoalInDTO dto) {

        User user = userRepository.findUserById(userId);

        if (user == null) {
            throw new ApiException("User not found");
        }

        PersonalizedGoal personalizedGoal = personalizedGoalToEntity(dto);
        personalizedGoal.setUser(user);

        return personalizedGoalFromEntity(personalizedGoalRepository.save(personalizedGoal));
    }

    public PersonalizedGoal personalizedGoalToEntity(PersonalizedGoalInDTO dto) {
        PersonalizedGoal goal = new PersonalizedGoal();
        goal.setPeriod(dto.getPeriod());
        goal.setSuggestedTarget(dto.getSuggestedTarget());
        goal.setRationale(dto.getRationale());
        goal.setModelVersion(dto.getModelVersion());
        return goal;
    }

    
    @Transactional
    public PersonalizedGoalOutDTO accept(Integer id) {
        PersonalizedGoal goal = personalizedGoalRepository.findPersonalizedGoalById(id);
        if (goal == null) {
            throw new ApiException("PersonalizedGoal not found");
        }
        goal.setStatus("ACCEPTED");
        return personalizedGoalFromEntity(personalizedGoalRepository.save(goal));
    }

    public PersonalizedGoalOutDTO personalizedGoalFromEntity(PersonalizedGoal goal) {
        PersonalizedGoalOutDTO dto = new PersonalizedGoalOutDTO();
        dto.setId(goal.getId());
        dto.setPeriod(goal.getPeriod());
        dto.setStatus(goal.getStatus());
        dto.setSuggestedTarget(goal.getSuggestedTarget());
        dto.setRationale(goal.getRationale());
        dto.setModelVersion(goal.getModelVersion());
        if (goal.getUser() != null) {
            dto.setUserId(goal.getUser().getId());
        }
        return dto;
    }
}
