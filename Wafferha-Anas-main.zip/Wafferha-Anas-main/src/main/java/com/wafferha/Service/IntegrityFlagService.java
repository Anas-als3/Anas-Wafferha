package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.IntegrityFlagInDTO;
import com.wafferha.DTO.Out.IntegrityFlagOutDTO;
import com.wafferha.Model.BaselineIncome;
import com.wafferha.Model.BehaviorSource;
import com.wafferha.Model.IntegrityFlag;
import com.wafferha.Model.User;
import com.wafferha.Repository.BaselineIncomeRepository;
import com.wafferha.Repository.BehaviorSourceRepository;
import com.wafferha.Repository.IntegrityFlagRepository;
import com.wafferha.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class IntegrityFlagService {

    private final IntegrityFlagRepository integrityFlagRepository;
    private final UserRepository userRepository;
    private final BehaviorSourceRepository behaviorSourceRepository;
    private final BaselineIncomeRepository baselineIncomeRepository;

    public List<IntegrityFlagOutDTO> getAllIntegrityFlags() {
        return integrityFlagRepository.findAll()
                .stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public IntegrityFlagOutDTO getIntegrityFlagByUser(Integer userId) {
        IntegrityFlag flag = integrityFlagRepository.findByUser_Id(userId);
        if (flag == null) {
            throw new ApiException("IntegrityFlag not found");
        }
        return fromEntity(flag);
    }

    
    public List<IntegrityFlagOutDTO> filter(Boolean eligible) {
        return integrityFlagRepository.findAll().stream()
                .filter(f -> eligible == null || eligible.equals(f.getCompetitiveEligible()))
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    



    @Transactional
    public IntegrityFlagOutDTO evaluate(Integer userId) {
        User user = userRepository.findUserById(userId);
        if (user == null) {
            throw new ApiException("User not found");
        }

        boolean eligible = user.isBankVerified() && !"FLAGGED".equalsIgnoreCase(user.getIntegrityStatus());
        
        
        boolean salaryVerified = false;
        if (user.isBankVerified()) {
            BaselineIncome baseline = baselineIncomeRepository.findByUserId(userId);
            boolean hasIncome = baseline != null && baseline.getBaselineIncomeValue() != null
                    && baseline.getBaselineIncomeValue().signum() > 0;
            boolean salaryDetected = behaviorSourceRepository.findByUserId(userId).stream()
                    .anyMatch(BehaviorSource::isSalaryDetected);
            salaryVerified = hasIncome || salaryDetected;
        }

        IntegrityFlag flag = integrityFlagRepository.findByUser_Id(userId);
        if (flag == null) {
            flag = new IntegrityFlag();
            flag.setUser(user);
        }
        flag.setSalaryVerified(salaryVerified);
        flag.setCompetitiveEligible(eligible);
        if (eligible) {
            if (flag.getEligibleSince() == null) {
                flag.setEligibleSince(LocalDate.now());
            }
        } else {
            flag.setEligibleSince(null);
        }

        return fromEntity(integrityFlagRepository.save(flag));
    }

    public IntegrityFlagOutDTO addIntegrityFlag(Integer userId, IntegrityFlagInDTO dto) {

        User user = userRepository.findUserById(userId);

        if (user == null) {
            throw new ApiException("User not found");
        }

        IntegrityFlag integrityFlag = toEntity(dto);
        integrityFlag.setUser(user);

        return fromEntity(integrityFlagRepository.save(integrityFlag));
    }

    public IntegrityFlag toEntity(IntegrityFlagInDTO dto) {
        IntegrityFlag flag = new IntegrityFlag();
        flag.setSalaryVerified(dto.getSalaryVerified());
        flag.setAnomalyFlags(dto.getAnomalyFlags());
        flag.setCompetitiveEligible(dto.getCompetitiveEligible());
        flag.setEligibleSince(dto.getEligibleSince());
        return flag;
    }

    public IntegrityFlagOutDTO fromEntity(IntegrityFlag flag) {
        IntegrityFlagOutDTO dto = new IntegrityFlagOutDTO();
        dto.setId(flag.getId());
        dto.setSalaryVerified(flag.getSalaryVerified());
        dto.setAnomalyFlags(flag.getAnomalyFlags());
        dto.setCompetitiveEligible(flag.getCompetitiveEligible());
        dto.setEligibleSince(flag.getEligibleSince());
        if (flag.getUser() != null) {
            dto.setUserId(flag.getUser().getId());
        }
        return dto;
    }
}
