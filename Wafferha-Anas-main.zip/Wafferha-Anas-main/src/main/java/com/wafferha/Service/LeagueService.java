package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.LeagueInDTO;
import com.wafferha.DTO.Out.LeagueOutDTO;
import com.wafferha.Model.League;
import com.wafferha.Model.User;
import com.wafferha.Repository.LeagueRepository;
import com.wafferha.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LeagueService {

    
    private static final String INCOME_BAND = "incomeBand";

    private final LeagueRepository leagueRepository;
    private final UserRepository userRepository;

    public List<LeagueOutDTO> getAllLeagues() {
        return leagueRepository.findAll()
                .stream()
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    public void addLeague(LeagueInDTO dto) {
        leagueRepository.save(toEntity(dto));
    }

    

    




    @Transactional
    public LeagueOutDTO assignLeague(Integer userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));

        Integer income = user.getMonthlyIncome();
        if (income == null) {
            throw new ApiException("User has no monthly income set, cannot assign a league");
        }

        String bandName = bandForIncome(income);

        League league = leagueRepository.findByName(bandName);
        if (league == null) {
            league = new League();
            league.setSegmentType(INCOME_BAND);
            league.setName(bandName);
            league.setDisplayName(displayNameForBand(bandName));
            league = leagueRepository.save(league);
        } else if (league.getDisplayName() == null || league.getDisplayName().isBlank()) {
            
            league.setDisplayName(displayNameForBand(bandName));
            league = leagueRepository.save(league);
        }

        user.setLeague(league);
        userRepository.save(user);

        return fromEntity(league);
    }

    




    private String bandForIncome(int income) {
        
        if (income < 4000) {
            return "1-3k";
        }
        if (income < 9000) {
            return "4-8k";
        }
        if (income < 16000) {
            return "9-15k";
        }
        if (income < 26000) {
            return "16-25k";
        }
        if (income < 37000) {
            return "26-36k";
        }
        if (income < 49000) {
            return "37-48k";
        }
        return "49k+";
    }

    

    public League toEntity(LeagueInDTO dto) {
        League league = new League();
        league.setSegmentType(dto.getSegmentType());
        league.setName(dto.getName());
        return league;
    }

    public LeagueOutDTO fromEntity(League league) {
        LeagueOutDTO dto = new LeagueOutDTO();
        dto.setId(league.getId());
        dto.setSegmentType(league.getSegmentType());
        
        dto.setName(displayLabel(league));
        return dto;
    }

    
    public static String displayLabel(League league) {
        if (league == null) {
            return null;
        }
        if (league.getDisplayName() != null && !league.getDisplayName().isBlank()) {
            return league.getDisplayName();
        }
        return league.getId() == null ? "League" : "League " + league.getId();
    }

    
    public static String displayNameForBand(String band) {
        if (band == null) {
            return "Division";
        }
        switch (band.trim()) {
            case "1-3k":   return "Division 1";
            case "4-8k":   return "Division 2";
            case "9-15k":  return "Division 3";
            case "16-25k": return "Division 4";
            case "26-36k": return "Division 5";
            case "37-48k": return "Division 6";
            case "49k+":   return "Division 7";
            default:       return "Division";
        }
    }
}
