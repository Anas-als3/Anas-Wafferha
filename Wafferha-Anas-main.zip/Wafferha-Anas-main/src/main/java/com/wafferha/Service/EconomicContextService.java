package com.wafferha.Service;

import com.wafferha.DTO.In.EconomicContextInDTO;
import com.wafferha.DTO.Out.EconomicContextOutDTO;
import com.wafferha.Model.EconomicContext;
import com.wafferha.Repository.EconomicContextRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;










@Service
@RequiredArgsConstructor
public class EconomicContextService {

    private static final Logger log = LoggerFactory.getLogger(EconomicContextService.class);

    
    private static final double DEFAULT_INFLATION_RATE_PCT = 2.0;
    private static final double DEFAULT_POLICY_RATE_PCT = 5.0;
    private static final String DEFAULT_SEASON_LEVEL = "NORMAL";
    private static final String DEFAULT_SAVING_CLIMATE = "SAVE_FAVORABLE";
    private static final String DEFAULT_SOURCE = "Default (no SAMA snapshot yet)";

    private final EconomicContextRepository economicContextRepository;

    



    public EconomicContext getCurrent() {
        return economicContextRepository.findTopByOrderByUpdatedAtDescIdDesc()
                .orElseGet(EconomicContextService::defaultContext);
    }

    public EconomicContextOutDTO getCurrentDto() {
        return fromEntity(getCurrent());
    }

    




    @Transactional
    public EconomicContextOutDTO update(EconomicContextInDTO dto) {
        EconomicContext current = getCurrent();

        EconomicContext next = new EconomicContext();
        next.setInflationRatePct(dto.getInflationRatePct() != null
                ? dto.getInflationRatePct() : current.getInflationRatePct());
        next.setPolicyRatePct(dto.getPolicyRatePct() != null
                ? dto.getPolicyRatePct() : current.getPolicyRatePct());
        next.setSeasonLevel(dto.getSeasonLevel() != null
                ? dto.getSeasonLevel() : current.getSeasonLevel());
        next.setSavingClimate(dto.getSavingClimate() != null
                ? dto.getSavingClimate() : current.getSavingClimate());
        next.setSource(dto.getSource() != null ? dto.getSource() : current.getSource());

        return fromEntity(economicContextRepository.save(next));
    }

    




    @Scheduled(cron = "0 0 3 1 * *")
    @Transactional
    public void scheduledMonthlyRefresh() {
        economicContextRepository.findTopByOrderByUpdatedAtDescIdDesc().ifPresent(ctx -> {
            
            economicContextRepository.save(ctx);
            log.info("EconomicContextService: monthly refresh touched economic context #{}", ctx.getId());
        });
    }

    private static EconomicContext defaultContext() {
        EconomicContext ctx = new EconomicContext();
        ctx.setInflationRatePct(DEFAULT_INFLATION_RATE_PCT);
        ctx.setPolicyRatePct(DEFAULT_POLICY_RATE_PCT);
        ctx.setSeasonLevel(DEFAULT_SEASON_LEVEL);
        ctx.setSavingClimate(DEFAULT_SAVING_CLIMATE);
        ctx.setSource(DEFAULT_SOURCE);
        ctx.setUpdatedAt(java.time.LocalDateTime.now());
        return ctx;
    }

    private EconomicContextOutDTO fromEntity(EconomicContext entity) {
        return new EconomicContextOutDTO(
                entity.getId(),
                entity.getInflationRatePct(),
                entity.getPolicyRatePct(),
                entity.getSeasonLevel(),
                entity.getSavingClimate(),
                entity.getSource(),
                entity.getUpdatedAt());
    }
}
