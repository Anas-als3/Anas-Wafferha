package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.Out.SeasonalPointsLedgerOutDTO;
import com.wafferha.DTO.Out.SeasonalWalletOutDTO;
import com.wafferha.Model.SeasonalPointsLedger;
import com.wafferha.Model.SeasonalWallet;
import com.wafferha.Repository.SeasonalPointsLedgerRepository;
import com.wafferha.Repository.SeasonalWalletRepository;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;









@Service
@RequiredArgsConstructor
public class SeasonalWalletService {

    private final SeasonalWalletRepository seasonalWalletRepository;
    private final SeasonalPointsLedgerRepository seasonalPointsLedgerRepository;

    

    public List<SeasonalWalletOutDTO> getAll() {
        return seasonalWalletRepository.findAll().stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public SeasonalWalletOutDTO getById(Integer id) {
        return fromEntity(findById(id));
    }

    public List<SeasonalWalletOutDTO> getByUser(Integer userId) {
        return seasonalWalletRepository.findByUserId(userId).stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public List<SeasonalWalletOutDTO> getBySeason(Integer seasonId) {
        return seasonalWalletRepository.findBySeasonId(seasonId).stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public SeasonalWallet findById(Integer id) {
        return seasonalWalletRepository.findById(id)
                .orElseThrow(() -> new ApiException("Seasonal wallet was not found"));
    }

    

    public List<SeasonalPointsLedgerOutDTO> getAllLedger() {
        return seasonalPointsLedgerRepository.findAll().stream().map(this::ledgerFromEntity).collect(Collectors.toList());
    }

    public SeasonalPointsLedgerOutDTO getLedgerById(Integer id) {
        return ledgerFromEntity(findLedgerById(id));
    }

    public List<SeasonalPointsLedgerOutDTO> getLedgerByUser(Integer userId) {
        return seasonalPointsLedgerRepository.findByUserId(userId).stream().map(this::ledgerFromEntity).collect(Collectors.toList());
    }

    public List<SeasonalPointsLedgerOutDTO> getLedgerBySeason(Integer seasonId) {
        return seasonalPointsLedgerRepository.findBySeasonId(seasonId).stream().map(this::ledgerFromEntity).collect(Collectors.toList());
    }

    public SeasonalPointsLedger findLedgerById(Integer id) {
        return seasonalPointsLedgerRepository.findById(id)
                .orElseThrow(() -> new ApiException("Seasonal points ledger entry was not found"));
    }

    

    private SeasonalWalletOutDTO fromEntity(SeasonalWallet seasonalWallet) {
        SeasonalWalletOutDTO dto = new SeasonalWalletOutDTO();
        dto.setId(seasonalWallet.getId());
        dto.setUserId(seasonalWallet.getUserId());
        dto.setSeasonId(seasonalWallet.getSeasonId());
        dto.setSeasonalPointsBalance(seasonalWallet.getSeasonalPointsBalance());
        dto.setEarnedDuringSeason(seasonalWallet.getEarnedDuringSeason());
        dto.setSpentDuringSeason(seasonalWallet.getSpentDuringSeason());
        dto.setExpiredPoints(seasonalWallet.getExpiredPoints());
        dto.setExpiresAt(seasonalWallet.getExpiresAt());
        dto.setStatus(seasonalWallet.getStatus());
        dto.setCreatedAt(seasonalWallet.getCreatedAt());
        dto.setUpdatedAt(seasonalWallet.getUpdatedAt());
        return dto;
    }

    private SeasonalPointsLedgerOutDTO ledgerFromEntity(SeasonalPointsLedger seasonalPointsLedger) {
        SeasonalPointsLedgerOutDTO dto = new SeasonalPointsLedgerOutDTO();
        dto.setId(seasonalPointsLedger.getId());
        dto.setUserId(seasonalPointsLedger.getUserId());
        dto.setSeasonId(seasonalPointsLedger.getSeasonId());
        dto.setSeasonalWalletId(seasonalPointsLedger.getSeasonalWalletId());
        dto.setAmount(seasonalPointsLedger.getAmount());
        dto.setReason(seasonalPointsLedger.getReason());
        dto.setRefId(seasonalPointsLedger.getRefId());
        dto.setTimestamp(seasonalPointsLedger.getTimestamp());
        return dto;
    }
}
