package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.ChallengeInDTO;
import com.wafferha.DTO.Out.ChallengeOutDTO;
import com.wafferha.DTO.Out.StreakOutDTO;
import com.wafferha.DTO.Out.UserChallengeOutDTO;
import com.wafferha.Model.Challenge;
import com.wafferha.Model.Item;
import com.wafferha.Model.Season;
import com.wafferha.Model.Streak;
import com.wafferha.Model.User;
import com.wafferha.Model.UserChallenge;
import com.wafferha.Repository.ChallengeRepository;
import com.wafferha.Repository.ItemRepository;
import com.wafferha.Repository.SeasonRepository;
import com.wafferha.Repository.StreakRepository;
import com.wafferha.Repository.UserChallengeRepository;
import com.wafferha.Repository.UserRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;





@Service
@RequiredArgsConstructor
public class EngagementService {

    private static final Pattern TYPE_PATTERN = Pattern.compile("^(DAILY_SAVE|DAILY_LOGIN|CUSTOM)$");

    private final ChallengeRepository challengeRepository;
    private final SeasonRepository seasonRepository;
    private final ItemRepository itemRepository;
    private final UserChallengeRepository userChallengeRepository;
    private final UserRepository userRepository;
    private final StreakRepository streakRepository;

    
    
    

    public List<ChallengeOutDTO> getAllChallenges() {
        return challengeRepository.findAll()
                .stream()
                .map(this::challengeFromEntity)
                .collect(Collectors.toList());
    }

    public List<ChallengeOutDTO> getChallengesBySeason(Integer seasonId) {
        return challengeRepository.findBySeason_Id(seasonId)
                .stream()
                .map(this::challengeFromEntity)
                .collect(Collectors.toList());
    }

    



    public List<ChallengeOutDTO> getActive(Integer seasonId) {
        LocalDateTime now = LocalDateTime.now();
        return challengeRepository.findAll().stream()
                .filter(c -> c.getStartAt() != null && !now.isBefore(c.getStartAt()))
                .filter(c -> c.getEndAt() != null && !now.isAfter(c.getEndAt()))
                .filter(c -> seasonId == null || (c.getSeason() != null && seasonId.equals(c.getSeason().getId())))
                .map(this::challengeFromEntity)
                .collect(Collectors.toList());
    }

    public void addChallenge(Integer seasonId, Integer itemId, ChallengeInDTO dto) {

        Season season = seasonRepository.findSeasonById(seasonId);

        if (season == null) {
            throw new ApiException("Season not found");
        }

        Item item = itemRepository.findItemById(itemId);

        if (item == null) {
            throw new ApiException("Item not found");
        }

        Challenge challenge = challengeToEntity(dto);
        challenge.setSeason(season);
        challenge.setRewardItem(item);

        challengeRepository.save(challenge);
    }

    public Challenge challengeToEntity(ChallengeInDTO dto) {
        Challenge challenge = new Challenge();
        challenge.setTitle(dto.getTitle());
        challenge.setCadence(dto.getCadence());
        challenge.setType(dto.getType());
        challenge.setTargetValue(dto.getTargetValue());
        challenge.setRewardPoints(dto.getRewardPoints());
        challenge.setRewardCurrencyType(dto.getRewardCurrencyType());
        challenge.setStartAt(dto.getStartAt());
        challenge.setEndAt(dto.getEndAt());
        return challenge;
    }

    public ChallengeOutDTO challengeFromEntity(Challenge challenge) {
        ChallengeOutDTO dto = new ChallengeOutDTO();
        dto.setId(challenge.getId());
        dto.setTitle(challenge.getTitle());
        dto.setCadence(challenge.getCadence());
        dto.setType(challenge.getType());
        dto.setTargetValue(challenge.getTargetValue());
        dto.setRewardPoints(challenge.getRewardPoints());
        dto.setRewardCurrencyType(challenge.getRewardCurrencyType());
        dto.setStartAt(challenge.getStartAt());
        dto.setEndAt(challenge.getEndAt());
        dto.setSeasonId(challenge.getSeason() == null ? null : challenge.getSeason().getId());
        dto.setRewardItemId(challenge.getRewardItem() == null ? null : challenge.getRewardItem().getId());
        return dto;
    }

    
    
    

    public List<UserChallengeOutDTO> getAllUserChallenges() {
        return userChallengeRepository.findAll()
                .stream()
                .map(this::userChallengeFromEntity)
                .collect(Collectors.toList());
    }

    public List<UserChallengeOutDTO> getUserChallengesByUser(Integer userId) {
        return userChallengeRepository.findByUser_Id(userId)
                .stream()
                .map(this::userChallengeFromEntity)
                .collect(Collectors.toList());
    }

    
    public List<UserChallengeOutDTO> filterByUser(Integer userId, String status) {
        return userChallengeRepository.findByUser_Id(userId)
                .stream()
                .filter(uc -> status == null || status.equalsIgnoreCase(uc.getStatus()))
                .map(this::userChallengeFromEntity)
                .collect(Collectors.toList());
    }

    



    @Transactional
    public UserChallengeOutDTO addProgress(Integer id, double amount) {
        UserChallenge userChallenge = userChallengeRepository.findUserChallengeById(id);
        if (userChallenge == null) {
            throw new ApiException("UserChallenge not found");
        }

        double current = userChallenge.getProgress() == null ? 0.0 : userChallenge.getProgress();
        userChallenge.setProgress(current + amount);

        Challenge challenge = userChallenge.getChallenge();
        Double target = challenge == null ? null : challenge.getTargetValue();
        if (target != null && userChallenge.getProgress() >= target
                && !"COMPLETED".equalsIgnoreCase(userChallenge.getStatus())) {
            userChallenge.setStatus("COMPLETED");
            userChallenge.setCompletedAt(LocalDateTime.now());
        }

        return userChallengeFromEntity(userChallengeRepository.save(userChallenge));
    }

    public void addUserChallenge(Integer userId, Integer challengeId) {

        User user = userRepository.findUserById(userId);

        if (user == null) {
            throw new ApiException("User not found");
        }

        Challenge challenge = challengeRepository.findChallengeById(challengeId);

        if (challenge == null) {
            throw new ApiException("Challenge not found");
        }

        UserChallenge userChallenge = new UserChallenge();

        userChallenge.setUser(user);
        userChallenge.setChallenge(challenge);

        userChallenge.setProgress(0.0);
        userChallenge.setStatus("IN_PROGRESS");

        userChallengeRepository.save(userChallenge);
    }

    public UserChallengeOutDTO userChallengeFromEntity(UserChallenge userChallenge) {
        UserChallengeOutDTO dto = new UserChallengeOutDTO();
        dto.setId(userChallenge.getId());
        dto.setProgress(userChallenge.getProgress());
        dto.setStatus(userChallenge.getStatus());
        dto.setCompletedAt(userChallenge.getCompletedAt());
        dto.setUserId(userChallenge.getUser() == null ? null : userChallenge.getUser().getId());
        dto.setChallengeId(userChallenge.getChallenge() == null ? null : userChallenge.getChallenge().getId());
        return dto;
    }

    
    
    

    









    @Transactional
    public StreakOutDTO recordActivity(Integer userId, String type) {
        if (userId == null) {
            throw new ApiException("userId is required");
        }
        if (type == null || !TYPE_PATTERN.matcher(type).matches()) {
            throw new ApiException("Streak type must be DAILY_SAVE, DAILY_LOGIN or CUSTOM");
        }

        LocalDate today = LocalDate.now();

        Streak streak = streakRepository.findByUserIdAndType(userId, type)
                .orElseGet(() -> {
                    Streak fresh = new Streak();
                    fresh.setUserId(userId);
                    fresh.setType(type);
                    fresh.setCurrentCount(0);
                    fresh.setLongestCount(0);
                    fresh.setFreezesRemaining(0);
                    return fresh;
                });

        LocalDate last = streak.getLastActiveDate();

        if (last != null && last.isEqual(today)) {
            
            return streakFromEntity(streakRepository.save(streak));
        }

        if (last == null || last.isEqual(today.minusDays(1))) {
            
            streak.setCurrentCount(streak.getCurrentCount() + 1);
            if (streak.getCurrentCount() > streak.getLongestCount()) {
                streak.setLongestCount(streak.getCurrentCount());
            }
        } else {
            
            if (streak.getFreezesRemaining() > 0) {
                streak.setFreezesRemaining(streak.getFreezesRemaining() - 1);
                
            } else {
                streak.setCurrentCount(1);
            }
        }

        streak.setLastActiveDate(today);
        return streakFromEntity(streakRepository.save(streak));
    }

    


    @Transactional
    public StreakOutDTO useFreeze(Integer id) {
        Streak streak = getStreakEntity(id);
        if (streak.getFreezesRemaining() <= 0) {
            throw new ApiException("No freezes remaining");
        }
        streak.setFreezesRemaining(streak.getFreezesRemaining() - 1);
        return streakFromEntity(streakRepository.save(streak));
    }

    public List<StreakOutDTO> getAllStreaks() {
        return streakRepository.findAll().stream()
                .map(this::streakFromEntity)
                .collect(Collectors.toList());
    }

    public StreakOutDTO getStreakById(Integer id) {
        return streakFromEntity(getStreakEntity(id));
    }

    public List<StreakOutDTO> getStreaksByUser(Integer userId) {
        return streakRepository.findByUserId(userId).stream()
                .map(this::streakFromEntity)
                .collect(Collectors.toList());
    }

    private Streak getStreakEntity(Integer id) {
        return streakRepository.findById(id)
                .orElseThrow(() -> new ApiException("Streak was not found"));
    }

    private StreakOutDTO streakFromEntity(Streak entity) {
        return new StreakOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getType(),
                entity.getCurrentCount(),
                entity.getLongestCount(),
                entity.getLastActiveDate(),
                entity.getFreezesRemaining());
    }
}
