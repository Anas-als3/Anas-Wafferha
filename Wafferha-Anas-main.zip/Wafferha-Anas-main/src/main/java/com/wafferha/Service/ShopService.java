package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.Model.Item;
import com.wafferha.Model.Season;
import com.wafferha.Model.SeasonalPointsLedger;
import com.wafferha.Model.SeasonalWallet;
import com.wafferha.Model.User;
import com.wafferha.Model.UserReward;
import com.wafferha.Repository.ItemRepository;
import com.wafferha.Repository.SeasonalPointsLedgerRepository;
import com.wafferha.Repository.SeasonalWalletRepository;
import com.wafferha.Repository.UserRepository;
import com.wafferha.Repository.UserRewardRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;










@Service
@RequiredArgsConstructor
public class ShopService {

    private static final String CURRENCY_NORMAL = "normalPoints";
    private static final String CURRENCY_SEASONAL = "seasonalPoints";

    private final ItemRepository itemRepository;
    private final UserRepository userRepository;
    private final UserRewardRepository userRewardRepository;
    private final SeasonalWalletRepository seasonalWalletRepository;
    private final SeasonalPointsLedgerRepository seasonalPointsLedgerRepository;
    private final WalletService walletService;

    


    @Transactional
    public UserReward buyItem(Integer userId, Integer itemId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));

        Item item = itemRepository.findById(itemId)
                .orElseThrow(() -> new ApiException("Item was not found"));

        
        if (Boolean.TRUE.equals(item.getAwardOnly())) {
            throw new ApiException("This item is a reward you earn, not something you can buy");
        }
        
        boolean alreadyOwned = userRewardRepository.findByUser_Id(userId).stream()
                .anyMatch(r -> r.getItem() != null && itemId.equals(r.getItem().getId()));
        if (alreadyOwned) {
            throw new ApiException("You already own this item");
        }

        int cost = requireCost(item);
        String currencyType = item.getCurrencyType();

        if (CURRENCY_NORMAL.equalsIgnoreCase(currencyType)) {
            return buyWithNormalPoints(user, item, cost);
        }
        if (CURRENCY_SEASONAL.equalsIgnoreCase(currencyType)) {
            return buyWithSeasonalPoints(user, item, cost);
        }
        throw new ApiException("Item has an unknown currency type");
    }

    



    public List<Item> catalogForUser(Integer userId) {
        Set<Integer> owned = userRewardRepository.findByUser_Id(userId).stream()
                .filter(r -> r.getItem() != null)
                .map(r -> r.getItem().getId())
                .collect(Collectors.toSet());
        return itemRepository.findAll().stream()
                .filter(i -> !Boolean.TRUE.equals(i.getAwardOnly()))
                .filter(i -> !owned.contains(i.getId()))
                .collect(Collectors.toList());
    }

    

    private UserReward buyWithNormalPoints(User user, Item item, int cost) {
        
        
        walletService.spendNormalPoints(user.getId(), cost, "purchase", item.getId());

        UserReward reward = new UserReward();
        reward.setUser(user);
        reward.setItem(item);
        reward.setSourceType("normalPurchase");
        reward.setPurchaseCurrency(CURRENCY_NORMAL);
        reward.setAcquiredAt(LocalDateTime.now());
        reward.setEquipped(false);
        return userRewardRepository.save(reward);
    }

    

    private UserReward buyWithSeasonalPoints(User user, Item item, int cost) {
        Season season = item.getSeason();
        if (season == null) {
            throw new ApiException("Item is not available now");
        }

        LocalDateTime now = LocalDateTime.now();
        if (!"ACTIVE".equalsIgnoreCase(season.getStatus())) {
            throw new ApiException("Item is not available now");
        }
        if (!withinWindow(now, item.getAvailableFrom(), item.getAvailableUntil())) {
            throw new ApiException("Item is not available now");
        }

        
        SeasonalWallet wallet = seasonalWalletRepository.findByUserId(user.getId()).stream()
                .filter(w -> season.getId().equals(w.getSeasonId()))
                .findFirst()
                .orElseThrow(() -> new ApiException("Not enough seasonal points"));

        if (!"ACTIVE".equalsIgnoreCase(wallet.getStatus())) {
            throw new ApiException("Not enough seasonal points");
        }
        if (wallet.getSeasonalPointsBalance() < cost) {
            throw new ApiException("Not enough seasonal points");
        }

        wallet.setSeasonalPointsBalance(wallet.getSeasonalPointsBalance() - cost);
        wallet.setSpentDuringSeason(wallet.getSpentDuringSeason() + cost);
        wallet = seasonalWalletRepository.save(wallet);

        SeasonalPointsLedger ledger = new SeasonalPointsLedger();
        ledger.setUserId(user.getId());
        ledger.setSeasonId(season.getId());
        ledger.setSeasonalWalletId(wallet.getId());
        ledger.setAmount(-cost);
        ledger.setReason("purchase");
        ledger.setRefId(item.getId());
        seasonalPointsLedgerRepository.save(ledger);

        UserReward reward = new UserReward();
        reward.setUser(user);
        reward.setItem(item);
        reward.setSeason(season);
        reward.setSourceType("seasonalPurchase");
        reward.setPurchaseCurrency(CURRENCY_SEASONAL);
        reward.setAcquiredAt(now);
        reward.setEquipped(false);
        return userRewardRepository.save(reward);
    }

    

    private int requireCost(Item item) {
        if (item.getCost() == null || item.getCost() <= 0) {
            throw new ApiException("Item cost is invalid");
        }
        return item.getCost();
    }

    private boolean withinWindow(LocalDateTime now, LocalDateTime from, LocalDateTime until) {
        if (from != null && now.isBefore(from)) {
            return false;
        }
        if (until != null && now.isAfter(until)) {
            return false;
        }
        return true;
    }
}
