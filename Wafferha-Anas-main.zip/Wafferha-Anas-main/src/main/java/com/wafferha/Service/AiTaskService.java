package com.wafferha.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafferha.Api.ApiException;
import com.wafferha.DTO.Out.DailyQuestionOutDTO;
import com.wafferha.DTO.Out.InsightOutDTO;
import com.wafferha.Model.BehaviorEvent;
import com.wafferha.Model.Challenge;
import com.wafferha.Model.DailyQuestion;
import com.wafferha.Model.EconomicContext;
import com.wafferha.Model.Insight;
import com.wafferha.Model.User;
import com.wafferha.Model.UserChallenge;
import com.wafferha.Repository.BehaviorEventRepository;
import com.wafferha.Repository.ChallengeRepository;
import com.wafferha.Repository.DailyQuestionRepository;
import com.wafferha.Repository.InsightRepository;
import com.wafferha.Repository.UserChallengeRepository;
import com.wafferha.Repository.UserRepository;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;











@Service
@RequiredArgsConstructor
public class AiTaskService {

    private static final String TASK_INSTRUCTIONS = """
            You are Wafferha's behaviour-analysis engine inside a Saudi bank app. You do NOT talk to the user.
            Given the user's recent spending behaviour, design ONE concrete, achievable saving task.
            Rules:
            - "type" is one of: save, noSpend, log, rate, streak.
            - "cadence" is one of: DAILY, WEEKLY, MONTHLY.
            - "title" is the task the user sees, max 100 characters, specific and encouraging.
            - Use PLAIN, everyday words anyone understands. NO jargon or acronyms - never write "BNPL",
              "installments", "riba", "liquidity"; say it simply (e.g. "skip one pay-later purchase",
              "use cash instead", "put 50 SAR aside before you spend it").
            - "targetValue" is the numeric goal (e.g. 1 means "one fewer", 50 means "save 50 SAR").
            - "rewardPoints" is 5 to 100 based on difficulty.
            - Be Shariah-compliant: no interest (riba), gambling, or speculation. Never shame the user.
            Return only JSON matching the provided schema.
            """;

    private static final String QUESTION_INSTRUCTIONS = """
            You write ONE short (about 60 seconds) multiple-choice financial-literacy question
            for a young Saudi saver. Keep it practical and Shariah-compliant (no interest framing).
            Use PLAIN, everyday words - no jargon or acronyms (never "BNPL", "installments", "riba").
            Provide 3 or 4 options; exactly one is correct, and "correctAnswer" must match one option's
            text exactly. "explanation" is 1-2 sentences on why it is correct.
            Return only JSON matching the provided schema.
            """;

    private static final String INSIGHT_INSTRUCTIONS = """
            You are Wafferha's saving coach for a young Saudi saver. From the user's recent spending
            behaviour, write ONE short, specific, encouraging nudge (max 220 characters) that points to the
            single best place they can save more, toward the 40% fairness target.
            Use PLAIN, everyday words - no jargon or acronyms (never "BNPL", "installments", "riba").
            Write complete, clear sentences. Do NOT end on a slogan or compressed saying (avoid lines like
            "saved, not borrowed" or "cash beats borrowing"); if you mention borrowing, say it plainly, e.g.
            "saving now means you won't need a costly loan later".
            Never shame the user. No interest. Return only JSON matching the schema (a "message" string).
            """;

    private static final String PAYDAY_INSTRUCTIONS = """
            You are Wafferha's behaviour-analysis engine. Design ONE "save right after payday" task for a
            Saudi saver, themed around moving money to savings on or just after their payday day.
            Same fields as a normal task: "type" one of save/noSpend/log/rate/streak; "cadence"
            DAILY/WEEKLY/MONTHLY; "title" max 100 chars in PLAIN everyday words (no jargon/acronyms like
            "BNPL" or "installments"); "targetValue" numeric; "rewardPoints" 5-100.
            Shariah-compliant, never shaming. Return only JSON matching the provided schema.
            """;

    @Value("${openai.enabled:false}")
    private Boolean enabled;

    @Value("${openai.api-key:}")
    private String apiKey;

    @Value("${openai.model:gpt-5.5}")
    private String model;

    @Value("${openai.responses-url:https://api.openai.com/v1/responses}")
    private String responsesUrl;

    private final ObjectMapper objectMapper;
    private final UserRepository userRepository;
    private final BehaviorEventRepository behaviorEventRepository;
    private final ChallengeRepository challengeRepository;
    private final UserChallengeRepository userChallengeRepository;
    private final DailyQuestionRepository dailyQuestionRepository;
    private final InsightRepository insightRepository;
    private final WalletService walletService;
    private final EconomicContextService economicContextService;
    private final NotificationService notificationService;
    private final RestTemplate restTemplate = new RestTemplate();

    

    @Transactional
    public UserChallenge generateTaskForUser(Integer userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));

        var events = behaviorEventRepository.findByUserId(userId);
        if (events == null || events.isEmpty()) {
            
            
            throw new ApiException("No spending data yet. Connect your bank (open banking) first - your "
                    + "saving task is built from your real transactions.");
        }
        String summary = summarizeBehavior(events);
        String input = "User: " + user.getName() + "\n" + summary
                + "\nDesign one task that nudges them to save more."
                + economicPromptBlock();
        JsonNode out;
        try {
            out = aiEnabled()
                    ? callOpenAi(TASK_INSTRUCTIONS, input, taskSchema(), "wafferha_task")
                    : com.fasterxml.jackson.databind.node.MissingNode.getInstance();
        } catch (RuntimeException e) {
            
            
            out = com.fasterxml.jackson.databind.node.MissingNode.getInstance();
        }

        String title = out.path("title").asText("");
        double targetValue = out.path("targetValue").asDouble(0);
        int rewardPoints = out.path("rewardPoints").asInt(0);
        if (!StringUtils.hasText(title)) {
            
            
            String cat = topDiscretionaryCategory(events);
            title = (cat != null)
                    ? "Skip 2 " + cat.toLowerCase() + " purchases this week and move 120 SAR to savings"
                    : "Move 120 SAR to savings this week before it's spent";
            if (targetValue <= 0) targetValue = 120;
            if (rewardPoints <= 0) rewardPoints = 50;
        }
        if (title.length() > 100) {
            title = title.substring(0, 100);
        }
        String cadence = upperOrDefault(out.path("cadence").asText(""), "WEEKLY");

        Challenge challenge = new Challenge();
        challenge.setTitle(title);
        challenge.setType(defaultIfBlank(out.path("type").asText(""), "save"));
        challenge.setCadence(cadence);
        challenge.setTargetValue(Math.max(1.0, targetValue > 0 ? targetValue : 1.0));
        challenge.setRewardPoints(Math.min(100, Math.max(5, rewardPoints > 0 ? rewardPoints : 20)));
        challenge.setRewardCurrencyType("NORMAL");
        challenge.setStartAt(LocalDateTime.now());
        challenge.setEndAt(endForCadence(cadence));
        challenge = challengeRepository.save(challenge);

        UserChallenge uc = new UserChallenge();
        uc.setUser(user);
        uc.setChallenge(challenge);
        uc.setProgress(0.0);
        uc.setStatus("NOT_STARTED");
        return userChallengeRepository.save(uc);
    }

    





    @Transactional
    public UserChallenge generatePaydayTask(Integer userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));

        Integer payday = user.getPaydayDay();
        int paydayDay = (payday != null && payday >= 1 && payday <= 28) ? payday : 1;

        
        String title = "Save right after payday (day " + paydayDay + ")";
        String type = "save";
        String cadence = "MONTHLY";
        double targetValue = 1.0;
        int rewardPoints = 20;

        
        if (aiEnabled()) {
            try {
                String input = "User: " + user.getName() + " (payday is day " + paydayDay + " of the month).\n"
                        + summarizeBehavior(behaviorEventRepository.findByUserId(userId)) + economicPromptBlock();
                JsonNode out = callOpenAi(PAYDAY_INSTRUCTIONS, input, taskSchema(), "wafferha_payday_task");
                String t = out.path("title").asText("");
                if (StringUtils.hasText(t)) {
                    title = t.length() > 100 ? t.substring(0, 100) : t;
                    String tp = out.path("type").asText("");
                    if (StringUtils.hasText(tp)) {
                        type = tp;
                    }
                    cadence = upperOrDefault(out.path("cadence").asText(""), "MONTHLY");
                    targetValue = out.path("targetValue").asDouble(1.0);
                    rewardPoints = Math.min(100, Math.max(5, out.path("rewardPoints").asInt(20)));
                }
            } catch (Exception e) {
                
            }
        }

        Challenge challenge = new Challenge();
        challenge.setTitle(title);
        challenge.setType(type);
        challenge.setCadence(cadence);
        challenge.setTargetValue(targetValue);
        challenge.setRewardPoints(rewardPoints);
        challenge.setRewardCurrencyType("NORMAL");
        challenge.setStartAt(LocalDateTime.now());
        challenge.setEndAt(endForCadence(cadence));
        challenge = challengeRepository.save(challenge);

        UserChallenge uc = new UserChallenge();
        uc.setUser(user);
        uc.setChallenge(challenge);
        uc.setProgress(0.0);
        uc.setStatus("NOT_STARTED");
        return userChallengeRepository.save(uc);
    }

    public DailyQuestion generateDailyQuestion(Integer userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));

        String input = "Write today's 60-second financial question for " + user.getName() + ".";
        JsonNode out = callOpenAi(QUESTION_INSTRUCTIONS, input, questionSchema(), "wafferha_daily_question");

        DailyQuestion dq = new DailyQuestion();
        dq.setUserId(userId);
        dq.setQuestion(out.path("question").asText(""));
        dq.setOptions(out.path("options").toString());
        dq.setCorrectAnswer(out.path("correctAnswer").asText(""));
        dq.setExplanation(out.path("explanation").asText(""));
        dq.setRewardPoints(10);
        DailyQuestion saved = dailyQuestionRepository.save(dq);
        sendQuestionOverWhatsApp(user, saved);
        return saved;
    }

    





    @Transactional
    public Insight generateInsight(Integer userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));

        List<BehaviorEvent> events = behaviorEventRepository.findByUserId(userId);
        String topCategory = topOutgoingCategory(events);

        
        String fallback;
        if (topCategory == null) {
            fallback = "We don't have enough spending history for " + user.getName()
                    + " yet. Log a few transactions and we'll suggest where you can save.";
        } else {
            fallback = "Your biggest spending category lately is " + topCategory
                    + ". Trimming it a little this week is the fastest way to lift your savings rate"
                    + " toward the 40% fairness target, so you stay on track without leaning on a costly loan later.";
        }

        
        String aiInput = "User: " + user.getName() + "\n" + summarizeBehavior(events)
                + "\nWrite one short saving nudge." + economicPromptBlock();
        String aiMessage = aiText(INSIGHT_INSTRUCTIONS, aiInput);

        Insight insight = new Insight();
        insight.setUserId(userId);
        insight.setMessage(StringUtils.hasText(aiMessage) ? aiMessage : fallback);
        insight.setType("NUDGE");
        return insightRepository.save(insight);
    }

    
    private String topOutgoingCategory(List<BehaviorEvent> events) {
        Map<String, Double> totals = new LinkedHashMap<>();
        for (BehaviorEvent e : events) {
            if (!"OUT".equalsIgnoreCase(e.getDirection())) {
                continue;
            }
            String category = StringUtils.hasText(e.getCategory()) ? e.getCategory() : "Other";
            double amount = e.getValue() == null ? 0 : e.getValue().doubleValue();
            totals.merge(category, amount, Double::sum);
        }
        return totals.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    
    private static final java.util.Set<String> NON_DISCRETIONARY = java.util.Set.of(
            "rent", "mortgage", "housing", "utilities", "bills", "salary", "loan", "insurance",
            "groceries", "pharmacy", "healthcare", "tuition", "savings transfer");

    
    private String topDiscretionaryCategory(List<BehaviorEvent> events) {
        Map<String, Double> totals = new LinkedHashMap<>();
        for (BehaviorEvent e : events) {
            if (!"OUT".equalsIgnoreCase(e.getDirection())) {
                continue;
            }
            String category = StringUtils.hasText(e.getCategory()) ? e.getCategory() : "Other";
            if (NON_DISCRETIONARY.contains(category.toLowerCase())) {
                continue;
            }
            double amount = e.getValue() == null ? 0 : e.getValue().doubleValue();
            totals.merge(category, amount, Double::sum);
        }
        return totals.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    

    



    @Transactional
    public UserChallenge completeTaskForUser(Integer userId, Integer userChallengeId) {
        UserChallenge uc = userChallengeRepository.findById(userChallengeId)
                .orElseThrow(() -> new ApiException("User challenge was not found"));
        Integer ownerId = uc.getUser() != null ? uc.getUser().getId() : null;
        if (ownerId == null || !ownerId.equals(userId)) {
            throw new ApiException("Task " + userChallengeId + " does not belong to user " + userId);
        }
        return completeTask(userChallengeId);
    }

    @Transactional
    public UserChallenge completeTask(Integer userChallengeId) {
        UserChallenge uc = userChallengeRepository.findById(userChallengeId)
                .orElseThrow(() -> new ApiException("User challenge was not found"));
        if ("COMPLETED".equalsIgnoreCase(uc.getStatus())) {
            throw new ApiException("Task is already completed");
        }
        Challenge ch = uc.getChallenge();
        Integer userId = uc.getUser() != null ? uc.getUser().getId() : null;

        uc.setStatus("COMPLETED");
        uc.setCompletedAt(LocalDateTime.now());
        if (ch != null && ch.getTargetValue() != null) {
            uc.setProgress(ch.getTargetValue());
        }
        UserChallenge saved = userChallengeRepository.save(uc);

        
        
        
        
        if (ch != null && ch.getRewardPoints() != null && userId != null) {
            walletService.awardNormalPoints(userId, ch.getRewardPoints(), "challenge_reward", ch.getId());
        }
        return saved;
    }

    @Transactional
    public DailyQuestion answerDailyQuestion(Integer dailyQuestionId, String answer) {
        DailyQuestion dq = dailyQuestionRepository.findById(dailyQuestionId)
                .orElseThrow(() -> new ApiException("Daily question was not found"));
        if (dq.isAnswered()) {
            throw new ApiException("This question was already answered");
        }
        String chosen = resolveAnswer(dq, answer);
        boolean correct = dq.getCorrectAnswer() != null
                && dq.getCorrectAnswer().trim().equalsIgnoreCase(chosen == null ? "" : chosen.trim());
        dq.setAnswered(true);
        dq.setAnsweredCorrectly(correct);
        DailyQuestion saved = dailyQuestionRepository.save(dq);

        if (correct) {
            walletService.awardNormalPoints(dq.getUserId(), dq.getRewardPoints(),
                    "daily_question_reward", dq.getId());
        }
        return saved;
    }

    




    private String resolveAnswer(DailyQuestion dq, String answer) {
        if (answer == null) {
            return null;
        }
        String a = answer.trim();
        List<String> options = parseOptions(dq.getOptions());
        if (a.isEmpty() || options.isEmpty()) {
            return a;
        }
        Integer index = null;
        if (a.matches("\\d{1,2}")) {
            index = Integer.parseInt(a) - 1;                  
        } else if (a.length() == 1 && Character.isLetter(a.charAt(0))) {
            index = Character.toUpperCase(a.charAt(0)) - 'A';  
        } else if (a.matches("(?i)option\\s*\\d{1,2}")) {
            index = Integer.parseInt(a.replaceAll("\\D", "")) - 1;  
        }
        if (index != null && index >= 0 && index < options.size()) {
            return options.get(index);
        }
        return a;
    }

    
    private List<String> parseOptions(String optionsJson) {
        List<String> result = new ArrayList<>();
        if (!StringUtils.hasText(optionsJson)) {
            return result;
        }
        try {
            JsonNode arr = objectMapper.readTree(optionsJson);
            if (arr.isArray()) {
                arr.forEach(n -> result.add(n.asText()));
            }
        } catch (Exception ignored) {
            
        }
        return result;
    }

    



    private void sendQuestionOverWhatsApp(User user, DailyQuestion dq) {
        String phone = user.getPhoneNumber();
        if (!StringUtils.hasText(phone)) {
            return;
        }
        List<String> options = parseOptions(dq.getOptions());

        
        StringBuilder sb = new StringBuilder();
        sb.append("Wafferha daily question:\n").append(dq.getQuestion()).append("\n\n");
        for (int i = 0; i < options.size(); i++) {
            sb.append(i + 1).append(") ").append(options.get(i)).append("\n");
        }
        sb.append("\nReply with the number (1-").append(Math.max(1, options.size())).append(").");
        String numberedText = sb.toString();

        
        List<Map<String, String>> items = new ArrayList<>();
        for (int i = 0; i < options.size(); i++) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("id", String.valueOf(i + 1));
            row.put("title", "Option " + (i + 1));
            row.put("description", options.get(i));
            items.add(row);
        }
        boolean sentInteractive = notificationService.sendListPicker(phone, dq.getQuestion(), "Answer", items, numberedText);
        if (!sentInteractive) {
            notificationService.sendMessage(phone, numberedText);
        }
    }

    

    




    private String economicPromptBlock() {
        EconomicContext econ = economicContextService.getCurrent();
        double inflation = econ.getInflationRatePct() == null ? 0.0 : econ.getInflationRatePct();
        double policy = econ.getPolicyRatePct() == null ? 0.0 : econ.getPolicyRatePct();
        String season = econ.getSeasonLevel() == null ? "NORMAL" : econ.getSeasonLevel();
        String climate = econ.getSavingClimate() == null ? "NEUTRAL" : econ.getSavingClimate();

        StringBuilder sb = new StringBuilder();
        sb.append("\n\nCurrent economic context (factor this into the task):\n");
        sb.append(String.format("- Inflation rate: %.1f%%\n", inflation));
        sb.append(String.format("- Policy rate: %.1f%%\n", policy));
        sb.append("- Season level: ").append(season).append("\n");
        sb.append("- Saving climate: ").append(climate).append("\n");
        sb.append("Guidance:\n");
        sb.append(String.format(
                "- Add a small inflation buffer to any saving amount (about %.1f%%) so its real value holds.\n",
                inflation));
        if ("HIGH".equalsIgnoreCase(season)) {
            sb.append("- Season level is HIGH (heavy spending pressure): prefer an anti-impulse / no-spend "
                    + "task to curb overspending right now.\n");
        }
        if ("SAVE_FAVORABLE".equalsIgnoreCase(climate)) {
            sb.append("- Saving climate is favourable: frame an anti-debt nudge - borrowing is costly now, "
                    + "avoid BNPL/installments, save instead.\n");
        }
        sb.append("- Stay Shariah-compliant: NEVER suggest interest-earning deposits or any riba-based product.\n");
        return sb.toString();
    }

    private String summarizeBehavior(List<BehaviorEvent> events) {
        Map<String, double[]> byCategory = new LinkedHashMap<>();
        for (BehaviorEvent e : events) {
            if (!"OUT".equalsIgnoreCase(e.getDirection())) {
                continue;
            }
            String category = StringUtils.hasText(e.getCategory()) ? e.getCategory() : "Other";
            double[] agg = byCategory.computeIfAbsent(category, k -> new double[2]);
            agg[0] += 1;
            agg[1] += e.getValue() == null ? 0 : e.getValue().doubleValue();
        }
        if (byCategory.isEmpty()) {
            return "Recent spending: none recorded yet.";
        }
        StringBuilder sb = new StringBuilder("Recent outgoing spending by category:\n");
        byCategory.entrySet().stream()
                .sorted((a, b) -> Double.compare(b.getValue()[1], a.getValue()[1]))
                .limit(6)
                .forEach(en -> sb.append("- ").append(en.getKey()).append(": ")
                        .append((int) en.getValue()[0]).append(" charges totaling ")
                        .append(String.format("%.2f", en.getValue()[1])).append(" SAR\n"));
        return sb.toString();
    }

    private LocalDateTime endForCadence(String cadence) {
        LocalDateTime now = LocalDateTime.now();
        switch (cadence == null ? "WEEKLY" : cadence.toUpperCase()) {
            case "DAILY":
                return now.plusDays(1);
            case "MONTHLY":
                return now.plusMonths(1);
            case "YEARLY":
                return now.plusYears(1);
            default:
                return now.plusWeeks(1);
        }
    }

    private boolean isConfigured() {
        return Boolean.TRUE.equals(enabled) && StringUtils.hasText(apiKey) && StringUtils.hasText(model);
    }

    
    public boolean aiEnabled() {
        return isConfigured();
    }

    
    public String aiModel() {
        return model;
    }

    



    public String aiText(String instructions, String input) {
        if (!isConfigured()) {
            return null;
        }
        try {
            Map<String, Object> props = new LinkedHashMap<>();
            props.put("message", typeOf("string"));
            JsonNode out = callOpenAi(instructions, input, objectSchema(props, "message"), "wafferha_message");
            String msg = out.path("message").asText(null);
            return StringUtils.hasText(msg) ? msg : null;
        } catch (Exception e) {
            return null;
        }
    }

    private JsonNode callOpenAi(String instructions, String input, Map<String, Object> schema, String schemaName) {
        if (!isConfigured()) {
            throw new ApiException("OpenAI is not configured. Add your key to application-local.properties or set OPENAI_API_KEY.");
        }
        try {
            Map<String, Object> format = new LinkedHashMap<>();
            format.put("type", "json_schema");
            format.put("name", schemaName);
            format.put("strict", true);
            format.put("schema", schema);

            Map<String, Object> text = new LinkedHashMap<>();
            text.put("format", format);

            Map<String, Object> reasoning = new LinkedHashMap<>();
            reasoning.put("effort", "low");

            Map<String, Object> body = new LinkedHashMap<>();
            body.put("model", model.trim());
            body.put("instructions", instructions);
            body.put("input", input);
            body.put("max_output_tokens", 1000);
            body.put("text", text);
            body.put("reasoning", reasoning);

            JsonNode response = restTemplate.postForObject(
                    responsesUrl.trim(),
                    new HttpEntity<>(body, createHeaders()),
                    JsonNode.class
            );
            String outputText = extractOutputText(response);
            if (!StringUtils.hasText(outputText)) {
                throw new ApiException("AI returned no content");
            }
            return objectMapper.readTree(outputText);
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException("AI request failed: " + e.getMessage());
        }
    }

    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(apiKey.trim());
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

    private String extractOutputText(JsonNode response) {
        if (response == null) {
            return null;
        }
        JsonNode outputText = response.path("output_text");
        if (outputText.isTextual()) {
            return outputText.asText();
        }
        for (JsonNode outputItem : response.path("output")) {
            for (JsonNode contentItem : outputItem.path("content")) {
                JsonNode textNode = contentItem.path("text");
                if (textNode.isTextual()) {
                    return textNode.asText();
                }
            }
        }
        return null;
    }

    private Map<String, Object> taskSchema() {
        Map<String, Object> properties = new LinkedHashMap<>();
        properties.put("title", typeOf("string"));
        properties.put("type", stringEnum("save", "noSpend", "log", "rate", "streak"));
        properties.put("cadence", stringEnum("DAILY", "WEEKLY", "MONTHLY"));
        properties.put("targetValue", typeOf("number"));
        properties.put("rewardPoints", typeOf("integer"));
        return objectSchema(properties, "title", "type", "cadence", "targetValue", "rewardPoints");
    }

    private Map<String, Object> questionSchema() {
        Map<String, Object> options = new LinkedHashMap<>();
        options.put("type", "array");
        options.put("items", typeOf("string"));

        Map<String, Object> properties = new LinkedHashMap<>();
        properties.put("question", typeOf("string"));
        properties.put("options", options);
        properties.put("correctAnswer", typeOf("string"));
        properties.put("explanation", typeOf("string"));
        return objectSchema(properties, "question", "options", "correctAnswer", "explanation");
    }

    private Map<String, Object> objectSchema(Map<String, Object> properties, String... required) {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        schema.put("additionalProperties", false);
        schema.put("properties", properties);
        schema.put("required", List.of(required));
        return schema;
    }

    private Map<String, Object> stringEnum(String... values) {
        Map<String, Object> node = new LinkedHashMap<>();
        node.put("type", "string");
        node.put("enum", List.of(values));
        return node;
    }

    private Map<String, Object> typeOf(String type) {
        Map<String, Object> node = new LinkedHashMap<>();
        node.put("type", type);
        return node;
    }

    private String upperOrDefault(String value, String fallback) {
        return StringUtils.hasText(value) ? value.toUpperCase() : fallback;
    }

    private String defaultIfBlank(String value, String fallback) {
        return StringUtils.hasText(value) ? value : fallback;
    }

    

    public List<InsightOutDTO> getAllInsights() {
        return insightRepository.findAll().stream()
                .map(this::insightToDto)
                .collect(java.util.stream.Collectors.toList());
    }

    public InsightOutDTO getInsightById(Integer id) {
        return insightToDto(getInsightEntity(id));
    }

    public List<InsightOutDTO> getInsightsByUser(Integer userId) {
        return insightRepository.findByUserId(userId).stream()
                .map(this::insightToDto)
                .collect(java.util.stream.Collectors.toList());
    }

    
    public List<InsightOutDTO> filterInsightsByUser(Integer userId, String type) {
        return insightRepository.findByUserId(userId).stream()
                .filter(i -> type == null || type.equalsIgnoreCase(i.getType()))
                .map(this::insightToDto)
                .collect(java.util.stream.Collectors.toList());
    }

    private Insight getInsightEntity(Integer id) {
        return insightRepository.findById(id)
                .orElseThrow(() -> new ApiException("Insight was not found"));
    }

    private InsightOutDTO insightToDto(Insight entity) {
        return new InsightOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getMessage(),
                entity.getType(),
                entity.getGeneratedAt());
    }

    

    public List<DailyQuestionOutDTO> getAllDailyQuestions() {
        return dailyQuestionRepository.findAll().stream()
                .map(this::dailyQuestionToDto)
                .collect(java.util.stream.Collectors.toList());
    }

    public DailyQuestionOutDTO getDailyQuestionById(Integer id) {
        return dailyQuestionToDto(getDailyQuestionEntity(id));
    }

    public List<DailyQuestionOutDTO> getDailyQuestionsByUser(Integer userId) {
        return dailyQuestionRepository.findByUserId(userId).stream()
                .map(this::dailyQuestionToDto)
                .collect(java.util.stream.Collectors.toList());
    }

    
    public List<DailyQuestionOutDTO> filterDailyQuestionsByUser(Integer userId, Boolean answered) {
        return dailyQuestionRepository.findByUserId(userId).stream()
                .filter(q -> answered == null || answered.equals(q.isAnswered()))
                .map(this::dailyQuestionToDto)
                .collect(java.util.stream.Collectors.toList());
    }

    private DailyQuestion getDailyQuestionEntity(Integer id) {
        return dailyQuestionRepository.findById(id)
                .orElseThrow(() -> new ApiException("Daily question was not found"));
    }

    private DailyQuestionOutDTO dailyQuestionToDto(DailyQuestion entity) {
        return new DailyQuestionOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getQuestion(),
                entity.getOptions(),
                entity.getCorrectAnswer(),
                entity.getExplanation(),
                entity.getRewardPoints(),
                entity.getQuestionDate(),
                entity.isAnswered(),
                entity.isAnsweredCorrectly());
    }
}
