package com.wafferha.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.wafferha.Model.BaselineIncome;
import com.wafferha.Model.BehaviorEvent;
import com.wafferha.Repository.BehaviorEventRepository;
import com.wafferha.Repository.UserRepository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
















@Service
public class OpenBankingService {

    private static final Logger log = LoggerFactory.getLogger(OpenBankingService.class);

    @Value("${openbanking.enabled:false}")
    private Boolean enabled;

    @Value("${openbanking.provider:tarabut}")
    private String provider;

    @Value("${openbanking.client-id:}")
    private String clientId;

    @Value("${openbanking.client-secret:}")
    private String clientSecret;

    @Value("${openbanking.redirect-uri:}")
    private String redirectUri;

    
    @Value("${openbanking.auth-url:https://oauth.tarabutgateway.io/sandbox/token}")
    private String authUrl;

    
    @Value("${openbanking.base-url:https://api.sau.sandbox.tarabutgateway.io}")
    private String baseUrl;

    
    @Value("${openbanking.sample-fallback:true}")
    private Boolean sampleFallback;

    private final BehaviorEventRepository behaviorEventRepository;
    private final BehaviorService behaviorService;
    private final UserRepository userRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    public OpenBankingService(BehaviorEventRepository behaviorEventRepository,
                              BehaviorService behaviorService,
                              UserRepository userRepository) {
        this.behaviorEventRepository = behaviorEventRepository;
        this.behaviorService = behaviorService;
        this.userRepository = userRepository;
    }

    
    public boolean isConfigured() {
        return Boolean.TRUE.equals(enabled)
                && StringUtils.hasText(clientId)
                && StringUtils.hasText(clientSecret);
    }

    
    private String customerUserId(Integer userId) {
        return "wafferha-" + userId;
    }

    





    public String getAccessToken(Integer userId) {
        if (!isConfigured()) {
            return null;
        }
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            if (userId != null) {
                headers.set("X-TG-CustomerUserId", customerUserId(userId));
            }

            Map<String, Object> body = new LinkedHashMap<>();
            body.put("clientId", clientId.trim());
            body.put("clientSecret", clientSecret.trim());
            body.put("grantType", "client_credentials");

            ResponseEntity<JsonNode> res = restTemplate.exchange(
                    authUrl.trim(), HttpMethod.POST, new HttpEntity<>(body, headers), JsonNode.class);

            JsonNode b = res.getBody();
            String token = b == null ? null : firstNonEmpty(
                    b.path("accessToken").asText(null),
                    b.path("access_token").asText(null),
                    b.path("token").asText(null));
            if (token != null) {
                log.info("Tarabut: obtained access token for {} (expires ~{}s)",
                        userId == null ? "app" : customerUserId(userId), b.path("expiresIn").asInt(900));
            }
            return token;
        } catch (Exception e) {
            log.warn("Tarabut token exchange failed: {}", e.getMessage());
            return null;
        }
    }

    




    public Map<String, Object> linkAccount(Integer userId) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (!isConfigured()) {
            out.put("configured", false);
            out.put("message", "Open banking not configured - set openbanking.* in application-local.properties");
            return out;
        }
        String token = getAccessToken(userId);
        out.put("configured", true);
        out.put("provider", provider);
        out.put("customerUserId", customerUserId(userId));
        out.put("tokenObtained", token != null);
        out.put("redirectUri", redirectUri);

        if (token != null) {
            try {
                JsonNode intent = createConnectIntent(userId, token);
                if (intent != null) {
                    out.put("connectUrl", intent.path("connectUrl").asText(null));
                    out.put("intentId", intent.path("intentId").asText(null));
                    out.put("expiry", intent.path("expiry").asText(null));
                }
            } catch (Exception e) {
                log.warn("Tarabut create-intent for user {} failed: {}", userId, e.getMessage());
                out.put("intentError", e.getMessage());
            }
        }

        boolean haveUrl = out.get("connectUrl") != null;
        out.put("message", haveUrl
                ? "Open connectUrl to link a bank (consent), then POST /api/open-banking/import/" + userId
                : token != null
                    ? "Authenticated with Tarabut, but could not create a Connect intent - check the redirect URL / entitlements."
                    : "Could not reach the Tarabut token endpoint - check credentials/network.");
        return out;
    }

    




    private JsonNode createConnectIntent(Integer userId, String token) {
        Map<String, Object> user = new LinkedHashMap<>();
        user.put("customerUserId", customerUserId(userId));
        user.put("firstName", "Wafferha");
        user.put("lastName", "User" + userId);
        user.put("email", "user" + userId + "@wafferha.app");

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("user", user);
        body.put("redirectUrl", StringUtils.hasText(redirectUri) ? redirectUri.trim() : "http://localhost:3000/callback");
        body.put("providerType", "Retail");
        body.put("language", "EN");

        HttpHeaders headers = bearer(userId, token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        ResponseEntity<JsonNode> res = restTemplate.exchange(
                baseUrl.trim() + "/accountInformation/v1/intent",
                HttpMethod.POST, new HttpEntity<>(body, headers), JsonNode.class);
        return res.getBody();
    }

    





    @Transactional
    public Map<String, Object> importTransactions(Integer userId) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (!isConfigured()) {
            out.put("configured", false);
            out.put("imported", 0);
            return out;
        }
        out.put("configured", true);

        String token = getAccessToken(userId);
        out.put("tokenObtained", token != null);

        List<BehaviorEvent> events = new ArrayList<>();
        String source = "none";

        if (token != null) {
            try {
                List<String> accountIds = fetchAccountIds(userId, token);
                for (String accountId : accountIds) {
                    events.addAll(fetchTransactions(userId, token, accountId));
                }
                if (!events.isEmpty()) {
                    source = "tarabut-ais";
                    userRepository.findById(userId).ifPresent(u -> {
                        u.setBankVerified(true);
                        
                        if (!"FLAGGED".equalsIgnoreCase(u.getIntegrityStatus())) {
                            u.setIntegrityStatus("VERIFIED");
                        }
                        userRepository.save(u);
                    });
                }
            } catch (Exception e) {
                
                log.warn("Tarabut AIS read for user {} returned no data: {}", userId, e.getMessage());
            }
        }

        if (events.isEmpty() && Boolean.TRUE.equals(sampleFallback)) {
            events = sampleTransactions(userId);
            source = "sandbox-sample";
        }

        if (!events.isEmpty()) {
            behaviorEventRepository.saveAll(events);
            BaselineIncome baseline = behaviorService.recompute(userId);
            out.put("baselineIncomeValue", baseline == null ? null : baseline.getBaselineIncomeValue());
        }
        out.put("source", source);
        out.put("imported", events.size());
        return out;
    }

    
    private List<String> fetchAccountIds(Integer userId, String token) {
        List<String> ids = new ArrayList<>();
        ResponseEntity<JsonNode> res = restTemplate.exchange(
                baseUrl.trim() + "/accountInformation/v2/accounts",
                HttpMethod.GET, new HttpEntity<>(bearer(userId, token)), JsonNode.class);
        JsonNode accounts = res.getBody() == null ? null : res.getBody().path("accounts");
        if (accounts != null && accounts.isArray()) {
            for (JsonNode a : accounts) {
                String id = a.path("accountId").asText(null);
                if (StringUtils.hasText(id)) {
                    ids.add(id);
                }
            }
        }
        return ids;
    }

    
    private List<BehaviorEvent> fetchTransactions(Integer userId, String token, String accountId) {
        ResponseEntity<JsonNode> res = restTemplate.exchange(
                baseUrl.trim() + "/accountInformation/v2/accounts/" + accountId + "/transactions",
                HttpMethod.GET, new HttpEntity<>(bearer(userId, token)), JsonNode.class);
        return mapTransactions(userId, res.getBody());
    }

    private HttpHeaders bearer(Integer userId, String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        headers.set("X-TG-CustomerUserId", customerUserId(userId));
        return headers;
    }

    






    private List<BehaviorEvent> mapTransactions(Integer userId, JsonNode body) {
        List<BehaviorEvent> events = new ArrayList<>();
        if (body == null) {
            return events;
        }
        JsonNode array = body.has("transactions") ? body.path("transactions")
                : body.isArray() ? body
                : body.path("data");
        if (array == null || !array.isArray()) {
            return events;
        }

        for (JsonNode tx : array) {
            JsonNode amountNode = tx.path("amount");
            double value = amountNode.has("value") ? amountNode.path("value").asDouble(0.0)
                    : amountNode.asDouble(0.0);
            String creditDebit = tx.path("creditDebitIndicator").asText("");
            String direction = creditDebit.toLowerCase().startsWith("credit") ? "IN" : "OUT";
            String category = firstNonEmpty(
                    tx.path("category").asText(null),
                    tx.path("transactionDescription").asText(null),
                    "Imported");

            BehaviorEvent event = new BehaviorEvent();
            event.setUserId(userId);
            event.setSourceId(0); 
            event.setValue(BigDecimal.valueOf(Math.abs(value)));
            event.setCategory(category);
            event.setDirection(direction);
            events.add(event);
        }
        return events;
    }

    



    private List<BehaviorEvent> sampleTransactions(Integer userId) {
        List<BehaviorEvent> events = new ArrayList<>();
        events.add(sample(userId, 12000, "Salary", "IN"));
        events.add(sample(userId, 2500, "Rent", "OUT"));
        events.add(sample(userId, 850, "Groceries", "OUT"));
        events.add(sample(userId, 300, "Utilities", "OUT"));
        events.add(sample(userId, 180, "Coffee", "OUT"));
        events.add(sample(userId, 600, "Dining", "OUT"));
        return events;
    }

    private BehaviorEvent sample(Integer userId, double value, String category, String direction) {
        BehaviorEvent e = new BehaviorEvent();
        e.setUserId(userId);
        e.setSourceId(0);
        e.setValue(BigDecimal.valueOf(value));
        e.setCategory(category);
        e.setDirection(direction);
        return e;
    }

    private static String firstNonEmpty(String... values) {
        for (String v : values) {
            if (StringUtils.hasText(v)) {
                return v;
            }
        }
        return null;
    }
}
