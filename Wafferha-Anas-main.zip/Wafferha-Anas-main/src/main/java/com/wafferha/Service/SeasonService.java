package com.wafferha.Service;


import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.SeasonInDTO;
import com.wafferha.DTO.Out.LeaderBoardEntryOutDTO;
import com.wafferha.DTO.Out.SeasonOutDTO;
import com.wafferha.Model.Item;
import com.wafferha.Model.League;
import com.wafferha.Model.Season;
import com.wafferha.Model.User;
import com.wafferha.Model.UserReward;
import com.wafferha.Repository.ItemRepository;
import com.wafferha.Repository.LeagueRepository;
import com.wafferha.Repository.SeasonRepository;
import com.wafferha.Repository.UserRepository;
import com.wafferha.Repository.UserRewardRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;








@Service
@RequiredArgsConstructor
public class SeasonService {

    private static final Logger log = LoggerFactory.getLogger(SeasonService.class);

    private final SeasonRepository seasonRepository;
    private final ResetJobService resetJobService;
    private final UserRepository userRepository;
    private final LeagueRepository leagueRepository;
    private final LeaderBoardService leaderBoardService;
    private final UserRewardRepository userRewardRepository;
    private final ItemRepository itemRepository;

    
    @Transactional
    public SeasonOutDTO activate(Integer id) {
        Season season = seasonRepository.findSeasonById(id);
        if (season == null) {
            throw new ApiException("Season not found");
        }
        season.setStatus("ACTIVE");
        return fromEntity(seasonRepository.save(season));
    }

    



    @Transactional
    public SeasonOutDTO end(Integer id, Integer adminId) {
        
        
        Season season = seasonRepository.findSeasonById(id);
        if (season == null) {
            throw new ApiException("Season not found");
        }
        season.setStatus("ENDED");
        Season ended = seasonRepository.save(season);
        resetJobService.runSeasonalReset();
        
        awardTopOfEachLeague(ended);
        return fromEntity(ended);
    }

    



    public SeasonOutDTO getActive() {
        LocalDateTime now = LocalDateTime.now();
        List<Season> seasons = seasonRepository.findAll();

        Season active = seasons.stream()
                .filter(s -> "ACTIVE".equalsIgnoreCase(s.getStatus()))
                .max(Comparator.comparing(Season::getStartAt,
                        Comparator.nullsFirst(Comparator.naturalOrder())))
                .orElse(null);

        if (active == null) {
            active = seasons.stream()
                    .filter(s -> s.getStartAt() != null && !now.isBefore(s.getStartAt()))
                    .filter(s -> s.getEndAt() != null && !now.isAfter(s.getEndAt()))
                    .max(Comparator.comparing(Season::getStartAt))
                    .orElse(null);
        }

        return active == null ? null : fromEntity(active);
    }

    public List<SeasonOutDTO> getAllSeasons() {
        return seasonRepository.findAll()
                .stream()
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    public void addSeason(SeasonInDTO dto) {
        seasonRepository.save(toEntity(dto));
    }

    
    
    

    





    @Transactional
    public int awardTopOfEachLeague(Season season) {
        Item coupon = couponItem();
        if (coupon == null) {
            log.warn("No COUPON item found - skipping season winner rewards");
            return 0;
        }
        int awarded = 0;
        for (League league : leagueRepository.findAll()) {
            try {
                List<LeaderBoardEntryOutDTO> ranked =
                        leaderBoardService.buildForLeague(league.getId(), "MONTHLY");
                if (ranked.isEmpty() || ranked.get(0).getUserId() == null) {
                    continue;
                }
                Integer winnerId = ranked.get(0).getUserId();
                if (alreadyAwarded(winnerId, season.getId())) {
                    continue;
                }
                User winner = userRepository.findUserById(winnerId);
                if (winner == null) {
                    continue;
                }
                UserReward reward = new UserReward();
                reward.setUser(winner);
                reward.setItem(coupon);
                reward.setSeason(season);
                reward.setSourceType("SEASON_REWARD");
                reward.setPurchaseCurrency("AWARD");
                reward.setEquipped(false);
                reward.setAcquiredAt(LocalDateTime.now());
                userRewardRepository.save(reward);
                awarded++;
                log.info("Season '{}': league '{}' winner = user {} ({})",
                        season.getName(), league.getName(), winnerId, winner.getName());
            } catch (Exception e) {
                log.warn("Winner reward failed for league {}: {}", league.getId(), e.getMessage());
            }
        }
        log.info("Season '{}' ended: awarded {} champion coupon(s)", season.getName(), awarded);
        return awarded;
    }

    private Item couponItem() {
        
        return itemRepository.findAll().stream()
                .filter(i -> "COUPON".equalsIgnoreCase(i.getType()) && Boolean.TRUE.equals(i.getAwardOnly()))
                .findFirst()
                .orElse(null);
    }

    
    private boolean alreadyAwarded(Integer userId, Integer seasonId) {
        return userRewardRepository.findByUser_Id(userId).stream()
                .anyMatch(r -> "SEASON_REWARD".equals(r.getSourceType())
                        && r.getSeason() != null
                        && seasonId.equals(r.getSeason().getId()));
    }

    

    public Season toEntity(SeasonInDTO dto) {
        Season season = new Season();
        season.setSeasonType(dto.getSeasonType());
        season.setName(dto.getName());
        season.setTheme(dto.getTheme());
        season.setYear(dto.getYear());
        season.setStartAt(dto.getStartAt());
        season.setEndAt(dto.getEndAt());
        season.setPointsExpireAt(dto.getPointsExpireAt());
        season.setStatus(dto.getStatus());
        return season;
    }

    public SeasonOutDTO fromEntity(Season season) {
        SeasonOutDTO dto = new SeasonOutDTO();
        dto.setId(season.getId());
        dto.setSeasonType(season.getSeasonType());
        dto.setName(season.getName());
        dto.setTheme(season.getTheme());
        dto.setYear(season.getYear());
        dto.setStartAt(season.getStartAt());
        dto.setEndAt(season.getEndAt());
        dto.setPointsExpireAt(season.getPointsExpireAt());
        dto.setStatus(season.getStatus());
        return dto;
    }
}
