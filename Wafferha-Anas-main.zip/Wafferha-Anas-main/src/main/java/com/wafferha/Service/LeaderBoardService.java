package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.LeaderBoardEntryInDTO;
import com.wafferha.DTO.In.LeaderBoardInDTO;
import com.wafferha.DTO.Out.LeaderBoardEntryOutDTO;
import com.wafferha.DTO.Out.LeaderBoardOutDTO;
import com.wafferha.Model.IntegrityFlag;
import com.wafferha.Model.LeaderBoard;
import com.wafferha.Model.LeaderBoardEntry;
import com.wafferha.Model.League;
import com.wafferha.Model.Score;
import com.wafferha.Model.User;
import com.wafferha.Repository.IntegrityFlagRepository;
import com.wafferha.Repository.LeaderBoardEntryRepository;
import com.wafferha.Repository.LeaderBoardRepository;
import com.wafferha.Repository.LeagueRepository;
import com.wafferha.Repository.ScoreRepository;
import com.wafferha.Repository.UserRepository;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;





@Service
@RequiredArgsConstructor
public class LeaderBoardService {

    private final LeaderBoardRepository leaderBoardRepository;
    private final LeagueRepository leagueRepository;
    private final LeaderBoardEntryRepository leaderBoardEntryRepository;
    private final UserRepository userRepository;
    private final IntegrityFlagRepository integrityFlagRepository;
    private final ScoreRepository scoreRepository;

    
    
    

    







    @Transactional
    public List<LeaderBoardEntryOutDTO> buildForLeague(Integer leagueId, String period) {
        League league = leagueRepository.findLeagueById(leagueId);
        if (league == null) {
            throw new ApiException("League not found");
        }
        String normalizedPeriod = normalizePeriod(period);

        
        LeaderBoard board = new LeaderBoard();
        board.setLeague(league);
        board.setPeriod(normalizedPeriod);
        board.setSnapshotAt(LocalDateTime.now());
        board = leaderBoardRepository.save(board);

        
        List<RankedUser> ranked = new ArrayList<>();
        for (User user : userRepository.findByLeague_Id(leagueId)) {
            if (!isEligible(user.getId())) {
                continue;
            }
            Score latest = latestScore(user.getId(), normalizedPeriod);
            if (latest == null || latest.getCompositeScore() == null) {
                continue;
            }
            ranked.add(new RankedUser(user, latest.getCompositeScore().doubleValue()));
        }

        
        ranked.sort(Comparator.comparingDouble((RankedUser r) -> r.score).reversed());

        List<LeaderBoardEntryOutDTO> result = new ArrayList<>();
        int rank = 1;
        for (RankedUser r : ranked) {
            LeaderBoardEntry entry = new LeaderBoardEntry();
            entry.setLeaderboard(board);
            entry.setUser(r.user);
            entry.setRank(rank++);
            entry.setScore(r.score);
            result.add(entryFromEntity(leaderBoardEntryRepository.save(entry)));
        }
        return result;
    }

    
    private boolean isEligible(Integer userId) {
        IntegrityFlag flag = integrityFlagRepository.findByUser_Id(userId);
        return flag != null && Boolean.TRUE.equals(flag.getCompetitiveEligible());
    }

    
    private Score latestScore(Integer userId, String period) {
        List<Score> history = scoreRepository.findByUserIdAndPeriodOrderByComputedAtDesc(userId, period);
        return history.isEmpty() ? null : history.get(0);
    }

    private String normalizePeriod(String period) {
        if (period == null) {
            throw new ApiException("Period must be WEEKLY, MONTHLY or YEARLY");
        }
        String p = period.trim().toUpperCase();
        if (!p.equals("WEEKLY") && !p.equals("MONTHLY") && !p.equals("YEARLY")) {
            throw new ApiException("Period must be WEEKLY, MONTHLY or YEARLY");
        }
        return p;
    }

    
    private static final class RankedUser {
        private final User user;
        private final double score;

        private RankedUser(User user, double score) {
            this.user = user;
            this.score = score;
        }
    }

    
    
    

    public LeaderBoardOutDTO addLeaderboard(Integer leagueId, LeaderBoardInDTO dto) {
        League league = leagueRepository.findLeagueById(leagueId);
        if (league == null) {
            throw new ApiException("League not found");
        }
        LeaderBoard leaderboard = toEntity(dto);
        leaderboard.setLeague(league);
        return fromEntity(leaderBoardRepository.save(leaderboard));
    }

    public List<LeaderBoardOutDTO> getLeaderBoards() {
        return leaderBoardRepository.findAll()
                .stream().map(this::fromEntity).collect(Collectors.toList());
    }

    



    public List<LeaderBoardEntryOutDTO> getTopEntries(Integer boardId, int limit) {
        LeaderBoard board = leaderBoardRepository.findLeaderBoardById(boardId);
        if (board == null) {
            throw new ApiException("LeaderBoard not found");
        }
        Comparator<LeaderBoardEntry> byRank = Comparator.comparing(
                LeaderBoardEntry::getRank, Comparator.nullsLast(Comparator.naturalOrder()));
        Comparator<LeaderBoardEntry> byScoreDesc = Comparator.comparing(
                LeaderBoardEntry::getScore, Comparator.nullsLast(Comparator.reverseOrder()));
        return leaderBoardEntryRepository.findByLeaderboard_Id(boardId).stream()
                .sorted(byRank.thenComparing(byScoreDesc))
                .limit(Math.max(0, limit))
                .map(this::entryFromEntity)
                .collect(Collectors.toList());
    }

    public List<LeaderBoardOutDTO> getLeaderBoardsByLeague(Integer leagueId) {
        return leaderBoardRepository.findByLeague_Id(leagueId)
                .stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public LeaderBoard toEntity(LeaderBoardInDTO dto) {
        LeaderBoard lb = new LeaderBoard();
        lb.setPeriod(dto.getPeriod());
        lb.setSnapshotAt(dto.getSnapshotAt());
        return lb;
    }

    public LeaderBoardOutDTO fromEntity(LeaderBoard lb) {
        LeaderBoardOutDTO dto = new LeaderBoardOutDTO();
        dto.setId(lb.getId());
        dto.setPeriod(lb.getPeriod());
        dto.setSnapshotAt(lb.getSnapshotAt());
        if (lb.getLeague() != null) {
            dto.setLeagueId(lb.getLeague().getId());
            
            dto.setLeagueName(LeagueService.displayLabel(lb.getLeague()));
        }
        return dto;
    }

    
    
    

    public LeaderBoardEntryOutDTO addEntry(Integer userId, Integer leaderboardId, LeaderBoardEntryInDTO dto) {
        User user = userRepository.findUserById(userId);
        if (user == null) {
            throw new ApiException("User not found");
        }
        LeaderBoard leaderboard = leaderBoardRepository.findLeaderBoardById(leaderboardId);
        if (leaderboard == null) {
            throw new ApiException("LeaderBoard not found");
        }
        LeaderBoardEntry entry = entryToEntity(dto);
        entry.setUser(user);
        entry.setLeaderboard(leaderboard);
        return entryFromEntity(leaderBoardEntryRepository.save(entry));
    }

    public List<LeaderBoardEntryOutDTO> getEntries() {
        return leaderBoardEntryRepository.findAll()
                .stream().map(this::entryFromEntity).collect(Collectors.toList());
    }

    public List<LeaderBoardEntryOutDTO> getEntriesByUser(Integer userId) {
        return leaderBoardEntryRepository.findByUser_Id(userId)
                .stream().map(this::entryFromEntity).collect(Collectors.toList());
    }

    




    public Map<String, Object> getUserRank(Integer userId, String period) {
        LeaderBoardEntry best = leaderBoardEntryRepository.findByUser_Id(userId).stream()
                .filter(e -> period == null || period.isBlank()
                        || (e.getLeaderboard() != null && period.equalsIgnoreCase(e.getLeaderboard().getPeriod())))
                .min(Comparator.comparing(LeaderBoardEntry::getRank,
                        Comparator.nullsLast(Comparator.naturalOrder())))
                .orElseThrow(() -> new ApiException("No leaderboard entry found for this user"));

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("rank", best.getRank());
        result.put("percentile", null);
        result.put("score", best.getScore());
        return result;
    }

    public List<LeaderBoardEntryOutDTO> getEntriesByLeaderboard(Integer leaderboardId) {
        return leaderBoardEntryRepository.findByLeaderboard_Id(leaderboardId)
                .stream().map(this::entryFromEntity).collect(Collectors.toList());
    }

    public LeaderBoardEntry entryToEntity(LeaderBoardEntryInDTO dto) {
        LeaderBoardEntry entry = new LeaderBoardEntry();
        entry.setRank(dto.getRank());
        entry.setScore(dto.getScore());
        return entry;
    }

    public LeaderBoardEntryOutDTO entryFromEntity(LeaderBoardEntry entry) {
        LeaderBoardEntryOutDTO dto = new LeaderBoardEntryOutDTO();
        dto.setId(entry.getId());
        dto.setRank(entry.getRank());
        dto.setScore(entry.getScore());
        if (entry.getUser() != null) {
            dto.setUserId(entry.getUser().getId());
            dto.setUserName(entry.getUser().getName());
        }
        if (entry.getLeaderboard() != null) {
            dto.setLeaderboardId(entry.getLeaderboard().getId());
        }
        return dto;
    }
}
