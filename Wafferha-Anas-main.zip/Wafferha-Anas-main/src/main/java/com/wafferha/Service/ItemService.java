package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.ItemInDTO;
import com.wafferha.DTO.Out.ItemOutDTO;
import com.wafferha.Model.Item;
import com.wafferha.Model.Season;
import com.wafferha.Repository.ItemRepository;
import com.wafferha.Repository.SeasonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ItemService {

    private final ItemRepository itemRepository;
    private final SeasonRepository seasonRepository;

    public List<ItemOutDTO> getAllItems() {
        return itemRepository.findAll()
                .stream()
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    public List<ItemOutDTO> getItemsBySeason(Integer seasonId) {
        return itemRepository.findBySeason_Id(seasonId)
                .stream()
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    



    public List<ItemOutDTO> filter(String currencyType, Integer seasonId, Double maxCost) {
        return itemRepository.findAll().stream()
                .filter(i -> currencyType == null || currencyType.equalsIgnoreCase(i.getCurrencyType()))
                .filter(i -> seasonId == null || (i.getSeason() != null && seasonId.equals(i.getSeason().getId())))
                .filter(i -> maxCost == null || (i.getCost() != null && i.getCost() <= maxCost))
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    public void addItem(Integer seasonId, ItemInDTO dto) {

        Season season = seasonRepository.findSeasonById(seasonId);

        if (season == null) {
            throw new ApiException("Season not found");
        }

        Item item = toEntity(dto);
        item.setSeason(season);

        itemRepository.save(item);
    }

    

    public Item toEntity(ItemInDTO dto) {
        Item item = new Item();
        item.setName(dto.getName());
        item.setType(dto.getType());
        item.setCost(dto.getCost());
        item.setCurrencyType(dto.getCurrencyType());
        item.setRarity(dto.getRarity());
        item.setAvailableFrom(dto.getAvailableFrom());
        item.setAvailableUntil(dto.getAvailableUntil());
        item.setIsSeasonExclusive(dto.getIsSeasonExclusive());
        item.setUnlockCondition(dto.getUnlockCondition());
        return item;
    }

    public ItemOutDTO fromEntity(Item item) {
        ItemOutDTO dto = new ItemOutDTO();
        dto.setId(item.getId());
        dto.setName(item.getName());
        dto.setType(item.getType());
        dto.setCost(item.getCost());
        dto.setCurrencyType(item.getCurrencyType());
        dto.setRarity(item.getRarity());
        dto.setAvailableFrom(item.getAvailableFrom());
        dto.setAvailableUntil(item.getAvailableUntil());
        dto.setIsSeasonExclusive(item.getIsSeasonExclusive());
        dto.setUnlockCondition(item.getUnlockCondition());
        dto.setSeasonId(item.getSeason() == null ? null : item.getSeason().getId());
        return dto;
    }
}
