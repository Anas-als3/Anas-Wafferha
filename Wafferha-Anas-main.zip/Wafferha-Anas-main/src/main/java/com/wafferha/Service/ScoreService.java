package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.Out.ScoreOutDTO;
import com.wafferha.Model.BaselineIncome;
import com.wafferha.Model.IntegrityFlag;
import com.wafferha.Model.Score;
import com.wafferha.Model.User;
import com.wafferha.Repository.BaselineIncomeRepository;
import com.wafferha.Repository.IntegrityFlagRepository;
import com.wafferha.Repository.ScoreRepository;
import com.wafferha.Repository.UserChallengeRepository;
import com.wafferha.Repository.UserRepository;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

















@Service
@RequiredArgsConstructor
public class ScoreService {

    
    private static final double RATE_WEIGHT = 0.60;
    private static final double CONSISTENCY_WEIGHT = 0.25;
    private static final double IMPROVEMENT_WEIGHT = 0.15;

    
    public static final double SAVINGS_TARGET_RATE = 0.40;
    private static final double WEEKS_PER_MONTH = 4.345;
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);

    private final ScoreRepository scoreRepository;
    private final UserRepository userRepository;
    private final BaselineIncomeRepository baselineIncomeRepository;
    private final IntegrityFlagRepository integrityFlagRepository;
    private final UserChallengeRepository userChallengeRepository;

    
    
    

    



    @Transactional
    public ScoreOutDTO computeForUser(Integer userId, String period) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));
        String normalizedPeriod = normalizePeriod(period);

        
        
        LocalDateTime windowStart = windowStart(normalizedPeriod);

        BigDecimal rateSubscore = computeRateSubscore(userId, normalizedPeriod, windowStart);
        BigDecimal consistencySubscore = computeConsistencySubscore(userId, windowStart);
        BigDecimal improvementSubscore = computeImprovementSubscore(userId, normalizedPeriod, rateSubscore);

        BigDecimal compositeScore = blend(rateSubscore, consistencySubscore, improvementSubscore);

        Score score = new Score();
        score.setUserId(userId);
        score.setPeriod(normalizedPeriod);
        score.setRateSubscore(rateSubscore);
        score.setConsistencySubscore(consistencySubscore);
        score.setImprovementSubscore(improvementSubscore);
        score.setCompositeScore(compositeScore);
        
        score.setPercentileInLeague(percentileInLeague(user, normalizedPeriod, compositeScore));
        Score saved = scoreRepository.save(score);

        return fromEntity(saved);
    }

    




    private BigDecimal computeRateSubscore(Integer userId, String period, LocalDateTime windowStart) {
        double saved = userChallengeRepository.sumSavedSince(userId, windowStart);
        double income = incomeForPeriod(userId, period);
        if (income <= 0) {
            
            return BigDecimal.ZERO.setScale(4, RoundingMode.HALF_UP);
        }
        double rate = Math.min(saved / income, SAVINGS_TARGET_RATE);
        if (rate < 0) {
            rate = 0;
        }
        return BigDecimal.valueOf(rate).setScale(4, RoundingMode.HALF_UP);
    }

    



    private BigDecimal computeConsistencySubscore(Integer userId, LocalDateTime windowStart) {
        List<LocalDateTime> completions = userChallengeRepository.findSaveCompletionsSince(userId, windowStart);
        Set<LocalDate> activeDays = new HashSet<>();
        for (LocalDateTime ts : completions) {
            if (ts != null) {
                activeDays.add(ts.toLocalDate());
            }
        }
        long windowDays = Math.max(1, java.time.Duration.between(windowStart, LocalDateTime.now()).toDays());
        double ratio = Math.min(1.0, activeDays.size() / (double) windowDays);
        return BigDecimal.valueOf(ratio).setScale(4, RoundingMode.HALF_UP);
    }

    




    private BigDecimal computeImprovementSubscore(Integer userId, String period, BigDecimal currentRate) {
        List<Score> history = scoreRepository.findByUserIdAndPeriodOrderByComputedAtDesc(userId, period);
        if (history.isEmpty()) {
            return BigDecimal.valueOf(0.5).setScale(4, RoundingMode.HALF_UP);
        }
        BigDecimal previousRate = history.get(0).getRateSubscore();
        if (previousRate == null) {
            return BigDecimal.valueOf(0.5).setScale(4, RoundingMode.HALF_UP);
        }
        double cap = SAVINGS_TARGET_RATE;
        
        double delta = (currentRate.doubleValue() - previousRate.doubleValue()) / cap;
        double improvement = 0.5 + (delta / 2.0);
        improvement = Math.max(0.0, Math.min(1.0, improvement));
        return BigDecimal.valueOf(improvement).setScale(4, RoundingMode.HALF_UP);
    }

    



    private BigDecimal blend(BigDecimal rate, BigDecimal consistency, BigDecimal improvement) {
        double rateNorm = rate.doubleValue() / SAVINGS_TARGET_RATE; 
        double blended = RATE_WEIGHT * rateNorm
                + CONSISTENCY_WEIGHT * consistency.doubleValue()
                + IMPROVEMENT_WEIGHT * improvement.doubleValue();
        blended = Math.max(0.0, Math.min(1.0, blended));
        return BigDecimal.valueOf(blended).multiply(HUNDRED).setScale(4, RoundingMode.HALF_UP);
    }

    



    private BigDecimal percentileInLeague(User user, String period, BigDecimal compositeScore) {
        if (user.getLeague() == null) {
            return BigDecimal.valueOf(100).setScale(2, RoundingMode.HALF_UP);
        }
        List<User> peers = userRepository.findByLeague_Id(user.getLeague().getId());
        int eligible = 0;
        int atOrBelow = 0;
        for (User peer : peers) {
            if (!isEligible(peer.getId())) {
                continue;
            }
            BigDecimal peerScore = latestComposite(peer.getId(), period);
            if (peerScore == null) {
                continue;
            }
            eligible++;
            if (peerScore.compareTo(compositeScore) <= 0) {
                atOrBelow++;
            }
        }
        if (eligible == 0) {
            return BigDecimal.valueOf(100).setScale(2, RoundingMode.HALF_UP);
        }
        double percentile = (atOrBelow / (double) eligible) * 100.0;
        return BigDecimal.valueOf(percentile).setScale(2, RoundingMode.HALF_UP);
    }

    
    private BigDecimal latestComposite(Integer userId, String period) {
        List<Score> history = scoreRepository.findByUserIdAndPeriodOrderByComputedAtDesc(userId, period);
        return history.isEmpty() ? null : history.get(0).getCompositeScore();
    }

    
    private boolean isEligible(Integer userId) {
        IntegrityFlag flag = integrityFlagRepository.findByUser_Id(userId);
        return flag != null && Boolean.TRUE.equals(flag.getCompetitiveEligible());
    }

    
    private double incomeForPeriod(Integer userId, String period) {
        BaselineIncome baseline = baselineIncomeRepository.findByUserId(userId);
        if (baseline == null || baseline.getBaselineIncomeValue() == null) {
            return 0;
        }
        double monthly = baseline.getBaselineIncomeValue().doubleValue();
        switch (period) {
            case "WEEKLY":
                return monthly / WEEKS_PER_MONTH;
            case "YEARLY":
                return monthly * 12.0;
            case "MONTHLY":
            default:
                return monthly;
        }
    }

    
    private LocalDateTime windowStart(String period) {
        LocalDate today = LocalDate.now();
        switch (period) {
            case "WEEKLY":
                return today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).atStartOfDay();
            case "YEARLY":
                return today.withDayOfYear(1).atStartOfDay();
            case "MONTHLY":
            default:
                return today.withDayOfMonth(1).atStartOfDay();
        }
    }

    private String normalizePeriod(String period) {
        if (period == null) {
            throw new ApiException("Period must be WEEKLY, MONTHLY or YEARLY");
        }
        String p = period.trim().toUpperCase();
        if (!p.equals("WEEKLY") && !p.equals("MONTHLY") && !p.equals("YEARLY")) {
            throw new ApiException("Period must be WEEKLY, MONTHLY or YEARLY");
        }
        return p;
    }

    
    
    

    public List<ScoreOutDTO> getAll() {
        return scoreRepository.findAll().stream()
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    public ScoreOutDTO getById(Integer id) {
        return fromEntity(findById(id));
    }

    
    public List<ScoreOutDTO> getByUserId(Integer userId) {
        return scoreRepository.findByUserId(userId).stream()
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    



    public ScoreOutDTO getLatestForUser(Integer userId, String period) {
        List<Score> scores;
        if (period != null && !period.isBlank()) {
            scores = scoreRepository.findByUserIdAndPeriodOrderByComputedAtDesc(userId, normalizePeriod(period));
        } else {
            scores = scoreRepository.findByUserId(userId);
        }
        return scores.stream()
                .max(Comparator.comparing(Score::getComputedAt))
                .map(this::fromEntity)
                .orElse(null);
    }

    



    public List<ScoreOutDTO> filter(String period, Double minScore, Integer leagueId) {
        final String normalizedPeriod = (period == null || period.isBlank()) ? null : normalizePeriod(period);
        final Set<Integer> leagueUserIds = leagueId == null ? null
                : userRepository.findByLeague_Id(leagueId).stream()
                        .map(User::getId)
                        .collect(Collectors.toSet());

        return scoreRepository.findAll().stream()
                .filter(s -> normalizedPeriod == null || normalizedPeriod.equals(s.getPeriod()))
                .filter(s -> minScore == null
                        || (s.getCompositeScore() != null && s.getCompositeScore().doubleValue() >= minScore))
                .filter(s -> leagueUserIds == null || leagueUserIds.contains(s.getUserId()))
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    public Score findById(Integer id) {
        return scoreRepository.findById(id)
                .orElseThrow(() -> new ApiException("Score was not found"));
    }

    private ScoreOutDTO fromEntity(Score entity) {
        return new ScoreOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getPeriod(),
                entity.getRateSubscore(),
                entity.getConsistencySubscore(),
                entity.getImprovementSubscore(),
                entity.getCompositeScore(),
                entity.getPercentileInLeague(),
                entity.getComputedAt());
    }

    
    
    

    






    public Map<String, Object> capStatus(Integer userId) {
        double monthlyIncome = resolveMonthlyIncome(userId);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("userId", userId);
        out.put("savingsCapRate", "40%");

        if (monthlyIncome <= 0) {
            out.put("monthlyIncomeKnown", false);
            out.put("monthlyCapUsedPct", 0.0);
            out.put("monthlyCapRemainingPct", 100.0);
            out.put("weeklyCapUsedPct", 0.0);
            out.put("weeklyCapRemainingPct", 100.0);
            out.put("capReached", false);
            out.put("earningLeaderboardScore", true);
            out.put("walletPointsStillEarned", true);
            out.put("message", "No income on file yet, so the 40% leaderboard cap is not enforced.");
            return out;
        }

        double monthlyCap = SAVINGS_TARGET_RATE * monthlyIncome;
        double weeklyCap = monthlyCap / WEEKS_PER_MONTH;
        double savedThisMonth = userChallengeRepository.sumSavedSince(userId, startOfMonth());
        double savedThisWeek = userChallengeRepository.sumSavedSince(userId, startOfWeek());

        double monthlyUsedPct = pct(savedThisMonth, monthlyCap);
        double weeklyUsedPct = pct(savedThisWeek, weeklyCap);
        boolean monthlyReached = monthlyUsedPct >= 100.0;
        boolean weeklyReached = weeklyUsedPct >= 100.0;
        boolean capReached = monthlyReached || weeklyReached; 

        out.put("monthlyIncome", round2(monthlyIncome));
        out.put("monthlyCapUsedPct", monthlyUsedPct);
        out.put("monthlyCapRemainingPct", round2(100.0 - monthlyUsedPct));
        out.put("monthlyCapReached", monthlyReached);
        out.put("weeklyCapUsedPct", weeklyUsedPct);
        out.put("weeklyCapRemainingPct", round2(100.0 - weeklyUsedPct));
        out.put("weeklyCapReached", weeklyReached);
        out.put("capReached", capReached);
        out.put("earningLeaderboardScore", !capReached);
        out.put("walletPointsStillEarned", true);
        out.put("message", capReached
                ? "Cap reached - saving more no longer lifts your leaderboard score (rank), but completing tasks still earns wallet points and helps your goals."
                : "Under the 40% cap - saving still lifts your leaderboard score and earns wallet points.");
        return out;
    }

    
    private double pct(double value, double cap) {
        if (cap <= 0) {
            return 0.0;
        }
        double p = (value / cap) * 100.0;
        if (p < 0) {
            p = 0;
        }
        if (p > 100) {
            p = 100;
        }
        return round2(p);
    }

    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    
    private double resolveMonthlyIncome(Integer userId) {
        BaselineIncome baseline = baselineIncomeRepository.findByUserId(userId);
        if (baseline != null && baseline.getBaselineIncomeValue() != null
                && baseline.getBaselineIncomeValue().doubleValue() > 0) {
            return baseline.getBaselineIncomeValue().doubleValue();
        }
        User user = userRepository.findById(userId).orElse(null);
        if (user != null && user.getMonthlyIncome() != null && user.getMonthlyIncome() > 0) {
            return user.getMonthlyIncome();
        }
        return 0;
    }

    private LocalDateTime startOfMonth() {
        return LocalDate.now().withDayOfMonth(1).atStartOfDay();
    }

    private LocalDateTime startOfWeek() {
        return LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).atStartOfDay();
    }
}
