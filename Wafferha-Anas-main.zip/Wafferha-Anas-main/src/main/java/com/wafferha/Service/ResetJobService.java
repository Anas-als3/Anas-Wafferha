package com.wafferha.Service;

import com.wafferha.Model.PointsLedger;
import com.wafferha.Model.Season;
import com.wafferha.Model.SeasonalPointsLedger;
import com.wafferha.Model.SeasonalWallet;
import com.wafferha.Model.Wallet;
import com.wafferha.Repository.PointsLedgerRepository;
import com.wafferha.Repository.SeasonRepository;
import com.wafferha.Repository.SeasonalPointsLedgerRepository;
import com.wafferha.Repository.SeasonalWalletRepository;
import com.wafferha.Repository.WalletRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;












@Component
@RequiredArgsConstructor
public class ResetJobService {

    private static final String STATUS_ACTIVE = "ACTIVE";
    private static final String STATUS_EXPIRED = "EXPIRED";
    private static final String REASON_YEARLY_EXPIRED = "yearly_points_expired";
    private static final String REASON_SEASONAL_EXPIRED = "seasonal_points_expired";

    private final WalletRepository walletRepository;
    private final PointsLedgerRepository pointsLedgerRepository;
    private final SeasonalWalletRepository seasonalWalletRepository;
    private final SeasonalPointsLedgerRepository seasonalPointsLedgerRepository;
    private final SeasonRepository seasonRepository;

    

    
    @Scheduled(cron = "0 5 0 1 1 *")
    public void scheduledYearlyReset() {
        runYearlyReset();
    }

    
    @Scheduled(cron = "0 30 0 * * *")
    public void scheduledSeasonalReset() {
        runSeasonalReset();
    }

    

    






    @Transactional
    public int runYearlyReset() {
        int currentYear = LocalDate.now().getYear();
        List<Wallet> wallets = walletRepository.findAll();
        int expired = 0;
        for (Wallet wallet : wallets) {
            if (!STATUS_ACTIVE.equals(wallet.getStatus())) {
                continue; 
            }
            if (wallet.getYear() >= currentYear) {
                continue; 
            }
            int remaining = wallet.getPointsBalance();
            if (remaining > 0) {
                PointsLedger ledger = new PointsLedger();
                ledger.setUserId(wallet.getUserId());
                ledger.setWalletId(wallet.getId());
                ledger.setYear(wallet.getYear());
                ledger.setAmount(-remaining);
                ledger.setReason(REASON_YEARLY_EXPIRED);
                ledger.setRefId(wallet.getId());
                pointsLedgerRepository.save(ledger);

                wallet.setExpiredPoints(wallet.getExpiredPoints() + remaining);
                wallet.setPointsBalance(0);
            }
            wallet.setStatus(STATUS_EXPIRED);
            walletRepository.save(wallet);
            expired++;
        }
        return expired;
    }

    






    @Transactional
    public int runSeasonalReset() {
        LocalDateTime now = LocalDateTime.now();
        List<SeasonalWallet> wallets = seasonalWalletRepository.findAll();
        int expired = 0;
        for (SeasonalWallet wallet : wallets) {
            if (!STATUS_ACTIVE.equals(wallet.getStatus())) {
                continue; 
            }
            if (!seasonHasEnded(wallet.getSeasonId(), now)) {
                continue; 
            }
            int remaining = wallet.getSeasonalPointsBalance();
            if (remaining > 0) {
                SeasonalPointsLedger ledger = new SeasonalPointsLedger();
                ledger.setUserId(wallet.getUserId());
                ledger.setSeasonId(wallet.getSeasonId());
                ledger.setSeasonalWalletId(wallet.getId());
                ledger.setAmount(-remaining);
                ledger.setReason(REASON_SEASONAL_EXPIRED);
                ledger.setRefId(wallet.getId());
                seasonalPointsLedgerRepository.save(ledger);

                wallet.setExpiredPoints(wallet.getExpiredPoints() + remaining);
                wallet.setSeasonalPointsBalance(0);
            }
            wallet.setStatus(STATUS_EXPIRED);
            seasonalWalletRepository.save(wallet);
            expired++;
        }
        return expired;
    }

    
    private boolean seasonHasEnded(Integer seasonId, LocalDateTime now) {
        if (seasonId == null) {
            return false;
        }
        Season season = seasonRepository.findById(seasonId).orElse(null);
        if (season == null) {
            return false;
        }
        if ("ENDED".equalsIgnoreCase(season.getStatus())) {
            return true;
        }
        if (season.getPointsExpireAt() != null && now.isAfter(season.getPointsExpireAt())) {
            return true;
        }
        return season.getEndAt() != null && now.isAfter(season.getEndAt());
    }
}
