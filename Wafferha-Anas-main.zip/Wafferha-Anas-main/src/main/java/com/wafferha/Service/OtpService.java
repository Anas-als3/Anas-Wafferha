package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.Model.User;
import com.wafferha.Model.VerificationCode;
import com.wafferha.Repository.UserRepository;
import com.wafferha.Repository.VerificationCodeRepository;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;








@Service
@RequiredArgsConstructor
public class OtpService {

    
    private static final int EXPIRY_MINUTES = 5;

    private final VerificationCodeRepository verificationCodeRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;

    






    @Transactional
    public boolean sendOtp(Integer userId) {
        User user = userRepository.findUserById(userId);
        if (user == null) {
            throw new ApiException("User not found");
        }

        String code = generateCode();

        VerificationCode verificationCode = new VerificationCode();
        verificationCode.setUserId(userId);
        verificationCode.setCode(code);
        verificationCode.setExpiresAt(LocalDateTime.now().plusMinutes(EXPIRY_MINUTES));
        verificationCode.setUsed(false);
        verificationCodeRepository.save(verificationCode);

        return notificationService.sendOtp(user.getPhoneNumber(), code);
    }

    





    @Transactional
    public boolean verifyOtp(Integer userId, String code) {
        Optional<VerificationCode> latest =
                verificationCodeRepository.findTopByUserIdAndUsedFalseOrderByExpiresAtDesc(userId);
        if (latest.isEmpty()) {
            return false;
        }

        VerificationCode verificationCode = latest.get();
        if (verificationCode.getExpiresAt().isBefore(LocalDateTime.now())) {
            return false;
        }
        if (!verificationCode.getCode().equals(code)) {
            return false;
        }

        verificationCode.setUsed(true);
        verificationCodeRepository.save(verificationCode);
        return true;
    }

    






    @Transactional
    public Map<String, Object> register(String name, String phoneNumber, String email, Integer monthlyIncome) {
        if (!StringUtils.hasText(name) || !StringUtils.hasText(phoneNumber)) {
            throw new ApiException("name and phoneNumber are required to register");
        }
        User user = userRepository.findByPhoneNumber(phoneNumber.trim());
        if (user == null) {
            user = new User();
            user.setName(name.trim());
            user.setPhoneNumber(phoneNumber.trim());
            user.setEmail(email);
            user.setMonthlyIncome(monthlyIncome);
            user.setPhoneVerified(false);
            user.setIntegrityStatus("NEW");
            user = userRepository.save(user);
        } else {
            
            
            
            boolean changed = false;
            if (StringUtils.hasText(name) && !name.trim().equals(user.getName())) {
                user.setName(name.trim());
                changed = true;
            }
            if (StringUtils.hasText(email) && !email.trim().equals(user.getEmail())) {
                user.setEmail(email.trim());
                changed = true;
            }
            if (changed) {
                user = userRepository.save(user);
            }
        }
        boolean otpSent = sendOtp(user.getId());

        
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("userId", user.getId());
        result.put("otpSent", otpSent);
        return result;
    }

    




    @Transactional
    public boolean verifyAndActivate(Integer userId, String code) {
        boolean valid = verifyOtp(userId, code);
        if (valid) {
            User user = userRepository.findUserById(userId);
            if (user != null) {
                user.setPhoneVerified(true);
                userRepository.save(user);
                
                try {
                    notificationService.sendAccountVerified(user);
                } catch (Exception e) {
                    
                }
            }
        }
        return valid;
    }

    
    private String generateCode() {
        return String.format("%06d", ThreadLocalRandom.current().nextInt(1_000_000));
    }
}
