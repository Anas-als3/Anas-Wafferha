package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.Out.BaselineIncomeOutDTO;
import com.wafferha.DTO.Out.BehaviorEventOutDTO;
import com.wafferha.DTO.Out.BehaviorSourceOutDTO;
import com.wafferha.Model.BaselineIncome;
import com.wafferha.Model.BehaviorEvent;
import com.wafferha.Model.BehaviorSource;
import com.wafferha.Model.User;
import com.wafferha.Repository.BaselineIncomeRepository;
import com.wafferha.Repository.BehaviorEventRepository;
import com.wafferha.Repository.BehaviorSourceRepository;
import com.wafferha.Repository.UserRepository;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;















@Service
@RequiredArgsConstructor
public class BehaviorService {

    
    private static final int WINDOW_DAYS = 90;
    private static final double WINDOW_MONTHS = WINDOW_DAYS / 30.0;

    
    
    private static final int MIN_RECURRENCES = 2;
    
    private static final BigDecimal SIMILARITY_TOLERANCE = new BigDecimal("0.15");
    
    private static final BigDecimal MIN_FLOOR = new BigDecimal("1000.00");

    private final BehaviorEventRepository behaviorEventRepository;
    private final BehaviorSourceRepository behaviorSourceRepository;
    private final BaselineIncomeRepository baselineIncomeRepository;
    private final UserRepository userRepository;

    

    



    @Transactional
    public BaselineIncome recompute(Integer userId) {

        User user = userRepository.findUserById(userId);
        if (user == null) {
            throw new ApiException("User not found");
        }

        LocalDateTime windowStart = LocalDateTime.now().minusDays(WINDOW_DAYS);

        List<BehaviorEvent> events = behaviorEventRepository.findByUserId(userId);

        detectSalary(userId, events, windowStart);

        return recomputeBaseline(userId, events, windowStart);
    }

    




    private void detectSalary(Integer userId, List<BehaviorEvent> events, LocalDateTime windowStart) {

        List<BehaviorSource> sources = behaviorSourceRepository.findByUserId(userId);

        
        Map<Integer, List<BigDecimal>> inAmountsBySource = new HashMap<>();
        for (BehaviorEvent e : events) {
            if ("IN".equals(e.getDirection())
                    && e.getValue() != null
                    && e.getTimestamp() != null
                    && !e.getTimestamp().isBefore(windowStart)) {
                inAmountsBySource
                        .computeIfAbsent(e.getSourceId(), k -> new ArrayList<>())
                        .add(e.getValue());
            }
        }

        for (BehaviorSource source : sources) {
            List<BigDecimal> inAmounts = inAmountsBySource.get(source.getId());
            boolean detected = looksLikeSalary(inAmounts);
            if (source.isSalaryDetected() != detected) {
                source.setSalaryDetected(detected);
                behaviorSourceRepository.save(source);
            }
        }
    }

    



    private boolean looksLikeSalary(List<BigDecimal> inAmounts) {
        if (inAmounts == null || inAmounts.size() < MIN_RECURRENCES) {
            return false;
        }
        for (BigDecimal anchor : inAmounts) {
            if (anchor.signum() <= 0) {
                continue;
            }
            BigDecimal band = anchor.multiply(SIMILARITY_TOLERANCE);
            BigDecimal low = anchor.subtract(band);
            BigDecimal high = anchor.add(band);
            int similar = 0;
            for (BigDecimal amount : inAmounts) {
                if (amount.compareTo(low) >= 0 && amount.compareTo(high) <= 0) {
                    similar++;
                }
            }
            if (similar >= MIN_RECURRENCES) {
                return true;
            }
        }
        return false;
    }

    



    private BaselineIncome recomputeBaseline(Integer userId, List<BehaviorEvent> events, LocalDateTime windowStart) {

        List<BigDecimal> ins = new ArrayList<>();
        BigDecimal totalIn = BigDecimal.ZERO;
        for (BehaviorEvent e : events) {
            if ("IN".equals(e.getDirection())
                    && e.getValue() != null
                    && e.getTimestamp() != null
                    && !e.getTimestamp().isBefore(windowStart)) {
                ins.add(e.getValue());
                totalIn = totalIn.add(e.getValue());
            }
        }

        
        
        
        BigDecimal salary = monthlySalary(ins);
        BigDecimal monthlyIncome = salary != null ? salary
                : totalIn.divide(BigDecimal.valueOf(WINDOW_MONTHS), 2, RoundingMode.HALF_UP);

        
        BigDecimal floored = monthlyIncome.max(MIN_FLOOR);

        BaselineIncome baseline = baselineIncomeRepository.findByUserId(userId);
        if (baseline == null) {
            baseline = new BaselineIncome();
            baseline.setUserId(userId);
        }
        baseline.setWindowDays(WINDOW_DAYS);
        baseline.setBaselineIncomeValue(floored);
        baseline.setFloorValue(MIN_FLOOR);
        baseline.setLastComputed(LocalDateTime.now());

        return baselineIncomeRepository.save(baseline);
    }

    





    private BigDecimal monthlySalary(List<BigDecimal> ins) {
        BigDecimal bestAvg = null;
        for (BigDecimal anchor : ins) {
            if (anchor.signum() <= 0) {
                continue;
            }
            BigDecimal band = anchor.multiply(SIMILARITY_TOLERANCE);
            BigDecimal low = anchor.subtract(band);
            BigDecimal high = anchor.add(band);
            BigDecimal sum = BigDecimal.ZERO;
            int count = 0;
            for (BigDecimal a : ins) {
                if (a.compareTo(low) >= 0 && a.compareTo(high) <= 0) {
                    sum = sum.add(a);
                    count++;
                }
            }
            if (count >= MIN_RECURRENCES) {
                BigDecimal avg = sum.divide(BigDecimal.valueOf(count), 2, RoundingMode.HALF_UP);
                if (bestAvg == null || avg.compareTo(bestAvg) > 0) {
                    bestAvg = avg;
                }
            }
        }
        return bestAvg;
    }

    

    




    @Transactional
    public int ingest(Integer userId, List<BehaviorEvent> events) {
        if (events == null || events.isEmpty()) {
            return 0;
        }
        for (BehaviorEvent event : events) {
            event.setId(null);
            event.setUserId(userId);
        }
        behaviorEventRepository.saveAll(events);
        recompute(userId);
        return events.size();
    }

    



    public List<BehaviorEventOutDTO> filterForUser(Integer userId, String direction, String category,
                                                   LocalDateTime from, LocalDateTime to) {
        return behaviorEventRepository.findByUserId(userId).stream()
                .filter(e -> direction == null || direction.equalsIgnoreCase(e.getDirection()))
                .filter(e -> category == null || category.equalsIgnoreCase(e.getCategory()))
                .filter(e -> from == null || (e.getTimestamp() != null && !e.getTimestamp().isBefore(from)))
                .filter(e -> to == null || (e.getTimestamp() != null && !e.getTimestamp().isAfter(to)))
                .map(this::eventToDto)
                .collect(Collectors.toList());
    }

    public List<BehaviorEventOutDTO> getAllEvents() {
        return behaviorEventRepository.findAll().stream()
                .map(this::eventToDto)
                .collect(Collectors.toList());
    }

    public BehaviorEventOutDTO getEventById(Integer id) {
        return eventToDto(getEventEntity(id));
    }

    public List<BehaviorEventOutDTO> getEventsByUser(Integer userId) {
        return behaviorEventRepository.findByUserId(userId).stream()
                .map(this::eventToDto)
                .collect(Collectors.toList());
    }

    



    public List<Map<String, Object>> spendingSummary(Integer userId) {
        Map<String, double[]> byCategory = new LinkedHashMap<>(); 
        for (BehaviorEvent e : behaviorEventRepository.findByUserId(userId)) {
            if (!"OUT".equalsIgnoreCase(e.getDirection())) {
                continue;
            }
            String category = (e.getCategory() != null && !e.getCategory().isBlank())
                    ? e.getCategory() : "Other";
            double[] agg = byCategory.computeIfAbsent(category, k -> new double[2]);
            agg[0] += 1;
            agg[1] += e.getValue() == null ? 0 : e.getValue().doubleValue();
        }
        return byCategory.entrySet().stream()
                .sorted((a, b) -> Double.compare(b.getValue()[1], a.getValue()[1]))
                .map(en -> {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("category", en.getKey());
                    row.put("transactions", (int) en.getValue()[0]);
                    row.put("totalSpent", Math.round(en.getValue()[1] * 100.0) / 100.0);
                    return row;
                })
                .collect(Collectors.toList());
    }

    private BehaviorEvent getEventEntity(Integer id) {
        return behaviorEventRepository.findById(id)
                .orElseThrow(() -> new ApiException("Behavior event was not found"));
    }

    private BehaviorEventOutDTO eventToDto(BehaviorEvent entity) {
        return new BehaviorEventOutDTO(
                entity.getId(),
                entity.getSourceId(),
                entity.getUserId(),
                entity.getValue(),
                entity.getCategory(),
                entity.getDirection(),
                entity.getTimestamp());
    }

    

    public List<BehaviorSourceOutDTO> getAllSources() {
        return behaviorSourceRepository.findAll().stream()
                .map(this::sourceToDto)
                .collect(Collectors.toList());
    }

    public BehaviorSourceOutDTO getSourceById(Integer id) {
        return sourceToDto(getSourceEntity(id));
    }

    public List<BehaviorSourceOutDTO> getSourcesByUser(Integer userId) {
        return behaviorSourceRepository.findByUserId(userId).stream()
                .map(this::sourceToDto)
                .collect(Collectors.toList());
    }

    
    @Transactional
    public BehaviorSourceOutDTO detectSalary(Integer sourceId) {
        BehaviorSource source = getSourceEntity(sourceId);
        source.setSalaryDetected(true);
        return sourceToDto(behaviorSourceRepository.save(source));
    }

    private BehaviorSource getSourceEntity(Integer id) {
        return behaviorSourceRepository.findById(id)
                .orElseThrow(() -> new ApiException("Behavior source was not found"));
    }

    private BehaviorSourceOutDTO sourceToDto(BehaviorSource entity) {
        return new BehaviorSourceOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getType(),
                entity.isPrimary(),
                entity.isSalaryDetected());
    }

    

    public List<BaselineIncomeOutDTO> getAllBaselines() {
        return baselineIncomeRepository.findAll().stream()
                .map(this::baselineToDto)
                .collect(Collectors.toList());
    }

    public BaselineIncomeOutDTO getBaselineById(Integer id) {
        return baselineToDto(findBaselineById(id));
    }

    
    public BaselineIncomeOutDTO getBaselineByUser(Integer userId) {
        BaselineIncome existing = baselineIncomeRepository.findByUserId(userId);
        if (existing == null) {
            throw new ApiException("Baseline income was not found for this user");
        }
        return baselineToDto(existing);
    }

    public BaselineIncome findBaselineById(Integer id) {
        return baselineIncomeRepository.findById(id)
                .orElseThrow(() -> new ApiException("Baseline income was not found"));
    }

    private BaselineIncomeOutDTO baselineToDto(BaselineIncome entity) {
        return new BaselineIncomeOutDTO(
                entity.getId(),
                entity.getUserId(),
                entity.getWindowDays(),
                entity.getBaselineIncomeValue(),
                entity.getFloorValue(),
                entity.getLastComputed());
    }
}
