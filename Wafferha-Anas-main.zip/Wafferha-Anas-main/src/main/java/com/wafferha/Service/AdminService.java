package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.Model.Admin;
import com.wafferha.Repository.AdminRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;






@Service
@RequiredArgsConstructor
public class AdminService {

    private final AdminRepository adminRepository;

    public void requireAdmin(Integer adminId) {
        if (adminId == null || !adminRepository.existsById(adminId)) {
            throw new ApiException("Only an admin can perform this action (admin " + adminId + " not found)");
        }
    }

    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }
}
