package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.Out.PointsLedgerOutDTO;
import com.wafferha.DTO.Out.WalletOutDTO;
import com.wafferha.Model.PointsLedger;
import com.wafferha.Model.SeasonalWallet;
import com.wafferha.Model.Wallet;
import com.wafferha.Repository.PointsLedgerRepository;
import com.wafferha.Repository.SeasonalWalletRepository;
import com.wafferha.Repository.WalletRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;










@Service
@RequiredArgsConstructor
public class WalletService {

    private final WalletRepository walletRepository;
    private final PointsLedgerRepository pointsLedgerRepository;
    private final SeasonalWalletRepository seasonalWalletRepository;

    

    public List<WalletOutDTO> getAll() {
        return walletRepository.findAll().stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public WalletOutDTO getById(Integer id) {
        return fromEntity(findById(id));
    }

    public List<WalletOutDTO> getByUser(Integer userId) {
        return walletRepository.findByUserId(userId).stream().map(this::fromEntity).collect(Collectors.toList());
    }

    
    public Map<String, Object> pointsSummary(Integer userId) {
        int normal = walletRepository.findByUserId(userId).stream()
                .filter(w -> "ACTIVE".equalsIgnoreCase(w.getStatus()))
                .mapToInt(w -> w.getPointsBalance()).sum();
        int seasonal = seasonalWalletRepository.findByUserId(userId).stream()
                .filter(w -> "ACTIVE".equalsIgnoreCase(w.getStatus()))
                .mapToInt(w -> w.getSeasonalPointsBalance()).sum();
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("userId", userId);
        out.put("normalPoints", normal);
        out.put("seasonalPoints", seasonal);
        return out;
    }

    public Wallet findById(Integer id) {
        return walletRepository.findById(id)
                .orElseThrow(() -> new ApiException("Wallet was not found"));
    }

    

    



    @Transactional
    public Wallet awardNormalPoints(Integer userId, int amount, String reason, Integer refId) {
        int year = LocalDate.now().getYear();

        Wallet wallet = walletRepository.findByUserIdAndYear(userId, year)
                .orElseGet(() -> {
                    Wallet fresh = new Wallet();
                    fresh.setUserId(userId);
                    fresh.setYear(year);
                    fresh.setStatus("ACTIVE");
                    return fresh;
                });

        wallet.setPointsBalance(wallet.getPointsBalance() + amount);
        wallet.setEarnedThisYear(wallet.getEarnedThisYear() + amount);
        wallet = walletRepository.save(wallet);

        PointsLedger ledger = new PointsLedger();
        ledger.setUserId(userId);
        ledger.setWalletId(wallet.getId());
        ledger.setYear(year);
        ledger.setAmount(amount);
        ledger.setReason(reason);
        ledger.setRefId(refId);
        pointsLedgerRepository.save(ledger);

        return wallet;
    }

    






    @Transactional
    public Wallet spendNormalPoints(Integer userId, int cost, String reason, Integer refId) {
        int year = LocalDate.now().getYear();

        Wallet wallet = walletRepository.findByUserIdAndYear(userId, year)
                .orElseThrow(() -> new ApiException("Not enough points"));

        if (!"ACTIVE".equalsIgnoreCase(wallet.getStatus())) {
            throw new ApiException("Not enough points");
        }
        if (wallet.getPointsBalance() < cost) {
            throw new ApiException("Not enough points");
        }

        wallet.setPointsBalance(wallet.getPointsBalance() - cost);
        wallet.setSpentThisYear(wallet.getSpentThisYear() + cost);
        wallet = walletRepository.save(wallet);

        PointsLedger ledger = new PointsLedger();
        ledger.setUserId(userId);
        ledger.setWalletId(wallet.getId());
        ledger.setYear(year);
        ledger.setAmount(-cost);
        ledger.setReason(reason);
        ledger.setRefId(refId);
        pointsLedgerRepository.save(ledger);

        return wallet;
    }

    

    public List<PointsLedgerOutDTO> getAllLedger() {
        return pointsLedgerRepository.findAll().stream().map(this::ledgerFromEntity).collect(Collectors.toList());
    }

    public PointsLedgerOutDTO getLedgerById(Integer id) {
        return ledgerFromEntity(findLedgerById(id));
    }

    public List<PointsLedgerOutDTO> getLedgerByUser(Integer userId) {
        return pointsLedgerRepository.findByUserId(userId).stream().map(this::ledgerFromEntity).collect(Collectors.toList());
    }

    



    public List<PointsLedgerOutDTO> filterByUser(Integer userId, String reason, LocalDateTime from, LocalDateTime to) {
        return pointsLedgerRepository.findByUserId(userId).stream()
                .filter(p -> reason == null || reason.equalsIgnoreCase(p.getReason()))
                .filter(p -> from == null || (p.getTimestamp() != null && !p.getTimestamp().isBefore(from)))
                .filter(p -> to == null || (p.getTimestamp() != null && !p.getTimestamp().isAfter(to)))
                .map(this::ledgerFromEntity)
                .collect(Collectors.toList());
    }

    public PointsLedger findLedgerById(Integer id) {
        return pointsLedgerRepository.findById(id)
                .orElseThrow(() -> new ApiException("Points ledger entry was not found"));
    }

    

    private WalletOutDTO fromEntity(Wallet wallet) {
        WalletOutDTO dto = new WalletOutDTO();
        dto.setId(wallet.getId());
        dto.setUserId(wallet.getUserId());
        dto.setYear(wallet.getYear());
        dto.setPointsBalance(wallet.getPointsBalance());
        dto.setEarnedThisYear(wallet.getEarnedThisYear());
        dto.setSpentThisYear(wallet.getSpentThisYear());
        dto.setExpiredPoints(wallet.getExpiredPoints());
        dto.setExpiresAt(wallet.getExpiresAt());
        dto.setStatus(wallet.getStatus());
        dto.setCreatedAt(wallet.getCreatedAt());
        dto.setUpdatedAt(wallet.getUpdatedAt());
        return dto;
    }

    private PointsLedgerOutDTO ledgerFromEntity(PointsLedger pointsLedger) {
        PointsLedgerOutDTO dto = new PointsLedgerOutDTO();
        dto.setId(pointsLedger.getId());
        dto.setUserId(pointsLedger.getUserId());
        dto.setWalletId(pointsLedger.getWalletId());
        dto.setYear(pointsLedger.getYear());
        dto.setAmount(pointsLedger.getAmount());
        dto.setReason(pointsLedger.getReason());
        dto.setRefId(pointsLedger.getRefId());
        dto.setTimestamp(pointsLedger.getTimestamp());
        return dto;
    }
}
