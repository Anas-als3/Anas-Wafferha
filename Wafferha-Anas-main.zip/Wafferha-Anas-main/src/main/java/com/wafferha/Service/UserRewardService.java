package com.wafferha.Service;

import com.wafferha.Api.ApiException;
import com.wafferha.DTO.In.UserRewardInDTO;
import com.wafferha.DTO.Out.UserRewardOutDTO;
import com.wafferha.Model.Item;
import com.wafferha.Model.Season;
import com.wafferha.Model.User;
import com.wafferha.Model.UserReward;
import com.wafferha.Repository.ItemRepository;
import com.wafferha.Repository.SeasonRepository;
import com.wafferha.Repository.UserRepository;
import com.wafferha.Repository.UserRewardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserRewardService {

    private final UserRewardRepository userRewardRepository;
    private final UserRepository userRepository;
    private final ItemRepository itemRepository;
    private final SeasonRepository seasonRepository;
    private final NotificationService notificationService;

    public List<UserRewardOutDTO> getAllUserRewards() {
        return userRewardRepository.findAll()
                .stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public List<UserRewardOutDTO> getUserRewardsByUser(Integer userId) {
        return userRewardRepository.findByUser_Id(userId)
                .stream().map(this::fromEntity).collect(Collectors.toList());
    }

    
    @Transactional
    public UserRewardOutDTO equip(Integer rewardId, boolean equipped) {
        UserReward reward = userRewardRepository.findUserRewardById(rewardId);
        if (reward == null) {
            throw new ApiException("UserReward not found");
        }
        reward.setEquipped(equipped);
        UserReward saved = userRewardRepository.save(reward);
        if (equipped) {
            deliverCouponIfAny(saved);
        }
        return fromEntity(saved);
    }

    



    @Transactional
    public UserRewardOutDTO equipByUserAndItem(Integer userId, Integer itemId, boolean equipped) {
        UserReward reward = userRewardRepository.findByUser_Id(userId).stream()
                .filter(r -> r.getItem() != null && itemId.equals(r.getItem().getId()))
                .findFirst()
                .orElseThrow(() -> new ApiException("User " + userId + " does not own item " + itemId));
        reward.setEquipped(equipped);
        UserReward saved = userRewardRepository.save(reward);
        if (equipped) {
            deliverCouponIfAny(saved);
        }
        return fromEntity(saved);
    }

    
    private void deliverCouponIfAny(UserReward reward) {
        Item item = reward.getItem();
        if (item == null || !"COUPON".equalsIgnoreCase(item.getType())) {
            return;
        }
        
        if (Boolean.TRUE.equals(reward.getRedeemed())) {
            throw new ApiException("This coupon has already been used - coupons are one-time only");
        }
        reward.setRedeemed(true);
        userRewardRepository.save(reward);

        User user = reward.getUser();
        if (user == null || !StringUtils.hasText(user.getPhoneNumber())) {
            return;
        }
        String desc = StringUtils.hasText(item.getCouponDescription())
                ? item.getCouponDescription() : item.getName();
        String code = StringUtils.hasText(item.getCouponCode()) ? item.getCouponCode() : "WAFFERHA";
        String message = "Congratulations from Wafferha! Here is your reward coupon: "
                + desc + "\nCoupon code: " + code;
        try {
            notificationService.sendMessage(user.getPhoneNumber(), message);
        } catch (Exception e) {
            
        }
    }

    
    public List<UserRewardOutDTO> filterByUser(Integer userId, Boolean equipped) {
        return userRewardRepository.findByUser_Id(userId).stream()
                .filter(r -> equipped == null || equipped.equals(r.getEquipped()))
                .map(this::fromEntity)
                .collect(Collectors.toList());
    }

    public List<UserRewardOutDTO> getUserRewardsBySeason(Integer seasonId) {
        return userRewardRepository.findBySeason_Id(seasonId)
                .stream().map(this::fromEntity).collect(Collectors.toList());
    }

    public UserRewardOutDTO addUserReward(Integer userId, Integer itemId, Integer seasonId, UserRewardInDTO dto) {

        User user = userRepository.findUserById(userId);
        if (user == null) {
            throw new ApiException("User not found");
        }

        Item item = itemRepository.findItemById(itemId);
        if (item == null) {
            throw new ApiException("Item not found");
        }

        Season season = seasonRepository.findSeasonById(seasonId);
        if (season == null) {
            throw new ApiException("Season not found");
        }

        UserReward userReward = toEntity(dto);
        userReward.setUser(user);
        userReward.setItem(item);
        userReward.setSeason(season);

        return fromEntity(userRewardRepository.save(userReward));
    }

    public UserReward toEntity(UserRewardInDTO dto) {
        UserReward userReward = new UserReward();
        userReward.setSourceType(dto.getSourceType());
        userReward.setPurchaseCurrency(dto.getPurchaseCurrency());
        userReward.setAcquiredAt(dto.getAcquiredAt());
        userReward.setEquipped(dto.getEquipped());
        return userReward;
    }

    public UserRewardOutDTO fromEntity(UserReward userReward) {
        UserRewardOutDTO dto = new UserRewardOutDTO();
        dto.setId(userReward.getId());
        dto.setSourceType(userReward.getSourceType());
        dto.setPurchaseCurrency(userReward.getPurchaseCurrency());
        dto.setAcquiredAt(userReward.getAcquiredAt());
        dto.setUsed(userReward.getEquipped());
        if (userReward.getUser() != null) {
            dto.setUserId(userReward.getUser().getId());
        }
        if (userReward.getItem() != null) {
            dto.setItemId(userReward.getItem().getId());
            dto.setItemName(userReward.getItem().getName());
        }
        if (userReward.getSeason() != null) {
            dto.setSeasonId(userReward.getSeason().getId());
            dto.setSeasonName(userReward.getSeason().getName());
        }
        return dto;
    }
}
