package com.wafferha.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafferha.Api.ApiException;
import com.wafferha.Model.Challenge;
import com.wafferha.Model.Item;
import com.wafferha.Model.User;
import com.wafferha.Model.UserChallenge;
import com.wafferha.Repository.ChallengeRepository;
import com.wafferha.Repository.ItemRepository;
import com.wafferha.Repository.UserChallengeRepository;
import com.wafferha.Repository.UserRepository;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;















@Service
@RequiredArgsConstructor
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    private static final String CURRENCY_NORMAL = "NORMAL";
    private static final String CURRENCY_SEASONAL = "SEASONAL";
    private static final String SUBJECT = "Keep saving!";
    private static final String VERIFIED_SUBJECT = "Your Wafferha account is verified";
    
    private static final int MAX_ITEM_SUGGESTIONS = 2;

    
    private static final Set<String> VALID_CADENCES = Set.of("DAILY", "WEEKLY", "MONTHLY", "YEARLY");
    private static final String STATUS_COMPLETED = "COMPLETED";

    private final UserRepository userRepository;
    private final ChallengeRepository challengeRepository;
    private final ItemRepository itemRepository;
    private final UserChallengeRepository userChallengeRepository;
    
    
    @Lazy
    private final AiTaskService aiTaskService;

    @Value("${app.notifications.enabled:true}")
    private boolean notificationsEnabled;

    
    @Value("${mailtrap.enabled:false}")
    private Boolean mailtrapEnabled;

    @Value("${mailtrap.api-token:}")
    private String mailtrapToken;

    @Value("${mailtrap.api-url:https://send.api.mailtrap.io/api/send}")
    private String mailtrapUrl;

    @Value("${mailtrap.from-email:no-reply@wafferha.app}")
    private String mailtrapFromEmail;

    @Value("${mailtrap.from-name:Wafferha}")
    private String mailtrapFromName;

    
    
    
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private JavaMailSender mailSender;

    @Value("${app.mail.from:no-reply@wafferha.app}")
    private String fromAddress;

    
    @Value("${twilio.enabled:false}")
    private Boolean twilioEnabled;

    @Value("${twilio.account-sid:}")
    private String twilioAccountSid;

    @Value("${twilio.auth-token:}")
    private String twilioAuthToken;

    
    @Value("${twilio.whatsapp-from:}")
    private String twilioFrom;

    @Value("${twilio.api-base-url:https://api.twilio.com}")
    private String twilioBaseUrl;

    
    @Value("${ultramsg.enabled:true}")
    private Boolean ultraEnabled;

    @Value("${ultramsg.instance-id:}")
    private String ultraInstanceId;

    @Value("${ultramsg.token:}")
    private String ultraToken;

    @Value("${ultramsg.api-base-url:https://api.ultramsg.com}")
    private String ultraBaseUrl;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    
    
    

    





    public void encourage(Integer userId) {
        User user = userRepository.findUserById(userId);
        if (user == null) {
            throw new ApiException("User not found");
        }
        deliver(user, buildMessage(user));
    }

    






    public void sendAccountVerified(Integer userId) {
        User user = userRepository.findUserById(userId);
        if (user == null) {
            throw new ApiException("User not found");
        }
        sendAccountVerified(user);
    }

    




    public void sendAccountVerified(User user) {
        if (user == null) {
            return;
        }
        
        if (StringUtils.hasText(user.getEmail())) {
            String body = "Hi " + displayName(user) + ",\n\n"
                    + "Great news - your phone number has been verified and your Wafferha account is now active.\n\n"
                    + "You're all set: start saving, earn points, set a savings goal, and climb the fairness "
                    + "leaderboard (ranked on the percentage of your own income you save, not absolute wealth).\n\n"
                    + "Every riyal you save gets you closer. Welcome aboard!\n"
                    + "- The Wafferha team";
            try {
                send(user.getEmail(), VERIFIED_SUBJECT, body);
            } catch (Exception e) {
                log.warn("Account-verified e-mail to user {} failed: {}", user.getId(), e.getMessage());
            }
        }
        
        if (StringUtils.hasText(user.getPhoneNumber())) {
            String wa = "Welcome " + displayName(user) + "! Your phone is verified. Connect your bank (open "
                    + "banking) to verify your income - then you're eligible to compete in the Wafferha leagues!";
            try {
                sendMessage(user.getPhoneNumber(), wa);
            } catch (Exception e) {
                log.warn("Account-verified WhatsApp to user {} failed: {}", user.getId(), e.getMessage());
            }
        }
    }

    






    @Scheduled(cron = "0 0 9 * * MON")
    public void encourageAllUsers() {
        if (!notificationsEnabled) {
            log.info("Notifications are disabled (app.notifications.enabled=false); skipping weekly encouragement sweep");
            return;
        }
        List<User> users = userRepository.findAll();
        log.info("Running weekly encouragement sweep for {} user(s)", users.size());
        for (User user : users) {
            try {
                deliver(user, buildMessage(user));
            } catch (Exception e) {
                
                log.warn("Encouragement for user {} failed: {}", user.getId(), e.getMessage());
            }
        }
    }

    
    private String buildMessage(User user) {
        LocalDateTime now = LocalDateTime.now();
        List<Challenge> available = challengeRepository.findAll().stream()
                .filter(c -> isChallengeAvailable(c, now))
                .collect(Collectors.toList());

        int normalPoints = sumRewardPoints(available, CURRENCY_NORMAL);
        int seasonalPoints = sumRewardPoints(available, CURRENCY_SEASONAL);

        StringBuilder sb = new StringBuilder();
        sb.append("Hi ").append(displayName(user)).append(",\n\n");
        sb.append("Keep saving - there are still rewards waiting for you!\n\n");

        if (normalPoints > 0 || seasonalPoints > 0) {
            sb.append("Rewards you could still earn:\n");
            if (normalPoints > 0) {
                sb.append("- Yearly (normal) rewards: up to ").append(normalPoints)
                        .append(" points across ").append(countByCurrency(available, CURRENCY_NORMAL))
                        .append(" challenge(s).\n");
            }
            if (seasonalPoints > 0) {
                sb.append("- Seasonal rewards: up to ").append(seasonalPoints)
                        .append(" points across ").append(countByCurrency(available, CURRENCY_SEASONAL))
                        .append(" challenge(s).\n");
            }
        } else {
            sb.append("New challenges are coming soon - stay tuned and keep your streak alive!\n");
        }

        List<Item> buyable = itemRepository.findAll().stream()
                .filter(i -> isItemAvailable(i, now))
                .filter(i -> i.getCost() != null && i.getCost() > 0)
                .sorted(Comparator.comparingInt(Item::getCost))
                .limit(MAX_ITEM_SUGGESTIONS)
                .collect(Collectors.toList());

        if (!buyable.isEmpty()) {
            sb.append("\nThings you could buy with your points:\n");
            for (Item item : buyable) {
                sb.append("- ").append(item.getName())
                        .append(" (").append(item.getCost()).append(" ")
                        .append(currencyLabel(item.getCurrencyType())).append(" points)\n");
            }
        }

        sb.append("\nEvery riyal you save gets you closer. Keep it up!\n");
        sb.append("- The Wafferha team");
        return sb.toString();
    }

    



    private void deliver(User user, String body) {
        if (StringUtils.hasText(user.getEmail())) {
            try {
                send(user.getEmail(), SUBJECT, body);
            } catch (Exception e) {
                log.warn("Encouragement e-mail to user {} failed: {}", user.getId(), e.getMessage());
            }
        } else {
            log.debug("User {} has no e-mail; skipping encouragement e-mail", user.getId());
        }

        if (StringUtils.hasText(user.getPhoneNumber())) {
            try {
                sendMessage(user.getPhoneNumber(), body);
            } catch (Exception e) {
                log.warn("Encouragement WhatsApp to user {} failed: {}", user.getId(), e.getMessage());
            }
        } else {
            log.debug("User {} has no phone number; skipping encouragement WhatsApp", user.getId());
        }
    }

    private int sumRewardPoints(List<Challenge> challenges, String currencyType) {
        return challenges.stream()
                .filter(c -> currencyType.equals(c.getRewardCurrencyType()))
                .mapToInt(c -> c.getRewardPoints() == null ? 0 : c.getRewardPoints())
                .sum();
    }

    private long countByCurrency(List<Challenge> challenges, String currencyType) {
        return challenges.stream()
                .filter(c -> currencyType.equals(c.getRewardCurrencyType()))
                .count();
    }

    
    private boolean isChallengeAvailable(Challenge c, LocalDateTime now) {
        if (c.getStartAt() != null && now.isBefore(c.getStartAt())) {
            return false;
        }
        if (c.getEndAt() != null && now.isAfter(c.getEndAt())) {
            return false;
        }
        return true;
    }

    
    private boolean isItemAvailable(Item i, LocalDateTime now) {
        if (i.getAvailableFrom() != null && now.isBefore(i.getAvailableFrom())) {
            return false;
        }
        if (i.getAvailableUntil() != null && now.isAfter(i.getAvailableUntil())) {
            return false;
        }
        return true;
    }

    private String displayName(User user) {
        return StringUtils.hasText(user.getName()) ? user.getName() : "there";
    }

    private String currencyLabel(String currencyType) {
        return CURRENCY_SEASONAL.equals(currencyType) ? "seasonal" : "normal";
    }

    
    
    

    





    public Map<String, Object> notifyAllForCadence(String cadence) {
        String normalized = validateCadence(cadence);

        int usersNotified = 0;
        int whatsappSent = 0;
        int emailSent = 0;

        for (User user : userRepository.findAll()) {
            List<UserChallenge> due = dueTasks(user.getId(), normalized);
            if (due.isEmpty()) {
                continue;
            }
            int[] sent = notify(user, normalized, due);
            if (sent[0] + sent[1] > 0) {
                usersNotified++;
            }
            whatsappSent += sent[0];
            emailSent += sent[1];
        }

        return summary(normalized, usersNotified, whatsappSent, emailSent);
    }

    




    public Map<String, Object> notifyUserForCadence(Integer userId, String cadence) {
        String normalized = validateCadence(cadence);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ApiException("User was not found"));

        List<UserChallenge> due = allPendingTasks(userId);
        int whatsappSent = 0;
        int emailSent = 0;
        int usersNotified = 0;
        if (!due.isEmpty()) {
            int[] sent = notify(user, normalized, due);
            whatsappSent = sent[0];
            emailSent = sent[1];
            if (whatsappSent + emailSent > 0) {
                usersNotified = 1;
            }
        }

        return summary(normalized, usersNotified, whatsappSent, emailSent);
    }

    
    private List<UserChallenge> dueTasks(Integer userId, String cadence) {
        List<UserChallenge> due = new ArrayList<>();
        for (UserChallenge uc : userChallengeRepository.findByUser_Id(userId)) {
            Challenge ch = uc.getChallenge();
            if (ch == null || !cadence.equalsIgnoreCase(ch.getCadence())) {
                continue;
            }
            if (STATUS_COMPLETED.equalsIgnoreCase(uc.getStatus())) {
                continue;
            }
            due.add(uc);
        }
        return due;
    }

    
    private List<UserChallenge> allPendingTasks(Integer userId) {
        List<UserChallenge> pending = new ArrayList<>();
        for (UserChallenge uc : userChallengeRepository.findByUser_Id(userId)) {
            if (STATUS_COMPLETED.equalsIgnoreCase(uc.getStatus())) {
                continue;
            }
            pending.add(uc);
        }
        return pending;
    }

    




    private int[] notify(User user, String cadence, List<UserChallenge> due) {
        String phone = user.getPhoneNumber();
        String email = user.getEmail();
        if (!StringUtils.hasText(phone) && !StringUtils.hasText(email)) {
            return new int[] {0, 0};
        }

        String message = buildTaskMessage(cadence, due);

        int whatsapp = 0;
        if (StringUtils.hasText(phone) && sendMessage(phone, message)) {
            whatsapp = 1;
        }
        int mail = 0;
        if (StringUtils.hasText(email)
                && send(email, "Your Wafferha " + cadence.toLowerCase() + " tasks", message)) {
            mail = 1;
        }
        return new int[] {whatsapp, mail};
    }

    
    private String buildTaskMessage(String cadence, List<UserChallenge> due) {
        StringBuilder sb = new StringBuilder("Wafferha - your ").append(cadence).append(" tasks:");
        for (UserChallenge uc : due) {
            Challenge ch = uc.getChallenge();
            if (ch == null) {
                continue;
            }
            String title = ch.getTitle() == null ? "(task)" : ch.getTitle();
            int points = ch.getRewardPoints() == null ? 0 : ch.getRewardPoints();
            sb.append("\n- ").append(title).append(" (+").append(points).append(" pts)");
        }
        return sb.toString();
    }

    private Map<String, Object> summary(String cadence, int usersNotified, int whatsappSent, int emailSent) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("cadence", cadence);
        out.put("usersNotified", usersNotified);
        out.put("whatsappSent", whatsappSent);
        out.put("emailSent", emailSent);
        return out;
    }

    
    private String validateCadence(String cadence) {
        String normalized = cadence == null ? "" : cadence.trim().toUpperCase();
        if (!VALID_CADENCES.contains(normalized)) {
            throw new ApiException("Cadence must be DAILY, WEEKLY, MONTHLY or YEARLY");
        }
        return normalized;
    }

    
    
    

    





    public int generateForPaydayDay(int dayOfMonth) {
        List<User> users = userRepository.findByPaydayDay(dayOfMonth);
        int created = 0;
        for (User user : users) {
            try {
                aiTaskService.generatePaydayTask(user.getId());
                created++;
            } catch (Exception e) {
                log.warn("Payday task generation failed for user {}: {}", user.getId(), e.getMessage());
            }
        }
        log.info("Payday tasks: generated {} of {} for payday day {}", created, users.size(), dayOfMonth);
        return created;
    }

    
    
    

    
    public boolean emailConfigured() {
        return mailtrapConfigured() || smtpConfigured();
    }

    private boolean mailtrapConfigured() {
        return Boolean.TRUE.equals(mailtrapEnabled)
                && StringUtils.hasText(mailtrapToken)
                && StringUtils.hasText(mailtrapFromEmail);
    }

    private boolean smtpConfigured() {
        return mailSender != null && StringUtils.hasText(fromAddress);
    }

    





    public boolean send(String to, String subject, String body) {
        if (!StringUtils.hasText(to)) {
            return false;
        }
        if (mailtrapConfigured()) {
            return sendViaMailtrap(to, subject, body);
        }
        if (smtpConfigured()) {
            return sendViaSmtp(to, subject, body);
        }
        log.warn("Email is not configured (no Mailtrap or SMTP); skipping message to {}", to);
        return false;
    }

    




    private boolean sendViaMailtrap(String to, String subject, String body) {
        try {
            Map<String, Object> from = new LinkedHashMap<>();
            from.put("email", mailtrapFromEmail.trim());
            from.put("name", StringUtils.hasText(mailtrapFromName) ? mailtrapFromName.trim() : "Wafferha");

            Map<String, Object> recipient = new LinkedHashMap<>();
            recipient.put("email", to.trim());

            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("from", from);
            payload.put("to", List.of(recipient));
            payload.put("subject", subject);
            payload.put("text", body);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(mailtrapToken.trim());

            ResponseEntity<String> response = restTemplate.postForEntity(
                    mailtrapUrl.trim(), new HttpEntity<>(payload, headers), String.class);

            boolean ok = response.getStatusCode().is2xxSuccessful() && mailtrapSuccess(response.getBody());
            if (ok) {
                log.info("Email (Mailtrap) sent to {}", to);
            } else {
                log.warn("Email (Mailtrap) to {} returned {}", to, response.getStatusCode());
            }
            return ok;
        } catch (Exception e) {
            log.warn("Email (Mailtrap) send to {} failed: {}", to, e.getMessage());
            return false;
        }
    }

    
    private boolean mailtrapSuccess(String response) {
        if (!StringUtils.hasText(response)) {
            return true; 
        }
        try {
            JsonNode node = objectMapper.readTree(response);
            JsonNode success = node.path("success");
            if (success.isBoolean()) {
                return success.asBoolean();
            }
            return node.path("message_ids").isArray() && node.path("message_ids").size() > 0;
        } catch (Exception e) {
            return true; 
        }
    }

    private boolean sendViaSmtp(String to, String subject, String body) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromAddress);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(body);
            mailSender.send(message);
            log.info("Email (SMTP) sent to {}", to);
            return true;
        } catch (Exception e) {
            log.warn("Email (SMTP) send to {} failed: {}", to, e.getMessage());
            return false;
        }
    }

    
    
    

    
    public boolean whatsAppConfigured() {
        return twilioConfigured() || ultraMsgConfigured();
    }

    private boolean twilioConfigured() {
        return Boolean.TRUE.equals(twilioEnabled)
                && StringUtils.hasText(twilioAccountSid)
                && StringUtils.hasText(twilioAuthToken)
                && StringUtils.hasText(twilioFrom);
    }

    private boolean ultraMsgConfigured() {
        return Boolean.TRUE.equals(ultraEnabled)
                && StringUtils.hasText(ultraInstanceId)
                && StringUtils.hasText(ultraToken);
    }

    





    public boolean sendMessage(String phone, String text) {
        if (twilioConfigured()) {
            return sendViaTwilio(phone, text);
        }
        if (ultraMsgConfigured()) {
            return sendViaUltraMsg(phone, text);
        }
        log.warn("WhatsApp not configured (no Twilio or UltraMsg credentials); skipping message to {}", phone);
        return false;
    }

    
    public boolean sendOtp(String phone, String code) {
        return sendMessage(phone, "Your Wafferha verification code is: " + code);
    }

    








    public boolean sendListPicker(String phone, String bodyText, String buttonText,
                                  List<Map<String, String>> items, String textFallback) {
        if (!twilioConfigured()) {
            return false;
        }
        try {
            List<Map<String, Object>> rows = new ArrayList<>();
            for (Map<String, String> it : items) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("id", it.get("id"));
                row.put("item", truncate(it.get("title"), 24));
                row.put("description", truncate(it.getOrDefault("description", ""), 72));
                rows.add(row);
            }
            Map<String, Object> listPicker = new LinkedHashMap<>();
            listPicker.put("body", truncate(bodyText, 1024));
            listPicker.put("button", truncate(buttonText, 20));
            listPicker.put("items", rows);

            Map<String, Object> textType = new LinkedHashMap<>();
            textType.put("body", textFallback);

            Map<String, Object> types = new LinkedHashMap<>();
            types.put("twilio/list-picker", listPicker);
            types.put("twilio/text", textType);

            Map<String, Object> content = new LinkedHashMap<>();
            content.put("friendly_name", "wafferha_list");
            content.put("language", "en");
            content.put("types", types);

            HttpHeaders jsonHeaders = new HttpHeaders();
            jsonHeaders.setContentType(MediaType.APPLICATION_JSON);
            jsonHeaders.setBasicAuth(twilioAccountSid.trim(), twilioAuthToken.trim());

            JsonNode created = restTemplate.postForObject(
                    "https://content.twilio.com/v1/Content",
                    new HttpEntity<>(content, jsonHeaders), JsonNode.class);
            String contentSid = created == null ? null : created.path("sid").asText(null);
            if (!StringUtils.hasText(contentSid)) {
                return false;
            }

            String url = twilioBaseUrl.trim() + "/2010-04-01/Accounts/" + twilioAccountSid.trim() + "/Messages.json";
            MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
            form.add("From", asWhatsApp(twilioFrom));
            form.add("To", asWhatsApp(phone));
            form.add("ContentSid", contentSid);

            HttpHeaders formHeaders = new HttpHeaders();
            formHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            formHeaders.setBasicAuth(twilioAccountSid.trim(), twilioAuthToken.trim());

            ResponseEntity<String> response =
                    restTemplate.postForEntity(url, new HttpEntity<>(form, formHeaders), String.class);
            boolean ok = response.getStatusCode().is2xxSuccessful() && hasTwilioSid(response.getBody());
            if (ok) {
                log.info("WhatsApp (Twilio) list-picker sent to {}", phone);
            }
            return ok;
        } catch (Exception e) {
            log.warn("WhatsApp (Twilio) list-picker to {} failed: {}", phone, e.getMessage());
            return false;
        }
    }

    private String truncate(String s, int max) {
        if (s == null) {
            return "";
        }
        return s.length() <= max ? s : s.substring(0, max);
    }

    





    private boolean sendViaTwilio(String phone, String text) {
        try {
            String url = twilioBaseUrl.trim() + "/2010-04-01/Accounts/" + twilioAccountSid.trim() + "/Messages.json";

            MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
            body.add("From", asWhatsApp(twilioFrom));
            body.add("To", asWhatsApp(phone));
            body.add("Body", text);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            headers.setBasicAuth(twilioAccountSid.trim(), twilioAuthToken.trim());

            ResponseEntity<String> response =
                    restTemplate.postForEntity(url, new HttpEntity<>(body, headers), String.class);

            boolean ok = response.getStatusCode().is2xxSuccessful() && hasTwilioSid(response.getBody());
            if (ok) {
                log.info("WhatsApp (Twilio) sent to {}", phone);
            } else {
                log.warn("WhatsApp (Twilio) send to {} returned {}", phone, response.getStatusCode());
            }
            return ok;
        } catch (Exception e) {
            log.warn("WhatsApp (Twilio) send to {} failed: {}", phone, e.getMessage());
            return false;
        }
    }

    
    private String asWhatsApp(String number) {
        if (number == null) {
            return null;
        }
        String n = number.trim();
        return n.startsWith("whatsapp:") ? n : "whatsapp:" + n;
    }

    
    private boolean hasTwilioSid(String response) {
        if (!StringUtils.hasText(response)) {
            return false;
        }
        try {
            JsonNode sid = objectMapper.readTree(response).path("sid");
            return sid.isTextual() && StringUtils.hasText(sid.asText());
        } catch (Exception e) {
            log.warn("WhatsApp (Twilio) returned an unparseable response: {}", e.getMessage());
            return false;
        }
    }

    private boolean sendViaUltraMsg(String phone, String text) {
        try {
            String url = ultraBaseUrl.trim() + "/" + ultraInstanceId.trim() + "/messages/chat";

            MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
            body.add("token", ultraToken.trim());
            body.add("to", phone);
            body.add("body", text);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            String response = restTemplate.postForObject(url, new HttpEntity<>(body, headers), String.class);
            return ultraMsgSent(response);
        } catch (Exception e) {
            log.warn("WhatsApp (UltraMsg) send to {} failed: {}", phone, e.getMessage());
            return false;
        }
    }

    



    private boolean ultraMsgSent(String response) {
        if (!StringUtils.hasText(response)) {
            return false;
        }
        try {
            JsonNode node = objectMapper.readTree(response);
            JsonNode sent = node.path("sent");
            if (sent.isBoolean() && sent.asBoolean()) {
                return true;
            }
            if (sent.isTextual() && "true".equalsIgnoreCase(sent.asText())) {
                return true;
            }
            JsonNode id = node.path("id");
            if (id.isNumber()) {
                return id.asLong() != 0L;
            }
            if (id.isTextual()) {
                return StringUtils.hasText(id.asText()) && !"0".equals(id.asText().trim());
            }
            return false;
        } catch (Exception e) {
            log.warn("WhatsApp (UltraMsg) returned an unparseable response: {}", e.getMessage());
            return false;
        }
    }
}
