package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;





@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SavingsGoalInDTO {

    @NotBlank(message = "name is required")
    private String name;

    @NotNull(message = "targetAmount is required")
    @Positive(message = "targetAmount must be positive")
    private Double targetAmount;

    @NotNull(message = "months is required")
    @Positive(message = "months must be positive")
    private Integer months;

    
    @Pattern(regexp = "^(DAILY|WEEKLY|MONTHLY)$", message = "Cadence must be DAILY, WEEKLY or MONTHLY")
    private String cadence;
}
