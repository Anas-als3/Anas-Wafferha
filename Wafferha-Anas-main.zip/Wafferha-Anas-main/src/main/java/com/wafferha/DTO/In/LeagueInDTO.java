package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LeagueInDTO {

    @NotEmpty(message = "Segment type cannot be empty")
    private String segmentType;

    @NotEmpty(message = "Name cannot be empty")
    private String name;
}
