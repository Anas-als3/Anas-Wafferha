package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserRewardInDTO {

    @NotEmpty(message = "Source type cannot be empty")
    private String sourceType;

    @NotEmpty(message = "Purchase currency cannot be empty")
    private String purchaseCurrency;

    private LocalDateTime acquiredAt;

    @NotNull(message = "Equipped cannot be null")
    private Boolean equipped;
}
