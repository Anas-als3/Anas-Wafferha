package com.wafferha.DTO.In;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;






@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EconomicContextInDTO {

    @PositiveOrZero(message = "inflationRatePct cannot be negative")
    private Double inflationRatePct;

    @PositiveOrZero(message = "policyRatePct cannot be negative")
    private Double policyRatePct;

    
    @Pattern(regexp = "^(NORMAL|HIGH)$", message = "Season level must be NORMAL or HIGH")
    private String seasonLevel;

    
    @Pattern(regexp = "^(SAVE_FAVORABLE|NEUTRAL)$", message = "Saving climate must be SAVE_FAVORABLE or NEUTRAL")
    private String savingClimate;

    private String source;
}
