package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LeaderBoardInDTO {

    @NotEmpty(message = "Period cannot be empty")
    @Pattern(regexp = "^(WEEKLY|MONTHLY|YEARLY|SEASONAL)$", message = "Period must be WEEKLY, MONTHLY, YEARLY or SEASONAL")
    private String period;

    @NotNull(message = "Snapshot date cannot be null")
    private LocalDateTime snapshotAt;
}
