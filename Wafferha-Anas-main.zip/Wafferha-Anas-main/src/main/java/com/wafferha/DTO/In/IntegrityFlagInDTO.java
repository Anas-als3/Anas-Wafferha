package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IntegrityFlagInDTO {

    @NotNull(message = "Salary verified cannot be null")
    private Boolean salaryVerified;

    private String anomalyFlags;

    @NotNull(message = "Competitive eligible cannot be null")
    private Boolean competitiveEligible;

    private LocalDate eligibleSince;
}
