package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LeaderBoardEntryInDTO {

    @NotNull(message = "Rank cannot be null")
    private Integer rank;

    @NotNull(message = "Score cannot be null")
    private Double score;
}
