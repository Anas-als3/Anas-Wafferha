package com.wafferha.DTO.In;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;






@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserInDTO {

    @NotEmpty(message = "Name cannot be empty")
    private String name;

    private String phoneNumber;

    @Email(message = "Email must be a valid email address")
    private String email;

    @Min(value = 1, message = "Payday day must be between 1 and 28")
    @Max(value = 28, message = "Payday day must be between 1 and 28")
    private Integer paydayDay;

    private Integer monthlyIncome;

    private boolean competitiveOptIn;

    @Pattern(regexp = "^(NEW|VERIFYING|VERIFIED|FLAGGED)$", message = "Integrity status must be NEW, VERIFYING, VERIFIED or FLAGGED")
    private String integrityStatus;

    
    private Integer leagueId;
}
