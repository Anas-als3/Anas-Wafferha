package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ChallengeInDTO {

    @NotEmpty(message = "Title cannot be empty")
    private String title;

    @NotEmpty(message = "Cadence cannot be empty")
    @Pattern(regexp = "^(DAILY|WEEKLY|MONTHLY|YEARLY)$",
            message = "Cadence must be DAILY, WEEKLY, MONTHLY, or YEARLY")
    private String cadence;

    @NotEmpty(message = "Type cannot be empty")
    private String type;

    @NotNull(message = "Target value cannot be null")
    @Positive(message = "Target value must be positive")
    private Double targetValue;

    @NotNull(message = "Reward points cannot be null")
    @PositiveOrZero(message = "Reward points must be positive or zero")
    private Integer rewardPoints;

    @NotEmpty(message = "Reward currency type cannot be empty")
    @Pattern(regexp = "^(NORMAL|SEASONAL)$",
            message = "Reward currency type must be NORMAL or SEASONAL")
    private String rewardCurrencyType;

    @NotNull(message = "Start date cannot be null")
    private LocalDateTime startAt;

    @NotNull(message = "End date cannot be null")
    private LocalDateTime endAt;
}
