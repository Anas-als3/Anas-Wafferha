package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PersonalizedGoalInDTO {

    @NotEmpty(message = "Period cannot be empty")
    @Pattern(
            regexp = "^(DAILY|WEEKLY|MONTHLY|YEARLY)$",
            message = "Period must be DAILY, WEEKLY, MONTHLY, or YEARLY"
    )
    private String period;

    @NotNull(message = "Suggested target cannot be null")
    @Positive(message = "Suggested target must be positive")
    private Double suggestedTarget;

    @NotEmpty(message = "Rationale cannot be empty")
    private String rationale;

    @NotEmpty(message = "Model version cannot be empty")
    private String modelVersion;
}
