package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;




@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OtpVerifyInDTO {

    @NotBlank(message = "code is required")
    private String code;
}
