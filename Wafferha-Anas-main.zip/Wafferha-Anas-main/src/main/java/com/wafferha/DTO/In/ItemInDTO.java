package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ItemInDTO {

    @NotEmpty
    private String name;

    @NotEmpty
    private String type;

    @Positive
    private Integer cost;

    @NotEmpty
    private String currencyType;

    @NotEmpty
    private String rarity;

    private LocalDateTime availableFrom;

    private LocalDateTime availableUntil;

    private Boolean isSeasonExclusive;

    private String unlockCondition;
}
