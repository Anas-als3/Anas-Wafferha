package com.wafferha.DTO.In;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SeasonInDTO {

    @NotEmpty(message = "Season type cannot be empty")
    private String seasonType;

    @NotEmpty(message = "Name cannot be empty")
    private String name;

    private String theme;

    @NotNull(message = "Year cannot be null")
    private Integer year;

    @NotNull(message = "Start date cannot be null")
    private LocalDateTime startAt;

    @NotNull(message = "End date cannot be null")
    private LocalDateTime endAt;

    @NotNull(message = "Points expire date cannot be null")
    private LocalDateTime pointsExpireAt;

    @NotEmpty(message = "Status cannot be empty")
    private String status;
}
