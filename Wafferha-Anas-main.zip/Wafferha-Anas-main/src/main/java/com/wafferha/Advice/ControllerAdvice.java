package com.wafferha.Advice;

import com.wafferha.Api.ApiException;
import com.wafferha.Api.ApiResponse;
import jakarta.validation.ConstraintViolationException;
import java.sql.SQLIntegrityConstraintViolationException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@RestControllerAdvice
public class ControllerAdvice {

    private ResponseEntity<ApiResponse> response(int status, String message) {
        return ResponseEntity.status(status)
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ApiResponse(message));
    }

    @ExceptionHandler(value = ApiException.class)
    public ResponseEntity<?> APIExceptionHandler(ApiException e) {
        return response(400, e.getMessage());
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<?> MethodArgumentNotValidExceptionHandler(MethodArgumentNotValidException e) {
        String message = e.getBindingResult().getFieldError() == null
                ? "Validation failed"
                : e.getBindingResult().getFieldError().getDefaultMessage();
        return response(400, message);
    }

    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity<?> ConstraintViolationExceptionHandler(ConstraintViolationException e) {
        return response(400, "Validation failed: " + e.getMessage());
    }

    @ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
    public ResponseEntity<?> MethodArgumentTypeMismatchExceptionHandler(MethodArgumentTypeMismatchException e) {
        return response(400, "Invalid value for " + e.getName());
    }

    @ExceptionHandler(value = TypeMismatchException.class)
    public ResponseEntity<?> TypeMismatchExceptionHandler(TypeMismatchException e) {
        return response(400, "Invalid value type");
    }

    @ExceptionHandler(value = NumberFormatException.class)
    public ResponseEntity<?> NumberFormatExceptionHandler(NumberFormatException e) {
        return response(400, "Invalid number format");
    }

    @ExceptionHandler(value = MissingServletRequestParameterException.class)
    public ResponseEntity<?> MissingServletRequestParameterExceptionHandler(MissingServletRequestParameterException e) {
        return response(400, "Missing required parameter: " + e.getParameterName());
    }

    @ExceptionHandler(value = MissingPathVariableException.class)
    public ResponseEntity<?> MissingPathVariableExceptionHandler(MissingPathVariableException e) {
        return response(400, "Missing path variable: " + e.getVariableName());
    }

    @ExceptionHandler(value = ServletRequestBindingException.class)
    public ResponseEntity<?> ServletRequestBindingExceptionHandler(ServletRequestBindingException e) {
        return response(400, "Invalid request binding");
    }

    @ExceptionHandler(value = HttpMessageNotReadableException.class)
    public ResponseEntity<?> HttpMessageNotReadableExceptionHandler(HttpMessageNotReadableException e) {
        return response(400, "Request body is missing or invalid");
    }

    @ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<?> HttpRequestMethodNotSupportedExceptionHandler(HttpRequestMethodNotSupportedException e) {
        String supportedMethods = e.getSupportedMethods() == null
                ? "the correct request type"
                : String.join(", ", e.getSupportedMethods());
        return response(400, "This endpoint does not support " + e.getMethod() + ". Use: " + supportedMethods);
    }

    @ExceptionHandler(value = HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<?> HttpMediaTypeNotSupportedExceptionHandler(HttpMediaTypeNotSupportedException e) {
        return response(400, "Content type is not supported. Use application/json");
    }

    @ExceptionHandler(value = HttpMediaTypeNotAcceptableException.class)
    public ResponseEntity<?> HttpMediaTypeNotAcceptableExceptionHandler(HttpMediaTypeNotAcceptableException e) {
        return response(400, "Requested response type is not acceptable");
    }

    @ExceptionHandler(value = NoHandlerFoundException.class)
    public ResponseEntity<?> NoHandlerFoundExceptionHandler(NoHandlerFoundException e) {
        return response(400, "Endpoint was not found. Check the URL path");
    }

    @ExceptionHandler(value = NoResourceFoundException.class)
    public ResponseEntity<?> NoResourceFoundExceptionHandler(NoResourceFoundException e) {
        return response(400, "Endpoint was not found. Check the URL path");
    }

    @ExceptionHandler(value = IllegalArgumentException.class)
    public ResponseEntity<?> IllegalArgumentExceptionHandler(IllegalArgumentException e) {
        return response(400, e.getMessage());
    }

    @ExceptionHandler(value = DataIntegrityViolationException.class)
    public ResponseEntity<?> DataIntegrityViolationExceptionHandler(DataIntegrityViolationException e) {
        return response(400, "Database constraint error. Check duplicate or invalid data");
    }

    @ExceptionHandler(value = SQLIntegrityConstraintViolationException.class)
    public ResponseEntity<?> SQLIntegrityConstraintViolationExceptionHandler(SQLIntegrityConstraintViolationException e) {
        return response(400, "Database constraint error. Check duplicate or invalid data");
    }

    @ExceptionHandler(value = ObjectOptimisticLockingFailureException.class)
    public ResponseEntity<?> ObjectOptimisticLockingFailureExceptionHandler(ObjectOptimisticLockingFailureException e) {
        return response(400, "Invalid update request");
    }

    @ExceptionHandler(value = DataAccessResourceFailureException.class)
    public ResponseEntity<?> DataAccessResourceFailureExceptionHandler(DataAccessResourceFailureException e) {
        return response(500, "Database connection error");
    }

    @ExceptionHandler(value = IllegalStateException.class)
    public ResponseEntity<?> IllegalStateExceptionHandler(IllegalStateException e) {
        return response(500, "Internal server error");
    }

    @ExceptionHandler(value = NullPointerException.class)
    public ResponseEntity<?> NullPointerExceptionHandler(NullPointerException e) {
        return response(500, "Internal server error");
    }

    @ExceptionHandler(value = IndexOutOfBoundsException.class)
    public ResponseEntity<?> IndexOutOfBoundsExceptionHandler(IndexOutOfBoundsException e) {
        return response(500, "Internal server error");
    }

    @ExceptionHandler(value = ArithmeticException.class)
    public ResponseEntity<?> ArithmeticExceptionHandler(ArithmeticException e) {
        return response(500, "Internal server error");
    }

    @ExceptionHandler(value = RuntimeException.class)
    public ResponseEntity<?> RuntimeExceptionHandler(RuntimeException e) {
        return response(500, "Internal server error");
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<?> ExceptionHandler(Exception e) {
        return response(500, "Internal server error");
    }
}
