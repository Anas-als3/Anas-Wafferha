package com.wafferha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;






@SpringBootTest
class WafferhaApplicationTests {

    @Test
    void contextLoads() {
    }
}
