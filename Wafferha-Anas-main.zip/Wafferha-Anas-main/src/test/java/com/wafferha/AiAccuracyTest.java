package com.wafferha;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.wafferha.Model.BehaviorEvent;
import com.wafferha.Model.BehaviorSource;
import com.wafferha.Model.Challenge;
import com.wafferha.Model.User;
import com.wafferha.Repository.BehaviorEventRepository;
import com.wafferha.Repository.BehaviorSourceRepository;
import com.wafferha.Repository.UserRepository;
import com.wafferha.Service.AiTaskService;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;













@SpringBootTest
@EnabledIfSystemProperty(named = "ai.accuracy", matches = "true")
class AiAccuracyTest {

    private static final int N = 50;
    private static final Set<String> VALID_TYPES = Set.of("save", "nospend", "log", "rate", "streak");
    private static final Set<String> VALID_CADENCE = Set.of("DAILY", "WEEKLY", "MONTHLY", "YEARLY");
    private static final List<String> BANNED = List.of("bnpl", "installment", "riba");
    private static final String[] CATEGORIES = {
        "Dining", "Coffee", "Online Shopping", "Entertainment", "Subscriptions",
        "Electronics", "Clothing", "Food Delivery", "Gaming", "Ride Hailing"
    };

    @Autowired private AiTaskService aiTaskService;
    @Autowired private UserRepository userRepository;
    @Autowired private BehaviorSourceRepository behaviorSourceRepository;
    @Autowired private BehaviorEventRepository behaviorEventRepository;

    @Test
    void measureSavingTaskAccuracy() {
        Assumptions.assumeTrue(aiTaskService.aiEnabled(),
                "OpenAI is not enabled - run with -Dopenai.enabled=true and a key in application-local.properties");

        int pass = 0, validSchema = 0, jargonFree = 0, targetSane = 0, realAi = 0, saveType = 0;
        List<String> issues = new ArrayList<>();

        for (int i = 0; i < N; i++) {
            int income = 6000 + (i % 14) * 1000;          
            String category = CATEGORIES[i % CATEGORIES.length];
            int userId = createDataset(i, income, category);
            try {
                Challenge ch = aiTaskService.generateTaskForUser(userId).getChallenge();
                String title = nz(ch.getTitle());
                String type = nz(ch.getType());
                String cadence = nz(ch.getCadence());
                double target = ch.getTargetValue() == null ? 0 : ch.getTargetValue();
                int points = ch.getRewardPoints() == null ? 0 : ch.getRewardPoints();

                boolean schema = !title.isBlank()
                        && VALID_TYPES.contains(type.toLowerCase())
                        && VALID_CADENCE.contains(cadence.toUpperCase())
                        && target > 0 && points >= 5 && points <= 100;
                boolean noJargon = BANNED.stream().noneMatch(b -> title.toLowerCase().contains(b));
                boolean sane = target > 0 && target <= income * 0.5;
                boolean real = !isFallback(title);
                boolean isSave = type.equalsIgnoreCase("save");

                if (schema) validSchema++;
                if (noJargon) jargonFree++;
                if (sane) targetSane++;
                if (real) realAi++;
                if (isSave) saveType++;

                if (schema && noJargon && sane) {
                    pass++;
                } else {
                    issues.add("#" + i + " [" + category + "/" + income + "] type=" + type
                            + " cadence=" + cadence + " target=" + target + " pts=" + points + " title='" + title + "'");
                }
            } catch (Exception e) {
                issues.add("#" + i + " ERROR: " + e.getMessage());
            }
        }

        System.out.println();
        System.out.println("=============== WAFFERHA AI ACCURACY - " + N + " varied datasets ===============");
        System.out.println("Model in use                         : " + aiTaskService.aiModel());
        System.out.println("ACCURACY (valid + plain + sensible)  : " + pass + "/" + N + "  =  " + pct(pass) + "%");
        System.out.println("  - valid, in-spec schema            : " + validSchema + "/" + N + " (" + pct(validSchema) + "%)");
        System.out.println("  - plain language (no BNPL/riba)    : " + jargonFree + "/" + N + " (" + pct(jargonFree) + "%)");
        System.out.println("  - sensible target (<= 50% income)  : " + targetSane + "/" + N + " (" + pct(targetSane) + "%)");
        System.out.println("  - genuine AI answer (not fallback) : " + realAi + "/" + N + " (" + pct(realAi) + "%)");
        System.out.println("  - 'save'-type tasks                : " + saveType + "/" + N + " (" + pct(saveType) + "%)");
        if (!issues.isEmpty()) {
            System.out.println("--- runs that did not fully pass ---");
            issues.forEach(System.out::println);
        }
        System.out.println("=================================================================");
        System.out.println();

        
        
        assertTrue(validSchema == N,
                "Every generated task must be structurally valid; got " + validSchema + "/" + N);
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private int pct(int n) {
        return (int) Math.round(100.0 * n / N);
    }

    private boolean isFallback(String title) {
        if (title == null) {
            return true;
        }
        return (title.startsWith("Skip 2 ") && title.contains("purchases this week and move 120 SAR to savings"))
                || title.equals("Move 120 SAR to savings this week before it's spent");
    }

    
    private int createDataset(int i, int income, String category) {
        User u = new User();
        u.setName("AccuracyUser" + i);
        u.setMonthlyIncome(income);
        u.setPhoneNumber("+96651" + String.format("%06d", i));
        u = userRepository.save(u);
        Integer uid = u.getId();

        BehaviorSource src = new BehaviorSource();
        src.setUserId(uid);
        src.setType("CURRENT_ACCOUNT");
        src.setPrimary(true);
        src = behaviorSourceRepository.save(src);
        Integer sid = src.getId();

        List<BehaviorEvent> events = new ArrayList<>();
        events.add(event(sid, uid, BigDecimal.valueOf(income), "Salary", "IN"));
        for (int k = 0; k < 6; k++) {
            double amt = 40 + ((i + k) % 9) * 25;          
            events.add(event(sid, uid, BigDecimal.valueOf(amt), category, "OUT"));
        }
        events.add(event(sid, uid, BigDecimal.valueOf(income * 0.30), "Rent", "OUT"));
        events.add(event(sid, uid, BigDecimal.valueOf(550), "Groceries", "OUT"));
        behaviorEventRepository.saveAll(events);
        return uid;
    }

    private BehaviorEvent event(Integer sourceId, Integer userId, BigDecimal value, String category, String direction) {
        BehaviorEvent e = new BehaviorEvent();
        e.setSourceId(sourceId);
        e.setUserId(userId);
        e.setValue(value);
        e.setCategory(category);
        e.setDirection(direction);
        return e;
    }
}
